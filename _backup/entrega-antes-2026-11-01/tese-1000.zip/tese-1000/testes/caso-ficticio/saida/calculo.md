# Cálculo do processo 1 (NB 999.999.999-9): **CÁLCULO A CONFERIR**

Data da peça: 28/10/2026 · última competência de contrato ativo: 09/2026

| Derivado | Raiz | Raiz: averbação → exclusão | Intervalo | 1ª averbação do derivado | Norma | Qtde | Parcela | Total | Dobro | Status |
|---|---|---|---|---|---|---|---|---|---|---|
| 51-000111/00001_0001 | 51-000111/00001 | 05/05/2015 → 11/08/2018 | mesmo dia | 11/08/2018 | IN28 | 11 | R$ 33,75 | R$ 371,25 | R$ 742,50 | EXCLUÍDO |

- Total descontado: **R$ 371,25**
- Restituição em dobro: **R$ 742,50 (setecentos e quarenta e dois reais e cinquenta centavos)**
- Dano extrapatrimonial (fixo): **R$ 20.000,00**
- Valor da causa: **R$ 20.742,50 (vinte mil, setecentos e quarenta e dois reais e cinquenta centavos)**
- Tutela de urgência: não (sem derivado ativo)
- Tópico de prescrição (algum desconto com mais de 5 anos): SIM
- Troca de titularidade (mesmo número em outro banco): não

## Alertas

- Derivado 51-000111/00001_0001: há descontos anteriores a 30/03/2021. O marco do EAREsp 676.608/RS não é usado na peça (decisão do escritório de 29/10/2026: sem Tema 929 e sem modulação): pedir o dobro de todos, fundado no art. 42, parágrafo único, do CDC.
