# Cálculo do processo 1 (NB 999.999.999-9) — **CÁLCULO A CONFERIR**

Data da peça: 28/10/2026 · última competência de contrato ativo: 09/2026

| Contrato | Status | Início | Fim usado | Qtde | Parcela | Total | Dobro |
|---|---|---|---|---|---|---|---|
| 00123456789 | EXCLUÍDO | 03/2019 | 11/2021 | 33 | R$ 142,50 | R$ 4.702,50 | R$ 9.405,00 |
| 00987654321 | EXCLUÍDO | 05/2022 | 02/2024 | 22 | R$ 98,30 | R$ 2.162,60 | R$ 4.325,20 |
| 00555111222 | ATIVO | 09/2024 | 09/2026 | 25 | R$ 120,00 | R$ 3.000,00 | R$ 6.000,00 |

- Total descontado: **R$ 9.865,10**
- Restituição em dobro: **R$ 19.730,20**
- Dano moral (fixo): **R$ 20.000,00**
- Valor da causa: **R$ 39.730,20 (trinta e nove mil, setecentos e trinta reais e vinte centavos)**
- Tutela de urgência: SIM, só sobre 00555111222
- Tópico de prescrição (algum desconto com mais de 5 anos): SIM

## Alertas

- Contrato 00123456789: há descontos anteriores a 30/03/2021. O marco do EAREsp 676.608/RS não é usado na peça (decisão do escritório de 29/10/2026: sem Tema 929 e sem modulação): pedir o dobro de todos os descontos, fundado no art. 42, parágrafo único, do CDC.
- ANOMALIA: contrato 00555111222 (bloco B) está ATIVO no extrato; a análise só põe contratos não ativos em B e C. Mostrar ao advogado.
