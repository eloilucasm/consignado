# Fontes e limites da skill de recurso

Data da consulta: 29/10/2026. A skill tem duas camadas de fonte:

1. `references/referencias_juridicas.md`: lista autorizada de dispositivos e precedentes para o recurso, com a seção
   "Decisões do escritório que prevalecem" (alinhamento de 29/10/2026).
2. `references/normas/` e `references/jurisprudencia/`: cópias do acervo do pacote de consignado (o mesmo texto usado
   na inicial e na réplica). Súmulas do STJ e do TJBA vêm daqui.

| Item | Situação |
|---|---|
| Tema 929/STJ | não citar como fundamento (D7) |
| Tema 1414/STJ | afetado, sem tese; suspensão nacional (exceto cumprimentos de sentença) |
| IN 138/2022 | vigência adotada em 13/12/2022 (D30) |
| Marco da biometria | `[CONFERIR]` pela regra de contagem do escritório (D3) |
| Geolocalização e figuras | scripts e arquivos do mapa **congelados** (`testes/mapa/congelados.json`); limiares definidos pelo advogado, sem calibração com logs reais; figuras B e C exigem `regiao.pmtiles` e Playwright no Cowork |
| Calibração do catálogo FSC | 2 sentenças (Ilhéus); ficha em `references/calibracao/ficha-de-sentenca.md` |
