# Checagem FSC e VF: processo 1 (rmc) em 28/10/2026

Registro de trabalho: não entra na peça. Formato e regras em `assets/escrutinio-fsc-vf.md`.

| FSC | Status | Achado | Onde a peça trata |
|---|---|---|---|
| FSC1 | OK | negativa específica por contrato no modelo; conferir que cada número aparece na negativa | subtópico da negativa de contratação |
| FSC2 | OK | a parte não usou plataforma digital nem forneceu biometria; autenticação controvertida por antecipação | subtópico da negativa de contratação |
| FSC3 | OK | art. 14, § 3º, do CDC + art. 429, II, do CPC + Tema 1061/STJ antes do art. 6º, VIII | tópico da inversão do ônus da prova |
| FSC4 | PENDENTE_ADVOGADO | sem contrato do extrato neste cálculo: tratar o valor liberado pelas faturas ou pelo extrato bancário | fatos e tabela de documentos |
| FSC5 | NAO_SE_APLICA | sem origem de migração, portabilidade ou refinanciamento no extrato | — |
| FSC6 | PENDENTE_ADVOGADO | registrar quando e como a parte soube dos descontos; separar inexistência (não prescreve) de repetição e dano | fatos (ciência) |
| FSC7 | OK | negativa específica por contrato e pedido de juntada de cada documento com a contestação; o risco maior é da réplica | negativa específica; inversão do ônus |
| FSC8 | PENDENTE_ADVOGADO | natureza alimentar, período e valor vêm do cálculo; reclamação prévia ao banco precisa constar do quadro de fatos | subtópico do dano extrapatrimonial |
| FSC9 | OK | JEC: sem exibição nem perícia; inversão do ônus e encargo de juntar documentos com a contestação | inversão do ônus |
| FSC10 | PENDENTE_ADVOGADO | pedir que o banco identifique o correspondente e junte a trilha completa; registrar a residência do cliente com ID e página para a réplica | tabela de documentos |
| FSC11 | NAO_SE_APLICA | nenhuma inclusão no mesmo dia nem em até 7 dias de outro contrato do extrato | — |
| FSC12 | PENDENTE_ADVOGADO | documentos de identidade e residência atuais e legíveis; procuração atualizada; um processo por benefício + banco + tese; nada sobre outras ações | lista de documentos |

| VF | Status | Achado |
|---|---|---|
| VF1 | PENDENTE_ADVOGADO | índice dos documentos do cliente (ID provisório de cada um) |
| VF2 | NAO_SE_APLICA | sem documento do banco antes da ação; ficha do contrato fica para a réplica |
| VF3 | NAO_SE_APLICA | extrato sem origem de migração |
| VF4 | NAO_SE_APLICA | sem documento do banco antes da ação; autenticação eletrônica fica para a réplica |
| VF5 | NAO_SE_APLICA | sem documento do banco antes da ação; correspondente bancário fica para a réplica |
| VF6 | NAO_SE_APLICA | sem contrato do extrato neste cálculo |
| VF7 | NAO_SE_APLICA | sem contrato do extrato neste cálculo |
| VF8 | NAO_SE_APLICA | sem contrato do extrato neste cálculo |
| VF9 | PENDENTE_ADVOGADO | registrar a residência com ID e página (e coordenada, se houver) para a geolocalização da réplica |

**Portão 3:** PENDENTE (5 FSC ativado(s) ou pendente(s): FSC4, FSC6, FSC8, FSC10, FSC12)

**Para a réplica:** FSC7 (impugnar um a um os documentos que o banco juntar), FSC1/FSC2 (autenticidade), FSC4 e VF6 (confrontar o TED com o valor liberado), FSC10 e VF9 (correspondente, IP e geolocalização com a residência registrada).
