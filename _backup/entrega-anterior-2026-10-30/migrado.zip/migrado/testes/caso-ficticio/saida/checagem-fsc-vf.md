# Checagem FSC e VF: processo 1 (migrado) em 28/10/2026

Registro de trabalho: não entra na peça. Formato e regras em `assets/escrutinio-fsc-vf.md`.

| FSC | Status | Achado | Onde a peça trata |
|---|---|---|---|
| FSC1 | OK | negativa específica por contrato no modelo; conferir que cada número aparece na negativa | subtópico da negativa de contratação |
| FSC2 | OK | a parte não usou plataforma digital nem forneceu biometria; autenticação controvertida por antecipação | subtópico da negativa de contratação |
| FSC3 | OK | art. 14, § 3º, do CDC + art. 429, II, do CPC + Tema 1061/STJ antes do art. 6º, VIII | tópico da inversão do ônus da prova |
| FSC4 | ATIVADO | 7001001: liberado R$ 1.200,00; 7001002: liberado R$ 15.000,00; 7001003: liberado R$ 3.000,00. extrato bancário do mês da averbação ainda não informado. Risco da Súmula 42/TJBA se o crédito chegou à conta e a peça nega tudo [DECISÃO DO ADVOGADO: devolução, depósito ou compensação] | fatos; tabela de documentos; pedido |
| FSC5 | OK | 7001001: Migrado do contrato 7001001 CBC: 934; 7001002: Migrado do contrato 7001002 CBC: 934; 7001003: Migrado do contrato 7001003 CBC: 934. Tese da skill: cessão não notificada ao devedor (CC, art. 290) | tópico da migração e da cessão |
| FSC6 | ATIVADO | contrato(s) 7001001, 7001002 com desconto iniciado há mais de 5 anos: tratar prescrição (decisão do advogado) e a data da ciência | fatos (ciência); tópico de prescrição |
| FSC7 | OK | negativa específica por contrato e pedido de juntada de cada documento com a contestação; o risco maior é da réplica | negativa específica; inversão do ônus |
| FSC8 | PENDENTE_ADVOGADO | natureza alimentar, período e valor vêm do cálculo; reclamação prévia ao banco precisa constar do quadro de fatos | subtópico do dano extrapatrimonial |
| FSC9 | OK | JEC: sem exibição nem perícia; inversão do ônus e encargo de juntar documentos com a contestação | inversão do ônus |
| FSC10 | PENDENTE_ADVOGADO | pedir que o banco identifique o correspondente e junte a trilha completa; registrar a residência do cliente com ID e página para a réplica | tabela de documentos |
| FSC11 | NAO_SE_APLICA | nenhuma inclusão no mesmo dia nem em até 7 dias de outro contrato do extrato | — |
| FSC12 | PENDENTE_ADVOGADO | documentos de identidade e residência atuais e legíveis; procuração atualizada; um processo por benefício + banco + tese; nada sobre outras ações | lista de documentos |

| VF | Status | Achado |
|---|---|---|
| VF1 | PENDENTE_ADVOGADO | índice dos documentos do cliente (ID provisório de cada um) |
| VF2 | NAO_SE_APLICA | sem documento do banco antes da ação; ficha do contrato fica para a réplica |
| VF3 | EXECUTADA | 7001001: Migrado do contrato 7001001 CBC: 934; 7001002: Migrado do contrato 7001002 CBC: 934; 7001003: Migrado do contrato 7001003 CBC: 934 |
| VF4 | NAO_SE_APLICA | sem documento do banco antes da ação; autenticação eletrônica fica para a réplica |
| VF5 | NAO_SE_APLICA | sem documento do banco antes da ação; correspondente bancário fica para a réplica |
| VF6 | PENDENTE_ADVOGADO | pedir ao cliente o extrato bancário do mês da averbação de cada contrato (Súmula 42/TJBA) |
| VF7 | EXECUTADA | sem repetição de datas entre contratos do mesmo banco |
| VF8 | EXECUTADA | 0 par(es) até 7 dias |
| VF9 | PENDENTE_ADVOGADO | registrar a residência com ID e página (e coordenada, se houver) para a geolocalização da réplica |

**Portão 3:** PENDENTE (5 FSC ativado(s) ou pendente(s): FSC4, FSC6, FSC8, FSC10, FSC12)

**Para a réplica:** FSC7 (impugnar um a um os documentos que o banco juntar), FSC1/FSC2 (autenticidade), FSC4 e VF6 (confrontar o TED com o valor liberado), FSC10 e VF9 (correspondente, IP e geolocalização com a residência registrada).
