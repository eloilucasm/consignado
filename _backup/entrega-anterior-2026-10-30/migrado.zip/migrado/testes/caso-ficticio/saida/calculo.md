# Cálculo do processo 1 (NB 999.999.999-9): **CÁLCULO A CONFERIR**

Data da peça: 28/10/2026 · última competência de contrato ativo: 09/2026

| Contrato | Origem da averbação | Banco de origem (CBC) | 1ª averbação | Norma | Início | Fim usado | Qtde | Parcela | Total | Dobro | Vincendas | Status |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 7001001 | Migrado do contrato 7001001 CBC: 934 | 934 | 16/06/2021 | IN28 | 07/2021 | 12/2021 | 6 | R$ 68,25 | R$ 409,50 | R$ 819,00 | 0 (R$ 0,00) | EXCLUÍDO |
| 7001002 | Migrado do contrato 7001002 CBC: 934 | 934 | 20/04/2021 | IN28 | 05/2021 | 12/2021 | 8 | R$ 482,64 | R$ 3.861,12 | R$ 7.722,24 | 0 (R$ 0,00) | EXCLUÍDO |
| 7001003 | Migrado do contrato 7001003 CBC: 934 | 934 | 10/01/2024 | IN138 | 02/2025 | 09/2026 | 20 | R$ 77,80 | R$ 1.556,00 | R$ 3.112,00 | 64 (R$ 4.979,20) | ATIVO |

- Total descontado: **R$ 5.826,62**
- Restituição em dobro: **R$ 11.653,24 (onze mil, seiscentos e cinquenta e três reais e vinte e quatro centavos)**
- Dano extrapatrimonial (fixo): **R$ 20.000,00**
- Valor da causa: **R$ 31.653,24 (trinta e um mil, seiscentos e cinquenta e três reais e vinte e quatro centavos)**
- Proveito econômico declaratório (parcelas vincendas dos ativos, só Justiça Comum, decisão do advogado): R$ 4.979,20 · valor da causa com proveito: R$ 36.632,44 (trinta e seis mil, seiscentos e trinta e dois reais e quarenta e quatro centavos)
- Tutela de urgência: SIM, só sobre 7001003
- Tópico de prescrição (algum desconto com mais de 5 anos): SIM
- Troca de titularidade (mesmo número em outro banco): SIM; descontos do banco anterior NÃO somados

## Alertas

- Contrato 7001001: migrado do banco 934, mas o extrato não mostra o registro do banco anterior; conferir.
- Contrato 7001002: migrado do banco 934, mas o extrato não mostra o registro do banco anterior; conferir.
- TROCA DE TITULARIDADE: o contrato 7001003 aparece também em 934 - BANCO ORIGEM FICTICIO S.A., com 11 parcela(s) (R$ 855,80) que NÃO foram somadas. Decisão do advogado sobre a legitimidade do réu e a extensão da restituição; para somar, rode com --incluir-outros-bancos.
- Contratos de regimes diferentes (IN 28 e IN 138) no mesmo processo: o modelo traz os dois blocos; revisar.
