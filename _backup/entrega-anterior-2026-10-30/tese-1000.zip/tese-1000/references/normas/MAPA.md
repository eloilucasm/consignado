# Mapa de dispositivos: tese-1000

Gerado por `python3 _manutencao/gerar-mapa.py` (não edite à mão). Um dispositivo por linha: número do artigo, linha do arquivo e início do texto (sem os parágrafos e incisos). Serve para achar o artigo **pelo conteúdo**. A regra é o texto do arquivo indicado, com parágrafos e incisos.

**Como usar.**
- **Cowork:** abra o arquivo só na janela indicada (`Read` com `offset` na linha do artigo) ou use `grep -n "^Art. N"`.
- **Chat, sem execução de código:** procure no arquivo o número do artigo (`Art. N`) e leia a partir dali.
- Para localizar por Livro, Título ou Capítulo, use `ESTRUTURA.md`. O que não está nas normas desta pasta está em `../../protocolo/fontes-e-limites.md`.
- Dispositivo ~~riscado~~ ou marcado (revogado) não é vigente: não o cite como vigente.


## Lei nº 10.406/2002 — Código Civil

`cc.md` · 9368 linhas

_Mapa seletivo: só os 11 artigos que as peças usam. Os demais estão em `ESTRUTURA.md`._

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 104 | 551 | A validade do negócio jurídico requer: |
| Art. 157 | 721 | Ocorre a lesão quando uma pessoa, sob premente necessidade, ou por inexperiência, se obriga a prestação manifestamente desproporcional ao valor da… |
| Art. 166 | 755 | É nulo o negócio jurídico quando: |
| Art. 168 | 783 | As nulidades dos artigos antecedentes podem ser alegadas por qualquer interessado, ou pelo Ministério Público, quando lhe couber intervir. |
| Art. 169 | 787 | O negócio jurídico nulo não é suscetível de confirmação, nem convalesce pelo decurso do tempo. |
| Art. 182 | 823 | Anulado o negócio jurídico, restituir-se-ão as partes ao estado em que antes dele se achavam, e, não sendo possível restituí-las, serão indenizadas… |
| Art. 186 | 835 | Aquele que, por ação ou omissão voluntária, negligência ou imprudência, violar direito e causar dano a outrem, ainda que exclusivamente moral, comete… |
| Art. 205 | 929 | A prescrição ocorre em dez anos, quando a lei não lhe haja fixado prazo menor. |
| Art. 397 | 1591 | O inadimplemento da obrigação, positiva e líquida, no seu termo, constitui de pleno direito em mora o devedor. |
| Art. 398 | 1595 | Nas obrigações provenientes de ato ilícito, considera-se o devedor em mora, desde que o praticou. |
| Art. 422 | 1687 | Os contratantes são obrigados a guardar, assim na conclusão do contrato, como em sua execução, os princípios de probidade e boa-fé. |

## Lei nº 8.078/1990 — Código de Defesa do Consumidor

`cdc.md` · 1102 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 33 | O presente código estabelece normas de proteção e defesa do consumidor, de ordem pública e interesse social, nos termos dos arts. 5°, inciso XXXII,… |
| Art. 2º | 35 | Consumidor é toda pessoa física ou jurídica que adquire ou utiliza produto ou serviço como destinatário final. |
| Art. 3º | 39 | Fornecedor é toda pessoa física ou jurídica, pública ou privada, nacional ou estrangeira, bem como os entes despersonalizados, que desenvolvem… |
| Art. 4º | 47 | A Política Nacional das Relações de Consumo tem por objetivo o atendimento das necessidades dos consumidores, o respeito à sua dignidade, saúde e… |
| Art. 5º | 77 | Para a execução da Política Nacional das Relações de Consumo, contará o poder público com os seguintes instrumentos, entre outros: |
| Art. 6º | 99 | São direitos básicos do consumidor: |
| Art. 7º | 129 | Os direitos previstos neste código não excluem outros decorrentes de tratados ou convenções internacionais de que o Brasil seja signatário, da… |
| Art. 8º | 137 | Os produtos e serviços colocados no mercado de consumo não acarretarão riscos à saúde ou segurança dos consumidores, exceto os considerados normais e… |
| Art. 9º | 143 | O fornecedor de produtos e serviços potencialmente nocivos ou perigosos à saúde ou segurança deverá informar, de maneira ostensiva e adequada, a… |
| Art. 10 | 145 | O fornecedor não poderá colocar no mercado de consumo produto ou serviço que sabe ou deveria saber apresentar alto grau de nocividade ou… |
| Art. 11 | 153 | (Vetado). |
| Art. 12 | 157 | O fabricante, o produtor, o construtor, nacional ou estrangeiro, e o importador respondem, independentemente da existência de culpa, pela reparação… |
| Art. 13 | 177 | O comerciante é igualmente responsável, nos termos do artigo anterior, quando: |
| Art. 14 | 187 | O fornecedor de serviços responde, independentemente da existência de culpa, pela reparação dos danos causados aos consumidores por defeitos… |
| Art. 15 | 207 | (Vetado). |
| Art. 16 | 209 | (Vetado). |
| Art. 17 | 211 | Para os efeitos desta Seção, equiparam-se aos consumidores todas as vítimas do evento. |
| Art. 18 | 215 | Os fornecedores de produtos de consumo duráveis ou não duráveis respondem solidariamente pelos vícios de qualidade ou quantidade que os tornem… |
| Art. 19 | 241 | Os fornecedores respondem solidariamente pelos vícios de quantidade do produto sempre que, respeitadas as variações decorrentes de sua natureza, seu… |
| Art. 20 | 255 | O fornecedor de serviços responde pelos vícios de qualidade que os tornem impróprios ao consumo ou lhes diminuam o valor, assim como por aqueles… |
| Art. 21 | 267 | No fornecimento de serviços que tenham por objetivo a reparação de qualquer produto considerar-se-á implícita a obrigação do fornecedor de empregar… |
| Art. 22 | 269 | Os órgãos públicos, por si ou suas empresas, concessionárias, permissionárias ou sob qualquer outra forma de empreendimento, são obrigados a fornecer… |
| Art. 23 | 273 | A ignorância do fornecedor sobre os vícios de qualidade por inadequação dos produtos e serviços não o exime de responsabilidade. |
| Art. 24 | 275 | A garantia legal de adequação do produto ou serviço independe de termo expresso, vedada a exoneração contratual do fornecedor. |
| Art. 25 | 277 | É vedada a estipulação contratual de cláusula que impossibilite, exonere ou atenue a obrigação de indenizar prevista nesta e nas seções anteriores. |
| Art. 26 | 285 | O direito de reclamar pelos vícios aparentes ou de fácil constatação caduca em: |
| Art. 27 | 303 | Prescreve em cinco anos a pretensão à reparação pelos danos causados por fato do produto ou do serviço prevista na Seção II deste Capítulo,… |
| Art. 28 | 309 | O juiz poderá desconsiderar a personalidade jurídica da sociedade quando, em detrimento do consumidor, houver abuso de direito, excesso de poder,… |
| Art. 29 | 325 | Para os fins deste Capítulo e do seguinte, equiparam-se aos consumidores todas as pessoas determináveis ou não, expostas às práticas nele previstas. |
| Art. 30 | 329 | Toda informação ou publicidade, suficientemente precisa, veiculada por qualquer forma ou meio de comunicação com relação a produtos e serviços… |
| Art. 31 | 331 | A oferta e apresentação de produtos ou serviços devem assegurar informações corretas, claras, precisas, ostensivas e em língua portuguesa sobre suas… |
| Art. 32 | 335 | Os fabricantes e importadores deverão assegurar a oferta de componentes e peças de reposição enquanto não cessar a fabricação ou importação do… |
| Art. 33 | 339 | Em caso de oferta ou venda por telefone ou reembolso postal, deve constar o nome do fabricante e endereço na embalagem, publicidade e em todos os… |
| Art. 34 | 343 | O fornecedor do produto ou serviço é solidariamente responsável pelos atos de seus prepostos ou representantes autônomos. |
| Art. 35 | 345 | Se o fornecedor de produtos ou serviços recusar cumprimento à oferta, apresentação ou publicidade, o consumidor poderá, alternativamente e à sua… |
| Art. 36 | 355 | A publicidade deve ser veiculada de tal forma que o consumidor, fácil e imediatamente, a identifique como tal. |
| Art. 37 | 359 | É proibida toda publicidade enganosa ou abusiva. |
| Art. 38 | 369 | O ônus da prova da veracidade e correção da informação ou comunicação publicitária cabe a quem as patrocina. |
| Art. 39 | 373 | É vedado ao fornecedor de produtos ou serviços, dentre outras práticas abusivas: |
| Art. 40 | 405 | O fornecedor de serviço será obrigado a entregar ao consumidor orçamento prévio discriminando o valor da mão-de-obra, dos materiais e equipamentos a… |
| Art. 41 | 413 | No caso de fornecimento de produtos ou de serviços sujeitos ao regime de controle ou de tabelamento de preços, os fornecedores deverão respeitar os… |
| Art. 42 | 417 | Na cobrança de débitos, o consumidor inadimplente não será exposto a ridículo, nem será submetido a qualquer tipo de constrangimento ou ameaça. |
| Art. 42-A | 421 | Em todos os documentos de cobrança de débitos apresentados ao consumidor, deverão constar o nome, o endereço e o número de inscrição no Cadastro de… |
| Art. 43 | 425 | O consumidor, sem prejuízo do disposto no art. 86, terá acesso às informações existentes em cadastros, fichas, registros e dados pessoais e de… |
| Art. 44 | 439 | Os órgãos públicos de defesa do consumidor manterão cadastros atualizados de reclamações fundamentadas contra fornecedores de produtos e serviços,… |
| Art. 45 | 445 | (Vetado). |
| Art. 46 | 451 | Os contratos que regulam as relações de consumo não obrigarão os consumidores, se não lhes for dada a oportunidade de tomar conhecimento prévio de… |
| Art. 47 | 453 | As cláusulas contratuais serão interpretadas de maneira mais favorável ao consumidor. |
| Art. 48 | 455 | As declarações de vontade constantes de escritos particulares, recibos e pré-contratos relativos às relações de consumo vinculam o fornecedor,… |
| Art. 49 | 457 | O consumidor pode desistir do contrato, no prazo de 7 dias a contar de sua assinatura ou do ato de recebimento do produto ou serviço, sempre que a… |
| Art. 50 | 461 | A garantia contratual é complementar à legal e será conferida mediante termo escrito. |
| Art. 51 | 467 | São nulas de pleno direito, entre outras, as cláusulas contratuais relativas ao fornecimento de produtos e serviços que: |
| Art. 52 | 521 | No fornecimento de produtos ou serviços que envolva outorga de crédito ou concessão de financiamento ao consumidor, o fornecedor deverá, entre outros… |
| Art. 53 | 539 | Nos contratos de compra e venda de móveis ou imóveis mediante pagamento em prestações, bem como nas alienações fiduciárias em garantia, consideram-se… |
| Art. 54 | 549 | Contrato de adesão é aquele cujas cláusulas tenham sido aprovadas pela autoridade competente ou estabelecidas unilateralmente pelo fornecedor de… |
| Art. 54-A | 567 | Este Capítulo dispõe sobre a prevenção do superendividamento da pessoa natural, sobre o crédito responsável e sobre a educação financeira do… |
| Art. 54-B | 575 | No fornecimento de crédito e na venda a prazo, além das informações obrigatórias previstas no art. 52 deste Código e na legislação aplicável à… |
| Art. 54-C | 593 | É vedado, expressa ou implicitamente, na oferta de crédito ao consumidor, publicitária ou não: |
| Art. 54-D | 607 | Na oferta de crédito, previamente à contratação, o fornecedor ou o intermediário deverá, entre outras condutas: |
| Art. 54-E | 617 | (VETADO). |
| Art. 54-F | 619 | São conexos, coligados ou interdependentes, entre outros, o contrato principal de fornecimento de produto ou serviço e os contratos acessórios de… |
| Art. 54-G | 637 | Sem prejuízo do disposto no art. 39 deste Código e na legislação aplicável à matéria, é vedado ao fornecedor de produto ou serviço que envolva… |
| Art. 55 | 651 | A União, os Estados e o Distrito Federal, em caráter concorrente e nas suas respectivas áreas de atuação administrativa, baixarão normas relativas à… |
| Art. 56 | 661 | As infrações das normas de defesa do consumidor ficam sujeitas, conforme o caso, às seguintes sanções administrativas, sem prejuízo das de natureza… |
| Art. 57 | 689 | A pena de multa, graduada de acordo com a gravidade da infração, a vantagem auferida e a condição econômica do fornecedor, será aplicada mediante… |
| Art. 58 | 695 | As penas de apreensão, de inutilização de produtos, de proibição de fabricação de produtos, de suspensão do fornecimento de produto ou serviço, de… |
| Art. 59 | 697 | As penas de cassação de alvará de licença, de interdição e de suspensão temporária da atividade, bem como a de intervenção administrativa, serão… |
| Art. 60 | 705 | A imposição de contrapropaganda será cominada quando o fornecedor incorrer na prática de publicidade enganosa ou abusiva, nos termos do art. 36 e… |
| Art. 61 | 715 | Constituem crimes contra as relações de consumo previstas neste código, sem prejuízo do disposto no Código Penal e leis especiais, as condutas… |
| Art. 62 | 717 | (Vetado). |
| Art. 63 | 719 | Omitir dizeres ou sinais ostensivos sobre a nocividade ou periculosidade de produtos, nas embalagens, nos invólucros, recipientes ou publicidade: |
| Art. 64 | 729 | Deixar de comunicar à autoridade competente e aos consumidores a nocividade ou periculosidade de produtos cujo conhecimento seja posterior à sua… |
| Art. 65 | 735 | Executar serviço de alto grau de periculosidade, contrariando determinação de autoridade competente: |
| Art. 66 | 743 | Fazer afirmação falsa ou enganosa, ou omitir informação relevante sobre a natureza, característica, qualidade, quantidade, segurança, desempenho,… |
| Art. 67 | 753 | Fazer ou promover publicidade que sabe ou deveria saber ser enganosa ou abusiva: |
| Art. 68 | 759 | Fazer ou promover publicidade que sabe ou deveria saber ser capaz de induzir o consumidor a se comportar de forma prejudicial ou perigosa a sua saúde… |
| Art. 69 | 765 | Deixar de organizar dados fáticos, técnicos e científicos que dão base à publicidade: |
| Art. 70 | 769 | Empregar na reparação de produtos, peça ou componentes de reposição usados, sem autorização do consumidor: |
| Art. 71 | 773 | Utilizar, na cobrança de dívidas, de ameaça, coação, constrangimento físico ou moral, afirmações falsas incorretas ou enganosas ou de qualquer outro… |
| Art. 72 | 777 | Impedir ou dificultar o acesso do consumidor às informações que sobre ele constem em cadastros, banco de dados, fichas e registros: |
| Art. 73 | 781 | Deixar de corrigir imediatamente informação sobre consumidor constante de cadastro, banco de dados, fichas ou registros que sabe ou deveria saber ser… |
| Art. 74 | 785 | Deixar de entregar ao consumidor o termo de garantia adequadamente preenchido e com especificação clara de seu conteúdo; |
| Art. 75 | 789 | Quem, de qualquer forma, concorrer para os crimes referidos neste código, incide as penas a esses cominadas na medida de sua culpabilidade, bem como… |
| Art. 76 | 791 | São circunstâncias agravantes dos crimes tipificados neste código: |
| Art. 77 | 807 | A pena pecuniária prevista nesta Seção será fixada em dias-multa, correspondente ao mínimo e ao máximo de dias de duração da pena privativa da… |
| Art. 78 | 809 | Além das penas privativas de liberdade e de multa, podem ser impostas, cumulativa ou alternadamente, observado odisposto nos arts. 44 a 47, do Código… |
| Art. 79 | 817 | O valor da fiança, nas infrações de que trata este código, será fixado pelo juiz, ou pela autoridade que presidir o inquérito, entre cem e duzentas… |
| Art. 80 | 825 | No processo penal atinente aos crimes previstos neste código, bem como a outros crimes e contravenções que envolvam relações de consumo, poderão… |
| Art. 81 | 831 | A defesa dos interesses e direitos dos consumidores e das vítimas poderá ser exercida em juízo individualmente, ou a título coletivo. |
| Art. 82 | 841 | Para os fins do art. 81, parágrafo único, são legitimados concorrentemente: |
| Art. 83 | 857 | Para a defesa dos direitos e interesses protegidos por este código são admissíveis todas as espécies de ações capazes de propiciar sua adequada e… |
| Art. 84 | 861 | Na ação que tenha por objeto o cumprimento da obrigação de fazer ou não fazer, o juiz concederá a tutela específica da obrigação ou determinará… |
| Art. 85 | 873 | (Vetado). |
| Art. 86 | 875 | (Vetado). |
| Art. 87 | 877 | Nas ações coletivas de que trata este código não haverá adiantamento de custas, emolumentos, honorários periciais e quaisquer outras despesas, nem… |
| Art. 88 | 881 | Na hipótese do art. 13, parágrafo único deste código, a ação de regresso poderá ser ajuizada em processo autônomo, facultada a possibilidade de… |
| Art. 89 | 883 | (Vetado) |
| Art. 90 | 885 | Aplicam-se às ações previstas neste título as normas do Código de Processo Civil e da Lei n° 7.347, de 24 de julho de 1985, inclusive no que respeita… |
| Art. 91 | 889 | Os legitimados de que trata o art. 82 poderão propor, em nome próprio e no interesse das vítimas ou seus sucessores, ação civil coletiva de… |
| Art. 92 | 891 | O Ministério Público, se não ajuizar a ação, atuará sempre como fiscal da lei. |
| Art. 93 | 895 | Ressalvada a competência da Justiça Federal, é competente para a causa a justiça local: |
| Art. 94 | 901 | Proposta a ação, será publicado edital no órgão oficial, a fim de que os interessados possam intervir no processo como litisconsortes, sem prejuízo… |
| Art. 95 | 903 | Em caso de procedência do pedido, a condenação será genérica, fixando a responsabilidade do réu pelos danos causados. |
| Art. 96 | 905 | (Vetado). |
| Art. 97 | 907 | A liquidação e a execução de sentença poderão ser promovidas pela vítima e seus sucessores, assim como pelos legitimados de que trata o art. 82. |
| Art. 98 | 911 | A execução poderá ser coletiva, sendo promovida pelos legitimados de que trata o art. 82, abrangendo as vítimas cujas indenizações já tiveram sido… |
| Art. 99 | 921 | Em caso de concurso de créditos decorrentes de condenação prevista na Lei n.° 7.347, de 24 de julho de 1985 e de indenizações pelos prejuízos… |
| Art. 100 | 925 | Decorrido o prazo de um ano sem habilitação de interessados em número compatível com a gravidade do dano, poderão os legitimados do art. 82 promover… |
| Art. 101 | 931 | Na ação de responsabilidade civil do fornecedor de produtos e serviços, sem prejuízo do disposto nos Capítulos I e II deste título, serão observadas… |
| Art. 102 | 937 | Os legitimados a agir na forma deste código poderão propor ação visando compelir o Poder Público competente a proibir, em todo o território nacional,… |
| Art. 103 | 945 | Nas ações coletivas de que trata este código, a sentença fará coisa julgada: |
| Art. 104 | 961 | As ações coletivas, previstas nos incisos I e II e do parágrafo único do art. 81, não induzem litispendência para as ações individuais, mas os… |
| Art. 104-A | 969 | A requerimento do consumidor superendividado pessoa natural, o juiz poderá instaurar processo de repactuação de dívidas, com vistas à realização de… |
| Art. 104-B | 989 | Se não houver êxito na conciliação em relação a quaisquer credores, o juiz, a pedido do consumidor, instaurará processo por superendividamento para… |
| Art. 104-C | 999 | Compete concorrente e facultativamente aos órgãos públicos integrantes do Sistema Nacional de Defesa do Consumidor a fase conciliatória e preventiva… |
| Art. 105 | 1007 | Integram o Sistema Nacional de Defesa do Consumidor (SNDC), os órgãos federais, estaduais, do Distrito Federal e municipais e as entidades privadas… |
| Art. 106 | 1009 | O Departamento Nacional de Defesa do Consumidor, da Secretaria Nacional de Direito Econômico (MJ), ou órgão federal que venha substituí-lo, é… |
| Art. 107 | 1041 | As entidades civis de consumidores e as associações de fornecedores ou sindicatos de categoria econômica podem regular, por convenção escrita,… |
| Art. 108 | 1049 | (Vetado). |
| Art. 109 | 1053 | (Vetado). |
| Art. 110 | 1055 | Acrescente-se o seguinte inciso IV ao art. 1° da Lei n° 7.347, de 24 de julho de 1985: |
| Art. 111 | 1059 | O inciso II do art. 5° da Lei n° 7.347, de 24 de julho de 1985, passa a ter a seguinte redação: |
| Art. 112 | 1063 | O § 3° do art. 5° da Lei n° 7.347, de 24 de julho de 1985, passa a ter a seguinte redação: |
| Art. 113 | 1067 | Acrescente-se os seguintes §§ 4°, 5° e 6° ao art. 5º. da Lei n.° 7.347, de 24 de julho de 1985: |
| Art. 114 | 1075 | O art. 15 da Lei n° 7.347, de 24 de julho de 1985, passa a ter a seguinte redação: |
| Art. 115 | 1079 | Suprima-se o caput do art. 17 da Lei n° 7.347, de 24 de julho de 1985, passando o parágrafo único a constituir o caput, com a seguinte redação: |
| Art. 116 | 1083 | Dê-se a seguinte redação ao art. 18 da Lei n° 7.347, de 24 de julho de 1985: |
| Art. 117 | 1087 | Acrescente-se à Lei n° 7.347, de 24 de julho de 1985, o seguinte dispositivo, renumerando-se os seguintes: |
| Art. 118 | 1091 | Este código entrará em vigor dentro de cento e oitenta dias a contar de sua publicação. |
| Art. 119 | 1093 | Revogam-se as disposições em contrário. |

## Lei nº 13.105/2015 — Código de Processo Civil

`cpc.md` · 8700 linhas

_Mapa seletivo: só os 28 artigos que as peças usam. Os demais estão em `ESTRUTURA.md`._

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 85 | 707 | A sentença condenará o vencido a pagar honorários ao advogado do vencedor. |
| Art. 98 | 839 | A pessoa natural ou jurídica, brasileira ou estrangeira, com insuficiência de recursos para pagar as custas, as despesas processuais e os honorários… |
| Art. 99 | 875 | O pedido de gratuidade da justiça pode ser formulado na petição inicial, na contestação, na petição para ingresso de terceiro no processo ou em… |
| Art. 105 | 919 | A procuração geral para o foro, outorgada por instrumento público ou particular assinado pela parte, habilita o advogado a praticar todos os atos do… |
| Art. 219 | 1725 | Na contagem de prazo em dias, estabelecido por lei ou pelo juiz, computar-se-ão somente os dias úteis. |
| Art. 292 | 2269 | O valor da causa constará da petição inicial ou da reconvenção e será: |
| Art. 294 | 2299 | A tutela provisória pode fundamentar-se em urgência ou evidência. |
| Art. 300 | 2323 | A tutela de urgência será concedida quando houver elementos que evidenciem a probabilidade do direito e o perigo de dano ou o risco ao resultado útil… |
| Art. 311 | 2417 | A tutela da evidência será concedida, independentemente da demonstração de perigo de dano ou de risco ao resultado útil do processo, quando: |
| Art. 337 | 2699 | Incumbe ao réu, antes de discutir o mérito, alegar: |
| Art. 369 | 2975 | As partes têm o direito de empregar todos os meios legais, bem como os moralmente legítimos, ainda que não especificados neste Código, para provar a… |
| Art. 373 | 2985 | O ônus da prova incumbe: |
| Art. 396 | 3135 | O juiz pode ordenar que a parte exiba documento ou coisa que se encontre em seu poder. |
| Art. 397 | 3137 | O pedido formulado pela parte conterá: |
| Art. 398 | 3151 | O requerido dará sua resposta nos 5 (cinco) dias subsequentes à sua intimação. |
| Art. 399 | 3155 | O juiz não admitirá a recusa se: |
| Art. 400 | 3163 | Ao decidir o pedido, o juiz admitirá como verdadeiros os fatos que, por meio do documento ou da coisa, a parte pretendia provar se: |
| Art. 401 | 3171 | Quando o documento ou a coisa estiver em poder de terceiro, o juiz ordenará sua citação para responder no prazo de 15 (quinze) dias. |
| Art. 402 | 3173 | Se o terceiro negar a obrigação de exibir ou a posse do documento ou da coisa, o juiz designará audiência especial, tomando-lhe o depoimento, bem… |
| Art. 403 | 3175 | Se o terceiro, sem justo motivo, se recusar a efetuar a exibição, o juiz ordenar-lhe-á que proceda ao respectivo depósito em cartório ou em outro… |
| Art. 404 | 3179 | A parte e o terceiro se escusam de exibir, em juízo, o documento ou a coisa se: |
| Art. 429 | 3325 | Incumbe o ônus da prova quando: |
| Art. 489 | 3815 | São elementos essenciais da sentença: |
| Art. 497 | 3917 | Na ação que tenha por objeto a prestação de fazer ou de não fazer, o juiz, se procedente o pedido, concederá a tutela específica ou determinará… |
| Art. 505 | 3955 | Nenhum juiz decidirá novamente as questões já decididas relativas à mesma lide, salvo: |
| Art. 508 | 3965 | Transitada em julgado a decisão de mérito, considerar-se-ão deduzidas e repelidas todas as alegações e as defesas que a parte poderia opor tanto ao… |
| Art. 537 | 4329 | A multa independe de requerimento da parte e poderá ser aplicada na fase de conhecimento, em tutela provisória ou na sentença, ou na fase de… |
| Art. 1.048 | 8515 | Terão prioridade de tramitação, em qualquer juízo ou tribunal, os procedimentos judiciais: |

## IN PRES/INSS nº 138/2022 — texto consolidado "com as alterações" (PDF do INSS, atualizado em 19/5/2026)

`in-inss-138-2022-consolidada.md` · 810 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 21 | O desconto no valor da aposentadoria e da pensão por morte pagas pelo Regime Geral de Previdência Social, bem como no valor do Benefício de Prestação… |
| Art. 1º | 23 | O desconto no valor da aposentadoria e da pensão por morte pagas pelo Regime Geral de Previdência Social, das parcelas referentes ao pagamento de… |
| Art. 1º | 25 | O desconto do valor das parcelas referentes ao pagamento de empréstimo pessoal consignado, cartão de crédito consignado e cartão consignado de… |
| Art. 1º | 27 | Esta Instrução Normativa, dispõe sobre o desconto do valor das parcelas referentes ao pagamento de empréstimo pessoal consignado, cartão de crédito… |
| Art. 1º | 29 | Esta Instrução Normativa dispõe sobre o desconto do valor das parcelas referentes ao pagamento de empréstimo pessoal consignado, cartão de crédito… |
| Art. 2º | 53 | Em qualquer circunstância, a responsabilidade do INSS em relação ao crédito consignado restringe-se à retenção dos valores autorizados pelo… |
| Art. 3º | 65 | O crédito consignado, cujas parcelas contratadas são deduzidas diretamente do pagamento mensal do benefício, compreende as seguintes modalidades: |
| Art. 3º-B | 69 | Os titulares de benefícios elegíveis pagos pelo INSS, poderão antecipar valores do pagamento do seu benefício referente à competência imediatamente… |
| Art. 4º | 87 | Para os fins desta Instrução Normativa, considera-se: |
| Art. 5º | 159 | A averbação da contratação de crédito consignado pelo titular do benefício ocorrerá desde que: I - a operação seja realizada com a própria… |
| Art. 6º | 245 | A averbação da contratação do crédito consignado não será permitida nos benefícios tratados no art. 1º, quando: |
| Art. 7º | 255 | A identificação do limite de 45% (quarenta e cinco por cento) dar-se-á no momento da averbação, após a dedução das seguintes consignações, observada… |
| Art. 8º | 263 | O bloqueio dos benefícios elegíveis para averbação do crédito consignado é realizado: |
| Art. 10 | 323 | A instituição consignatária acordante deverá disponibilizar ao beneficiário que solicitar a quitação antecipada do seu contrato a planilha… |
| Art. 11 | 333 | A cessão de créditos entre instituições financeiras poderá ser realizada, desde que atenda às normas editadas pelo BCB e pelo CMN. |
| Art. 13 | 361 | A portabilidade entre instituições financeiras poderá ser realizada, desde que atenda às normas editadas pelo BCB e CMN. |
| Art. 14 | 367 | O refinanciamento entre o beneficiário e a instituição financeira contratada poderá ser realizado, desde que atenda às normas editadas pelo BCB e… |
| Art. 15 | 375 | Os beneficiários, sem limite de idade, poderão constituir RMC para utilização de cartão de crédito consignado e RCC para utilização do cartão… |
| Art. 16 | 435 | Exclusivamente, na contratação do cartão consignado de benefício de que trata o inciso V do art. 4º, além do disposto no art. 15, é obrigatória: |
| Art. 16 | 437 | Nas contratações de cartão consignado de benefício e de cartão de crédito consignado, além do disposto no art. 15, é obrigatória: |
| Art. 17 | 467 | Atendidos os requisitos da legislação vigente e havendo margem consignável disponível no benefício, a averbação do desconto relativo ao crédito… |
| Art. 18 | 471 | A Dataprev, ao receber as informações para averbação do crédito consignado, considerará como campos obrigatórios de informação, além dos fixados no… |
| Art. 19 | 513 | As operações de crédito consignado, processadas mensalmente pela Dataprev, serão identificadas no extrato de pagamento do benefício por meio das… |
| Art. 20 | 521 | A Dataprev, mensalmente, encaminhará às instituições consignatárias acordantes, por arquivo, as parcelas consignadas, não consignadas, glosadas e… |
| Art. 21 | 523 | Com base nos valores apurados no arquivo magnético de que trata o art. 20, o INSS efetuará o repasse financeiro às respectivas instituições… |
| Art. 22 | 525 | Serão deduzidas do próximo repasse de valores às instituições consignatárias acordantes, credoras das parcelas, as consignações referentes: |
| Art. 23 | 543 | Os descontos, e respectivos repasses, são interrompidos por ocorrências relacionadas às alterações: |
| Art. 23-A | 569 | Os descontos e respectivos repasses serão interrompidos em razão do não envio de documentos ou informações exigidas nesta Instrução Normativa pelas… |
| Art. 24 | 571 | O contrato de crédito consignado suspenso, cuja vigência não tenha expirado, poderá ser reativado, observado que: |
| Art. 25 | 583 | O beneficiário que, a qualquer momento, sentir-se prejudicado por operação ou contrato de crédito consignado considerados irregular ou inexistente,… |
| Art. 26 | 589 | As reclamações não abrangidas pelo disposto no art. 25 deverão ser registradas na Plataforma Integrada de Ouvidoria e Acesso à informação – Fala.BR… |
| Art. 27 | 595 | Cabe ao INSS: I - credenciar as instituições financeiras, por intermédio da celebração de ACT, |
| Art. 28 | 619 | A Dataprev está autorizada pelo INSS a processar as operações do crédito consignado, abrangidas pela Lei nº 10.820, de 2003, com redação dada pela… |
| Art. 29 | 621 | A Dataprev efetuará cobrança direta da instituição consignatária acordante relativa aos custos de operacionalização do crédito consignado, conforme… |
| Art. 30 | 623 | Os custos operacionais diretos e indiretos acarretados ao INSS pelas operações de crédito consignado e relacionados à gestão dos benefícios elegíveis… |
| Art. 30 | 625 | Os custos operacionais diretos e indiretos acarretados ao INSS pelas operações de crédito consignado e relacionados à gestão dos benefícios elegíveis… |
| Art. 31 | 629 | Cabe à Dataprev: I - efetivar as operações tratadas nas Seções I, II e III do Capítulo III; II - disponibilizar ao INSS, em sistema de informações… |
| Art. 32 | 639 | Para a formalização do ACT com o INSS, a instituição consignatária deverá seguir o disciplinado na Portaria nº 76/DIRBEN/INSS, de 2020. |
| Art. 33 | 653 | As instituições consignatárias acordantes deverão cumprir as cláusulas do ACT celebrado com o INSS. |
| Art. 34 | 655 | Caberá às instituições consignatárias acordantes ou seus correspondentes bancários: |
| Art. 35 | 723 | É vedado às instituições consignatárias acordantes ou seus correspondentes bancários: |
| Art. 36 | 747 | Constatadas irregularidades nas operações de crédito consignado ou descumprimento das obrigações, pelas instituições consignatárias acordantes ou por… |
| Art. 38 | 783 | As instituições que possuem ACT com o INSS e contrato com a Dataprev vigentes deverão adaptar-se a todos os seus termos, inclusive quanto às normas… |
| Art. 38-A | 797 | Para reajuste do teto das operações de empréstimo consignado em benefício previdenciário, serão usados como referência os juros reais anualizados, em… |
| Art. 39 | 799 | Fica revogada a Instrução Normativa INSS/PRES nº 28, de 2008. |
| Art. 40 | 801 | Esta Instrução Normativa entra em vigor no ato da publicação. |

## IN PRES/INSS nº 143, de 10 de fevereiro de 2023 — altera a IN 138/2022

`in-inss-143-2023.md` · 66 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 13 | A Instrução Normativa PRES/INSS nº 138, de 10 de novembro 2022, passa a vigorar com as seguintes alterações: |
| Art. 2º | 59 | Ficam prorrogados por 60 (sessenta) dias, a contar da data da publicação desta Instrução Normativa, sob pena de rescisão, os prazos previstos no… |
| Art. 3º | 61 | Fica revogado o § 4º do art. 1º da Instrução Normativa PRES/INSS nº 138, de 2022. |
| Art. 4º | 63 | Esta Instrução Normativa entra em vigor na data de sua publicação. |

## IN INSS/PRES nº 28, de 16 de maio de 2008 — texto consolidado "atualizado 22.07.2020" (REVOGADA)

`in-inss-28-2008-consolidada-2020.md` · 885 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 18 | O desconto no valor d aposentadoria e pensão por morte pagas pela Previdência Social das parcelas referentes ao pagamento de empréstimo pessoal e… |
| Art. 2º | 36 | Para os fins desta Instrução Normativa, considera se: |
| Art. 3º | 72 | Os titulares de benefícios de aposentadoria e pensão por morte, pagos pela Previdência Social, poderão autorizar o desconto no respectivo benefício… |
| Art. 3º | 74 | Os titulares de benefícios de aposentadoria e pensão por morte, pagos pela Previdência Social, poderão autorizar o desconto no respectivo benefício… |
| Art. 4º | 140 | A contratação de operações de crédito consignado só poderá ocorrer, desde que: |
| Art. 5º | 148 | A instituição financeira, independentemente da modalidade de crédito adotada, somente encaminhará o arquivo para averbação de crédito após a devida… |
| Art. 6º | 150 | A inobservância do disposto no art. 5º implicará total responsabilidade da instituição financeira envolvida e, em caso de reclamação registrada pelo… |
| Art. 6º | 152 | A inobservância do disposto no art. 5º implicará total responsabilidade da instituição financeira envolvida e, em caso de ilegalidade constatada pelo… |
| Art. 7º | 154 | A concessão de empréstimo pessoal e cartão de crédito será feita a critério da instituição consignatária, sendo os valores e demais condições objeto… |
| Art. 8º | 156 | As informações necessárias à formalização do contrato de crédito poderão ser obtidas: I - pelos beneficiários, diretamente no sítio eletrônico da… |
| Art. 9º | 160 | A contratação de empréstimo e cartão de crédito somente poderá ser efetivada no Estado em que o beneficiário tem seu benefício mantido. |
| Art. 10 | 164 | O desconto relativo às consignações/retenções de que trata esta Instrução Normativa se aplica aos benefícios de aposentadoria, qualquer que seja sua… |
| Art. 11 | 174 | O disposto nesta Instrução Normativa não se aplica às seguintes espécies de benefícios assistenciais: |
| Art. 12 | 180 | A identificação do limite de 30% (trinta por cento) de que trata o § 1º do art. 3º dar-se-á após a apuração das seguintes deduções: (alterado pela… |
| Art. 12 | 182 | A identificação do limite de 35% (trinta e cinco por cento) de que trata o § 1º do art. 3º dar-se-á após a apuração das seguintes deduções: (alterado… |
| Art. 12 | 184 | A identificação do limite de 35% (trinta e cinco por cento) de que trata o § 1º do art. 3º dar-se-á após a dedução das seguintes consignações… |
| Art. 14 | 232 | O titular do benefício pode efetuar o empréstimo para aquisição de pacote turístico, no âmbito do programa de viagens para aposentados e pensionistas… |
| Art. 15 | 236 | Os titulares dos benefícios previdenciários de aposentadoria e pensão por morte, pagos pela Previdência Social, poderão constituir RMC para… |
| Art. 16 | 242 | Nas operações de cartão de crédito serão considerados, observado, no que couber, o disposto no art. 58 desta Instrução Normativa: |
| Art. 17 | 274 | A instituição financeira deverá encaminhar aos titulares dos benefícios com quem tenha celebrado contrato de cartão de crédito, mensalmente, extrato… |
| Art. 17-A | 276 | O beneficiário poderá, a qualquer tempo, independentemente de seu adimplemento contratual, solicitar o cancelamento do cartão de crédito junto à… |
| Art. 18 | 284 | O convênio como INSS/Dataprev será firmado e mantido com a instituição financeira que satisfaça, cumulativamente, as seguintes condições: |
| Art. 19 | 296 | A contratação de empréstimo pessoal e cartão de crédito de que trata esta Instrução Normativa, firmada pelos titulares dos benefícios… |
| Art. 20 | 298 | Para a efetivação da consignação/retenção/constituição de RMC nos benefícios previdenciários, as instituições financeiras que firmarem convênio com o… |
| Art. 20 | 300 | Para a efetivação da consignação/retenção/constituição de RMC nos benefícios previdenciários, as instituições financeiras que firmarem convênio com o… |
| Art. 21 | 304 | A instituição financeira, ao realizar as operações de consignação/retenção/constituição de RMC dos titulares de benefícios deverá, sem prejuízo de… |
| Art. 21 | 306 | A instituição financeira, ao realizar as operações de consignação/retenção/constituição de RMC dos titulares de benefícios deverá, sem prejuízo de… |
| Art. 21-A | 326 | Sem prejuízo das informações do art. 21, nas autorizações de descontos decorrentes da celebração de contratos de Cartão de Crédito com Reserva de… |
| Art. 21-A | 328 | Sem prejuízo das informações do art. 21, nas autorizações de descontos decorrentes da celebração de contratos de Cartão de Crédito com Reserva de… |
| Art. 22 | 376 | Sempre que o beneficiário receber o benefício por meio de crédito em conta corrente, o crédito do empréstimo concedido deverá ser feito,… |
| Art. 23 | 378 | Confirmado o efetivo registro da consignação pela Dataprev, a instituição financeira obriga-se a liberar o valor contratado ao beneficiário no prazo… |
| Art. 23 | 380 | Confirmado o efetivo registro da consignação pela Dataprev, a instituição financeira obriga-se a liberar o valor contratado ao beneficiário no prazo… |
| Art. 24 | 402 | Os encargos praticados pela instituição financeira nas operações de crédito realizadas na mesma unidade da federação, deverão ser idênticos para… |
| Art. 25 | 404 | A instituição financeira concedente do empréstimo é obrigada a confirmar se a operadora de turismo está devidamente autorizada e credenciada pelo… |
| Art. 26 | 412 | A instituição financeira deverá divulgar as regras de consignações/retenções/constituição de RMC acordadas em contrato com os… |
| Art. 27 | 414 | Eventuais alterações das taxas de juros deverão ser comunicadas ao INSS por meio do correio eletrônico institucional estabelecido pela Diretoria de… |
| Art. 27-A | 416 | As instituições financeiras que utilizam os serviços de terceirização para a operacionalização da venda de crédito consignado informarão ao INSS os… |
| Art. 28 | 418 | A instituição financeira concedente de crédito deverá conservar os documentos que comprovam a operação pelo prazo de cinco anos, contados da data do… |
| Art. 29 | 422 | A Dataprev é o órgão responsável, tanto pelos procedimentos operacionais quanto pela segurança da rotina de envio das informações de créditos em… |
| Art. 30 | 424 | A Dataprev, ao receber os arquivos para averbação de empréstimo ou cartão de crédito, considerará como campos obrigatórios de informação no arquivo… |
| Art. 30 | 426 | A Dataprev, ao receber as informações para averbação de empréstimo ou cartão de crédito, considerará como campos obrigatórios de informação, além dos… |
| Art. 31 | 442 | O primeiro desconto na renda do benefício dar-se-á no primeiro mês subseqüente ao do envio das informações pelas instituições financeiras para a… |
| Art. 32 | 444 | As operações de averbação, exclusão e reativação processadas mensalmente pela Dataprev serão identificadas como: |
| Art. 33 | 448 | A Dataprev disponibilizará ao INSS, em sistema de informações próprio, os dados das operações de crédito consignado em nível gerencial e operacional,… |
| Art. 34 | 450 | A Dataprev indicará à instituição financeira a conta corrente bancária para depósito do pagamento dos seus custos operacionais, conforme previsto no… |
| Art. 34-A | 454 | Os custos operacionais diretos e indiretos acarretados ao INSS pelas operações de crédito consignado e relacionados à gestão dos benefícios… |
| Art. 35 | 460 | O INSS repassará os valores descontados dos benefícios em razão das consignações processadas às respectivas instituições financeiras até o quinto dia… |
| Art. 36 | 464 | Tratando-se de operação realizada com a instituição financeira mantenedora do benefício, o INSS repassará a ela o valor integral do benefício,… |
| Art. 37 | 468 | O INSS manterá o benefício cujo titular autorizar a retenção referida no art. 36desta Instrução Normativa na instituição financeira mantenedora do… |
| Art. 38 | 480 | A Dirben verificará, trimestralmente, a situação de regularidade das instituições financeiras no SIAFI/SICAF, bem como se não integram o Cadastro… |
| Art. 39 | 484 | O INSS se encarregará de disponibilizar as informações sobre empréstimos consignados no sítio eletrônico da Previdência Social… |
| Art. 40 | 486 | O INSS poderá, a qualquer momento, solicitar a apresentação de contratos das operações de crédito ou mesmo a devolução de importâncias, atualizadas… |
| Art. 41 | 494 | Na ocorrência de cessação de benefício com data retroativa ou de eventuais importâncias repassadas indevidamente, inclusive relativas a créditos com… |
| Art. 43 | 504 | A APS poderá, a pedido do beneficiário e a qualquer tempo, bloquear ou desbloquear o benefício para averbações de empréstimos ou cartão de crédito,… |
| Art. 43 | 506 | O beneficiário ou representante legal, conforme inciso IV do art. 3º, poderá, respeitado o disposto no § 2º do art. 1º, efetuar bloqueio ou… |
| Art. 44 | 518 | A exclusão de empréstimo, RMC e parcelamento do cartão de crédito poderá ser efetuada pela instituição financeira ou pela APS. (alterado pela… |
| Art. 45 | 538 | As reclamações, críticas e sugestões pertinentes aos créditos consignados serão recebidas e tratadas, no âmbito da Previdência Social, pela OGPS. |
| Art. 46 | 540 | O beneficiário que, a qualquer momento, se sentir prejudicado por operações irregulares ou inexistentes ou que identificar descumprimento do contrato… |
| Art. 46 | 542 | O beneficiário que, a qualquer momento, se sentir prejudicado por operações irregulares ou inexistentes ou que identificar descumprimento do contrato… |
| Art. 47 | 550 | As reclamações serão recebidas diariamente pela OGPS e serão adotadas as seguintes providências: |
| Art. 48 | 586 | Quando a reclamação for considerada procedente por irregularidade na contratação ou consignação/averbação incorreta ou indevida em benefício, a… |
| Art. 49 | 604 | Quando o beneficiário não concordar com o resultado da resposta comunicada nos termos da alínea "a", inciso III, art. 47 desta Instrução Normativa,… |
| Art. 49 | 606 | Quando o beneficiário não concordar com o resultado da resposta comunicada nos termos da alínea "a", inciso IV, art. 47, deverá contestar junto às… |
| Art. 50 | 614 | A Dirben enviará, periodicamente, relatório ao Banco Central - Bacen, contendo as informações das reclamações de que tratam os arts.46, 47 e § 3º do… |
| Art. 50 | 616 | A Dataprev disponibilizará ao INSS relatório contendo as informações das reclamações de que tratam os arts. 46 e 47, para as providências cabíveis,… |
| Art. 51 | 618 | Os procedimentos previstos no inciso I do art. 47 desta Instrução Normativa poderão, a qualquer momento, ser alterados para disponibilização das… |
| Art. 52 | 628 | Constatadas irregularidades nas operações de consignação/retenção/RMC realizadas pelas instituições financeiras ou por correspondentes bancários a… |
| Art. 52-A | 660 | As penalidades previstas neste capítulo serão aplicadas mediante observância do devido processo legal, respeitados o contraditório e a ampla defesa,… |
| Art. 53 | 684 | O INSS não responde, em nenhuma hipótese, pelos débitos contratados, restringindo sua responsabilidade à averbação dos valores autorizados pelo… |
| Art. 54 | 698 | A contratação de empréstimo ou cartão de crédito constitui uma operação entre instituição financeira e beneficiário, cabendo, unicamente às partes,… |
| Art. 55 | 700 | Eventuais dúvidas sobre a operacionalização da contratação de empréstimo e cartão de crédito deverão ser dirimidas com a instituição financeira. |
| Art. 56 | 702 | A cessão de créditos entre instituições financeiras poderá ser realizada, desde que atenda às normas editadas pelo Conselho Monetário Nacional,… |
| Art. 57 | 706 | A instituição financeira que, após firmar convênio com o INSS/Dataprev, permanecer por três meses consecutivos sem realizar operações de empréstimo… |
| Art. 58 | 708 | A partir da vigência desta Instrução Normativa serão regulamentadas por portaria do Presidente do INSS eventuais alterações relativas: |
| Art. 59 | 714 | As instituições financeiras que já celebraram convênio com o INSS/Dataprev, para os fins previstos nesta Instrução Normativa, deverão, no prazo de… |
| Art. 60-A | 720 | As atualizações e posteriores alterações dos Anexos desta Instrução Normativa poderão ser objeto de Despacho Decisório da Dirben. (incluído pela… |
| Art. 61 | 722 | Revoga-se a Instrução Normativa INSS/DC Nº 121, de 1º de julho de |

## INs de 2022 que alteraram a IN INSS/PRES 28/2008 (INs 131, 136 e 137)

`in-inss-alteradoras-da-in28-2022.md` · 167 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 16 | A Instrução Normativa INSS/PRES nº 28, de 16 de maio de 2008, publicada no Diário Oficial da União nº 94, de 19 de maio de 2008, Seção 1, págs.… |
| Art. 2º | 50 | Fica revogado o inciso III do art. 11 da Instrução Normativa INSS/PRES nº 28, de 2008: |
| Art. 3º | 52 | Esta Instrução Normativa entra em vigor na data de sua publicação. |
| Art. 1º | 66 | A Instrução Normativa INSS/PRES nº 28, de 16 de maio de 2008, publicada no Diário Oficial da União - DOU nº 94, de 19 de maio de 2008, Seção 1, págs.… |
| Art. 2º | 94 | A Instrução Normativa PRES/INSS nº 128, de 28 de março de 2022, publicada no DOU nº 60, em 29 de março de 2022, Seção 1, pág. 132, passa a vigorar… |
| Art. 3º | 110 | Ficam revogados os seguintes dispositivos: |
| Art. 4º | 120 | Esta Instrução Normativa entra em vigor na data de sua publicação. |
| Art. 1º | 134 | A Instrução Normativa INSS/PRES nº 28, de 16 de maio de 2008, publicada no Diário Oficial da União - DOU nº 94, de 19 de maio de 2008, Seção 1, págs.… |
| Art. 2º | 162 | Fica revogado o § 1º-A do art. 3º da Instrução Normativa INSS/PRES nº 28, de 2008. |
| Art. 3º | 164 | Esta Instrução Normativa entra em vigor na data de sua publicação. |

## Lei nº 10.741/2003 — Estatuto da Pessoa Idosa

`lei-10741.md` · 1166 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º (revogado) | 19 | É instituído o Estatuto do Idoso, destinado a regular os direitos assegurados às pessoas com idade igual ou superior a 60 (sessenta) anos. |
| Art. 1º | 21 | É instituído o Estatuto da Pessoa Idosa, destinado a regular os direitos assegurados às pessoas com idade igual ou superior a 60 (sessenta) anos. |
| Art. 2º (revogado) | 23 | O idoso goza de todos os direitos fundamentais inerentes à pessoa humana, sem prejuízo da proteção integral de que trata esta Lei,… |
| Art. 2º | 25 | A pessoa idosa goza de todos os direitos fundamentais inerentes à pessoa humana, sem prejuízo da proteção integral de que trata esta Lei,… |
| Art. 3º (revogado) | 27 | É obrigação da família, da comunidade, da sociedade e do Poder Público assegurar ao idoso, com absoluta prioridade, a efetivação do direito à vida, à… |
| Art. 3º | 29 | É obrigação da família, da comunidade, da sociedade e do poder público assegurar à pessoa idosa, com absoluta prioridade, a efetivação do direito à… |
| Art. 4º (revogado) | 65 | Nenhum idoso será objeto de qualquer tipo de negligência, discriminação, violência, crueldade ou opressão, e todo atentado aos seus direitos, por… |
| Art. 4º | 67 | Nenhuma pessoa idosa será objeto de qualquer tipo de negligência, discriminação, violência, crueldade ou opressão, e todo atentado aos seus direitos,… |
| Art. 5º | 75 | A inobservância das normas de prevenção importará em responsabilidade à pessoa física ou jurídica nos termos da lei. |
| Art. 6º | 77 | Todo cidadão tem o dever de comunicar à autoridade competente qualquer forma de violação a esta Lei que tenha testemunhado ou de que tenha… |
| Art. 7º (revogado) | 79 | Os Conselhos Nacional, Estaduais, do Distrito Federal e Municipais do Idoso, previstos na Lei no 8.842, de 4 de janeiro de 1994, zelarão pelo… |
| Art. 7º | 81 | Os Conselhos Nacional, Estaduais, do Distrito Federal e Municipais da Pessoa Idosa, previstos na Lei nº 8.842, de 4 de janeiro de 1994, zelarão pelo… |
| Art. 8º | 87 | O envelhecimento é um direito personalíssimo e a sua proteção um direito social, nos termos desta Lei e da legislação vigente. |
| Art. 9º | 89 | É obrigação do Estado, garantir à pessoa idosa a proteção à vida e à saúde, mediante efetivação de políticas sociais públicas que permitam um… |
| Art. 10 (revogado) | 95 | É obrigação do Estado e da sociedade, assegurar à pessoa idosa a liberdade, o respeito e a dignidade, como pessoa humana e sujeito de direitos civis,… |
| Art. 10 | 97 | É obrigação do Estado e da sociedade assegurar à pessoa idosa a liberdade, o respeito e a dignidade, como pessoa humana e sujeito de direitos civis,… |
| Art. 11 (revogado) | 123 | Os alimentos serão prestados ao idoso na forma da lei civil. |
| Art. 11 | 125 | Os alimentos serão prestados à pessoa idosa na forma da lei civil. |
| Art. 12 (revogado) | 127 | A obrigação alimentar é solidária, podendo o idoso optar entre os prestadores. |
| Art. 12 | 129 | A obrigação alimentar é solidária, podendo a pessoa idosa optar entre os prestadores. |
| Art. 13 (revogado) | 131 | As transações relativas a alimentos poderão ser celebradas perante o Promotor de Justiça, que as referendará, e passarão a ter efeito de título… |
| Art. 13 | 133 | As transações relativas a alimentos poderão ser celebradas perante o Promotor de Justiça ou Defensor Público, que as referendará, e passarão a ter… |
| Art. 14 (revogado) | 135 | Se o idoso ou seus familiares não possuírem condições econômicas de prover o seu sustento, impõe-se ao Poder Público esse provimento, no âmbito da… |
| Art. 14 | 137 | Se a pessoa idosa ou seus familiares não possuírem condições econômicas de prover o seu sustento, impõe-se ao poder público esse provimento, no… |
| Art. 15 (revogado) | 141 | É assegurada a atenção integral à saúde do idoso, por intermédio do Sistema Único de Saúde – SUS, garantindo-lhe o acesso universal e igualitário, em… |
| Art. 15 | 143 | É assegurada a atenção integral à saúde da pessoa idosa, por intermédio do Sistema Único de Saúde (SUS), garantindo-lhe o acesso universal e… |
| Art. 16 (revogado) | 193 | Ao idoso internado ou em observação é assegurado o direito a acompanhante, devendo o órgão de saúde proporcionar as condições adequadas para a sua… |
| Art. 16 | 195 | À pessoa idosa internada ou em observação é assegurado o direito a acompanhante, devendo o órgão de saúde proporcionar as condições adequadas para a… |
| Art. 17 (revogado) | 201 | Ao idoso que esteja no domínio de suas faculdades mentais é assegurado o direito de optar pelo tratamento de saúde que lhe for reputado mais… |
| Art. 17 | 203 | À pessoa idosa que esteja no domínio de suas faculdades mentais é assegurado o direito de optar pelo tratamento de saúde que lhe for reputado mais… |
| Art. 18 (revogado) | 221 | As instituições de saúde devem atender aos critérios mínimos para o atendimento às necessidades do idoso, promovendo o treinamento e a capacitação… |
| Art. 18 | 223 | As instituições de saúde devem atender aos critérios mínimos para o atendimento às necessidades da pessoa idosa, promovendo o treinamento e a… |
| Art. 19 (revogado) | 225 | Os casos de suspeita ou confirmação de maus-tratos contra idoso serão obrigatoriamente comunicados pelos profissionais de saúde a quaisquer dos… |
| Art. 19 (revogado) | 227 | Os casos de suspeita ou confirmação de violência praticada contra idosos serão objeto de notificação compulsória pelos serviços de saúde públicos e… |
| Art. 19 | 229 | Os casos de suspeita ou confirmação de violência praticada contra pessoas idosas serão objeto de notificação compulsória pelos serviços de saúde… |
| Art. 20 (revogado) | 255 | O idoso tem direito a educação, cultura, esporte, lazer, diversões, espetáculos, produtos e serviços que respeitem sua peculiar condição de idade. |
| Art. 20 | 257 | A pessoa idosa tem direito a educação, cultura, esporte, lazer, diversões, espetáculos, produtos e serviços que respeitem sua peculiar condição de… |
| Art. 21 (revogado) | 259 | O Poder Público criará oportunidades de acesso do idoso à educação, adequando currículos, metodologias e material didático aos programas educacionais… |
| Art. 21 | 261 | O poder público criará oportunidades de acesso da pessoa idosa à educação, adequando currículos, metodologias e material didático aos programas… |
| Art. 22 (revogado) | 271 | Nos currículos mínimos dos diversos níveis de ensino formal serão inseridos conteúdos voltados ao processo de envelhecimento, ao respeito e à… |
| Art. 22 | 273 | Nos currículos mínimos dos diversos níveis de ensino formal serão inseridos conteúdos voltados ao processo de envelhecimento, ao respeito e à… |
| Art. 23 (revogado) | 275 | A participação dos idosos em atividades culturais e de lazer será proporcionada mediante descontos de pelo menos 50% (cinqüenta por cento) nos… |
| Art. 23 | 277 | A participação das pessoas idosas em atividades culturais e de lazer será proporcionada mediante descontos de pelo menos 50% (cinquenta por cento)… |
| Art. 24 (revogado) | 279 | Os meios de comunicação manterão espaços ou horários especiais voltados aos idosos, com finalidade informativa, educativa, artística e cultural, e ao… |
| Art. 24 | 281 | Os meios de comunicação manterão espaços ou horários especiais voltados às pessoas idosas, com finalidade informativa, educativa, artística e… |
| Art. 25 (revogado) | 283 | O Poder Público apoiará a criação de universidade aberta para as pessoas idosas e incentivará a publicação de livros e periódicos, de conteúdo e… |
| Art. 25 | 285 | As instituições de educação superior ofertarão às pessoas idosas, na perspectiva da educação ao longo da vida, cursos e programas de extensão,… |
| Art. 26 (revogado) | 293 | O idoso tem direito ao exercício de atividade profissional, respeitadas suas condições físicas, intelectuais e psíquicas. |
| Art. 26 | 295 | A pessoa idosa tem direito ao exercício de atividade profissional, respeitadas suas condições físicas, intelectuais e psíquicas. |
| Art. 27 (revogado) | 297 | Na admissão do idoso em qualquer trabalho ou emprego, é vedada a discriminação e a fixação de limite máximo de idade, inclusive para concursos,… |
| Art. 27 | 299 | Na admissão da pessoa idosa em qualquer trabalho ou emprego, são vedadas a discriminação e a fixação de limite máximo de idade, inclusive para… |
| Art. 28 | 303 | O Poder Público criará e estimulará programas de: |
| Art. 29 | 317 | Os benefícios de aposentadoria e pensão do Regime Geral da Previdência Social observarão, na sua concessão, critérios de cálculo que preservem o… |
| Art. 30 | 321 | A perda da condição de segurado não será considerada para a concessão da aposentadoria por idade, desde que a pessoa conte com, no mínimo, o tempo de… |
| Art. 31 | 325 | O pagamento de parcelas relativas a benefícios, efetuado com atraso por responsabilidade da Previdência Social, será atualizado pelo mesmo índice… |
| Art. 32 | 327 | O Dia Mundial do Trabalho, 1o de Maio, é a data-base dos aposentados e pensionistas. |
| Art. 33 (revogado) | 331 | A assistência social aos idosos será prestada, de forma articulada, conforme os princípios e diretrizes previstos na Lei Orgânica da Assistência… |
| Art. 33 | 333 | A assistência social às pessoas idosas será prestada, de forma articulada, conforme os princípios e diretrizes previstos na Lei Orgânica da… |
| Art. 34 (revogado) | 335 | Aos idosos, a partir de 65 (sessenta e cinco) anos, que não possuam meios para prover sua subsistência, nem de tê-la provida por sua família, é… |
| Art. 34 | 337 | Às pessoas idosas, a partir de 65 (sessenta e cinco) anos, que não possuam meios para prover sua subsistência, nem de tê-la provida por sua família,… |
| Art. 35 | 341 | Todas as entidades de longa permanência, ou casa-lar, são obrigadas a firmar contrato de prestação de serviços com a pessoa idosa abrigada. |
| Art. 36 (revogado) | 353 | O acolhimento de idosos em situação de risco social, por adulto ou núcleo familiar, caracteriza a dependência econômica, para os efeitos legais. |
| Art. 36 | 355 | O acolhimento de pessoas idosas em situação de risco social, por adulto ou núcleo familiar, caracteriza a dependência econômica, para os efeitos… |
| Art. 37 (revogado) | 359 | O idoso tem direito a moradia digna, no seio da família natural ou substituta, ou desacompanhado de seus familiares, quando assim o desejar, ou,… |
| Art. 37 | 361 | A pessoa idosa tem direito a moradia digna, no seio da família natural ou substituta, ou desacompanhada de seus familiares, quando assim o desejar,… |
| Art. 38 (revogado) | 373 | Nos programas habitacionais, públicos ou subsidiados com recursos públicos, o idoso goza de prioridade na aquisição de imóvel para moradia própria,… |
| Art. 38 | 375 | Nos programas habitacionais, públicos ou subsidiados com recursos públicos, a pessoa idosa goza de prioridade na aquisição de imóvel para moradia… |
| Art. 39 | 399 | Aos maiores de 65 (sessenta e cinco) anos fica assegurada a gratuidade dos transportes coletivos públicos urbanos e semi-urbanos, exceto nos serviços… |
| Art. 40 | 411 | No sistema de transporte coletivo interestadual observar-se-á, nos termos da legislação específica: |
| Art. 41 (revogado) | 423 | É assegurada a reserva, para os idosos, nos termos da lei local, de 5% (cinco por cento) das vagas nos estacionamentos públicos e privados, as quais… |
| Art. 41 | 425 | É assegurada a reserva para as pessoas idosas, nos termos da lei local, de 5% (cinco por cento) das vagas nos estacionamentos públicos e privados, as… |
| Art. 42 (revogado) | 427 | É assegurada a prioridade do idoso no embarque no sistema de transporte coletivo. |
| Art. 42 | 429 | São asseguradas a prioridade e a segurança do idoso nos procedimentos de embarque e desembarque nos veículos do sistema de transporte coletivo. |
| Art. 42 | 431 | São asseguradas a prioridade e a segurança da pessoa idosa nos procedimentos de embarque e desembarque nos veículos do sistema de transporte coletivo. |
| Art. 43 (revogado) | 437 | As medidas de proteção ao idoso são aplicáveis sempre que os direitos reconhecidos nesta Lei forem ameaçados ou violados: |
| Art. 43 | 439 | As medidas de proteção à pessoa idosa são aplicáveis sempre que os direitos reconhecidos nesta Lei forem ameaçados ou violados: |
| Art. 44 (revogado) | 449 | As medidas de proteção ao idoso previstas nesta Lei poderão ser aplicadas, isolada ou cumulativamente, e levarão em conta os fins sociais a que se… |
| Art. 44 | 451 | As medidas de proteção à pessoa idosa previstas nesta Lei poderão ser aplicadas, isolada ou cumulativamente, e levarão em conta os fins sociais a que… |
| Art. 45 | 453 | Verificada qualquer das hipóteses previstas no art. 43, o Ministério Público ou o Poder Judiciário, a requerimento daquele, poderá determinar, dentre… |
| Art. 46 (revogado) | 473 | A política de atendimento ao idoso far-se-á por meio do conjunto articulado de ações governamentais e não-governamentais da União, dos Estados, do… |
| Art. 46 | 475 | A política de atendimento à pessoa idosa far-se-á por meio do conjunto articulado de ações governamentais e não governamentais da União, dos Estados,… |
| Art. 47 | 477 | São linhas de ação da política de atendimento: |
| Art. 48 (revogado) | 499 | As entidades de atendimento são responsáveis pela manutenção das próprias unidades, observadas as normas de planejamento e execução emanadas do órgão… |
| Art. 48 | 501 | As entidades de atendimento são responsáveis pela manutenção das próprias unidades, observadas as normas de planejamento e execução emanadas do órgão… |
| Art. 49 | 515 | As entidades que desenvolvam programas de institucionalização de longa permanência adotarão os seguintes princípios: |
| Art. 50 | 541 | Constituem obrigações das entidades de atendimento: |
| Art. 51 (revogado) | 589 | As instituições filantrópicas ou sem fins lucrativos prestadoras de serviço ao idoso terão direito à assistência judiciária gratuita. |
| Art. 51 | 591 | As instituições filantrópicas ou sem fins lucrativos prestadoras de serviço às pessoas idosas terão direito à assistência judiciária gratuita. |
| Art. 52 (revogado) | 595 | As entidades governamentais e não-governamentais de atendimento ao idoso serão fiscalizadas pelos Conselhos do Idoso, Ministério Público, Vigilância… |
| Art. 52 | 597 | As entidades governamentais e não governamentais de atendimento à pessoa idosa serão fiscalizadas pelos Conselhos da Pessoa Idosa, Ministério… |
| Art. 53 | 599 | O art. 7o da Lei no 8.842, de 1994, passa a vigorar com a seguinte redação: |
| Art. 54 | 603 | Será dada publicidade das prestações de contas dos recursos públicos e privados recebidos pelas entidades de atendimento. |
| Art. 55 | 605 | As entidades de atendimento que descumprirem as determinações desta Lei ficarão sujeitas, sem prejuízo da responsabilidade civil e criminal de seus… |
| Art. 56 | 647 | Deixar a entidade de atendimento de cumprir as determinações do art. 50 desta Lei: |
| Art. 57 (revogado) | 655 | Deixar o profissional de saúde ou o responsável por estabelecimento de saúde ou instituição de longa permanência de comunicar à autoridade competente… |
| Art. 57 | 657 | Deixar o profissional de saúde ou o responsável por estabelecimento de saúde ou instituição de longa permanência de comunicar à autoridade competente… |
| Art. 58 (revogado) | 661 | Deixar de cumprir as determinações desta Lei sobre a prioridade no atendimento ao idoso: |
| Art. 58 | 663 | Deixar de cumprir as determinações desta Lei sobre a prioridade no atendimento à pessoa idosa: |
| Art. 59 | 673 | Os valores monetários expressos no Capítulo IV serão atualizados anualmente, na forma da lei. |
| Art. 60 (revogado) | 675 | O procedimento para a imposição de penalidade administrativa por infração às normas de proteção ao idoso terá início com requisição do Ministério… |
| Art. 60 | 677 | O procedimento para a imposição de penalidade administrativa por infração às normas de proteção à pessoa idosa terá início com requisição do… |
| Art. 61 | 683 | O autuado terá prazo de 10 (dez) dias para a apresentação da defesa, contado da data da intimação, que será feita: |
| Art. 62 (revogado) | 689 | Havendo risco para a vida ou à saúde do idoso, a autoridade competente aplicará à entidade de atendimento as sanções regulamentares, sem prejuízo da… |
| Art. 62 | 691 | Havendo risco para a vida ou à saúde da pessoa idosa, a autoridade competente aplicará à entidade de atendimento as sanções regulamentares, sem… |
| Art. 63 | 693 | Nos casos em que não houver risco para a vida ou a saúde da pessoa idosa abrigada, a autoridade competente aplicará à entidade de atendimento as… |
| Art. 64 | 697 | Aplicam-se, subsidiariamente, ao procedimento administrativo de que trata este Capítulo as disposições das Leis nos 6.437, de 20 de agosto de 1977, e… |
| Art. 65 (revogado) | 699 | O procedimento de apuração de irregularidade em entidade governamental e não-governamental de atendimento ao idoso terá início mediante petição… |
| Art. 65 | 701 | O procedimento de apuração de irregularidade em entidade governamental e não governamental de atendimento à pessoa idosa terá início mediante petição… |
| Art. 66 (revogado) | 703 | Havendo motivo grave, poderá a autoridade judiciária, ouvido o Ministério Público, decretar liminarmente o afastamento provisório do dirigente da… |
| Art. 66 | 705 | Havendo motivo grave, poderá a autoridade judiciária, ouvido o Ministério Público, decretar liminarmente o afastamento provisório do dirigente da… |
| Art. 67 | 707 | O dirigente da entidade será citado para, no prazo de 10 (dez) dias, oferecer resposta escrita, podendo juntar documentos e indicar as provas a… |
| Art. 68 | 709 | Apresentada a defesa, o juiz procederá na conformidade do art. 69 ou, se necessário, designará audiência de instrução e julgamento, deliberando sobre… |
| Art. 69 | 723 | Aplica-se, subsidiariamente, às disposições deste Capítulo, o procedimento sumário previsto no Código de Processo Civil, naquilo que não contrarie os… |
| Art. 70 (revogado) | 725 | O Poder Público poderá criar varas especializadas e exclusivas do idoso. |
| Art. 70 | 727 | O poder público poderá criar varas especializadas e exclusivas da pessoa idosa. |
| Art. 71 | 729 | É assegurada prioridade na tramitação dos processos e procedimentos e na execução dos atos e diligências judiciais em que figure como parte ou… |
| Art. 72 | 747 | (VETADO) |
| Art. 73 | 749 | As funções do Ministério Público, previstas nesta Lei, serão exercidas nos termos da respectiva Lei Orgânica. |
| Art. 74 | 751 | Compete ao Ministério Público: |
| Art. 75 | 801 | Nos processos e procedimentos em que não for parte, atuará obrigatoriamente o Ministério Público na defesa dos direitos e interesses de que cuida… |
| Art. 76 | 803 | A intimação do Ministério Público, em qualquer caso, será feita pessoalmente. |
| Art. 77 | 805 | A falta de intervenção do Ministério Público acarreta a nulidade do feito, que será declarada de ofício pelo juiz ou a requerimento de qualquer… |
| Art. 78 | 809 | As manifestações processuais do representante do Ministério Público deverão ser fundamentadas. |
| Art. 79 (revogado) | 811 | Regem-se pelas disposições desta Lei as ações de responsabilidade por ofensa aos direitos assegurados ao idoso, referentes à omissão ou ao… |
| Art. 79 | 813 | Regem-se pelas disposições desta Lei as ações de responsabilidade por ofensa aos direitos assegurados à pessoa idosa, referentes à omissão ou ao… |
| Art. 80 (revogado) | 833 | As ações previstas neste Capítulo serão propostas no foro do domicílio do idoso, cujo juízo terá competência absoluta para processar a causa,… |
| Art. 80 | 835 | As ações previstas neste Capítulo serão propostas no foro do domicílio da pessoa idosa, cujo juízo terá competência absoluta para processar a causa,… |
| Art. 81 | 837 | Para as ações cíveis fundadas em interesses difusos, coletivos, individuais indisponíveis ou homogêneos, consideram-se legitimados, concorrentemente: |
| Art. 82 | 851 | Para defesa dos interesses e direitos protegidos por esta Lei, são admissíveis todas as espécies de ação pertinentes. |
| Art. 83 | 855 | Na ação que tenha por objeto o cumprimento de obrigação de fazer ou não-fazer, o juiz concederá a tutela específica da obrigação ou determinará… |
| Art. 84 (revogado) | 863 | Os valores das multas previstas nesta Lei reverterão ao Fundo do Idoso, onde houver, ou na falta deste, ao Fundo Municipal de Assistência Social,… |
| Art. 84 | 865 | Os valores das multas previstas nesta Lei reverterão ao Fundo da Pessoa Idosa, onde houver, ou na falta deste, ao Fundo Municipal de Assistência… |
| Art. 85 | 869 | O juiz poderá conferir efeito suspensivo aos recursos, para evitar dano irreparável à parte. |
| Art. 86 | 871 | Transitada em julgado a sentença que impuser condenação ao Poder Público, o juiz determinará a remessa de peças à autoridade competente, para… |
| Art. 87 (revogado) | 873 | Decorridos 60 (sessenta) dias do trânsito em julgado da sentença condenatória favorável ao idoso sem que o autor lhe promova a execução, deverá… |
| Art. 87 | 875 | Decorridos 60 (sessenta) dias do trânsito em julgado da sentença condenatória favorável à pessoa idosa sem que o autor lhe promova a execução, deverá… |
| Art. 88 | 877 | Nas ações de que trata este Capítulo, não haverá adiantamento de custas, emolumentos, honorários periciais e quaisquer outras despesas. |
| Art. 89 | 881 | Qualquer pessoa poderá, e o servidor deverá, provocar a iniciativa do Ministério Público, prestando-lhe informações sobre os fatos que constituam… |
| Art. 90 (revogado) | 883 | Os agentes públicos em geral, os juízes e tribunais, no exercício de suas funções, quando tiverem conhecimento de fatos que possam configurar crime… |
| Art. 90 | 885 | Os agentes públicos em geral, os juízes e tribunais, no exercício de suas funções, quando tiverem conhecimento de fatos que possam configurar crime… |
| Art. 91 | 887 | Para instruir a petição inicial, o interessado poderá requerer às autoridades competentes as certidões e informações que julgar necessárias, que… |
| Art. 92 | 889 | O Ministério Público poderá instaurar sob sua presidência, inquérito civil, ou requisitar, de qualquer pessoa, organismo público ou particular,… |
| Art. 93 | 903 | Aplicam-se subsidiariamente, no que couber, as disposições da Lei no 7.347, de 24 de julho de 1985. |
| Art. 94 (revogado) | 905 | Aos crimes previstos nesta Lei, cuja pena máxima privativa de liberdade não ultrapasse 4 (quatro) anos, aplica-se o procedimento previsto na Lei no… |
| Art. 94 | 907 | Aos crimes previstos nesta Lei aplicam-se, no que couber, as disposições do Decreto-Lei nº 2.848, de 7 de dezembro de 1940 (Código Penal), e do… |
| Art. 95 | 913 | Os crimes definidos nesta Lei são de ação penal pública incondicionada, não se lhes aplicando os arts. 181 e 182 do Código Penal. |
| Art. 96 | 915 | Discriminar pessoa idosa, impedindo ou dificultando seu acesso a operações bancárias, aos meios de transporte, ao direito de contratar ou por… |
| Art. 97 (revogado) | 927 | Deixar de prestar assistência ao idoso, quando possível fazê-lo sem risco pessoal, em situação de iminente perigo, ou recusar, retardar ou dificultar… |
| Art. 97 | 929 | Deixar de prestar assistência à pessoa idosa, quando possível fazê-lo sem risco pessoal, em situação de iminente perigo, ou recusar, retardar ou… |
| Art. 98 (revogado) | 935 | Abandonar o idoso em hospitais, casas de saúde, entidades de longa permanência, ou congêneres, ou não prover suas necessidades básicas, quando… |
| Art. 98 | 937 | Abandonar a pessoa idosa em hospitais, casas de saúde, entidades de longa permanência, ou congêneres, ou não prover suas necessidades básicas, quando… |
| Art. 99 (revogado) | 941 | Expor a perigo a integridade e a saúde, física ou psíquica, do idoso, submetendo-o a condições desumanas ou degradantes ou privando-o de alimentos e… |
| Art. 99 | 943 | Expor a perigo a integridade e a saúde, física ou psíquica, da pessoa idosa, submetendo-a a condições desumanas ou degradantes ou privando-a de… |
| Art. 100 | 961 | Constitui crime punível com reclusão de 6 (seis) meses a 1 (um) ano e multa: |
| Art. 101 (revogado) | 973 | Deixar de cumprir, retardar ou frustrar, sem justo motivo, a execução de ordem judicial expedida nas ações em que for parte ou interveniente o idoso: |
| Art. 101 | 975 | Deixar de cumprir, retardar ou frustrar, sem justo motivo, a execução de ordem judicial expedida nas ações em que for parte ou interveniente a pessoa… |
| Art. 102 (revogado) | 979 | Apropriar-se de ou desviar bens, proventos, pensão ou qualquer outro rendimento do idoso, dando-lhes aplicação diversa da de sua finalidade: |
| Art. 102 | 981 | Apropriar-se de ou desviar bens, proventos, pensão ou qualquer outro rendimento da pessoa idosa, dando-lhes aplicação diversa da de sua finalidade: |
| Art. 103 (revogado) | 985 | Negar o acolhimento ou a permanência do idoso, como abrigado, por recusa deste em outorgar procuração à entidade de atendimento: |
| Art. 103 | 987 | Negar o acolhimento ou a permanência da pessoa idosa, como abrigada, por recusa desta em outorgar procuração à entidade de atendimento: |
| Art. 104 (revogado) | 991 | Reter o cartão magnético de conta bancária relativa a benefícios, proventos ou pensão do idoso, bem como qualquer outro documento com objetivo de… |
| Art. 104 | 993 | Reter o cartão magnético de conta bancária relativa a benefícios, proventos ou pensão da pessoa idosa, bem como qualquer outro documento com objetivo… |
| Art. 105 (revogado) | 997 | Exibir ou veicular, por qualquer meio de comunicação, informações ou imagens depreciativas ou injuriosas à pessoa do idoso: |
| Art. 105 | 999 | Exibir ou veicular, por qualquer meio de comunicação, informações ou imagens depreciativas ou injuriosas à pessoa idosa: |
| Art. 106 | 1003 | Induzir pessoa idosa sem discernimento de seus atos a outorgar procuração para fins de administração de bens ou deles dispor livremente: |
| Art. 107 (revogado) | 1007 | Coagir, de qualquer modo, o idoso a doar, contratar, testar ou outorgar procuração: |
| Art. 107 | 1009 | Coagir, de qualquer modo, a pessoa idosa a doar, contratar, testar ou outorgar procuração: |
| Art. 108 | 1013 | Lavrar ato notarial que envolva pessoa idosa sem discernimento de seus atos, sem a devida representação legal: |
| Art. 109 | 1019 | Impedir ou embaraçar ato do representante do Ministério Público ou de qualquer outro agente fiscalizador: |
| Art. 110 | 1023 | O Decreto-Lei nº 2.848, de 7 de dezembro de 1940, Código Penal, passa a vigorar com as seguintes alterações: |
| Art. 111 | 1099 | O O art. 21 do Decreto-Lei no 3.688, de 3 de outubro de 1941, Lei das Contravenções Penais, passa a vigorar acrescido do seguinte parágrafo único: |
| Art. 112 | 1107 | O inciso II do § 4o do art. 1o da Lei no 9.455, de 7 de abril de 1997, passa a vigorar com a seguinte redação: |
| Art. 113 | 1119 | O inciso III do art. 18 da Lei no 6.368, de 21 de outubro de 1976, passa a vigorar com a seguinte redação: |
| Art. 114 | 1129 | O art 1º da Lei no 10.048, de 8 de novembro de 2000, passa a vigorar com a seguinte redação: |
| Art. 115 (revogado) | 1133 | O Orçamento da Seguridade Social destinará ao Fundo Nacional de Assistência Social, até que o Fundo Nacional do Idoso seja criado, os recursos… |
| Art. 115 | 1135 | O Orçamento da Seguridade Social destinará ao Fundo Nacional de Assistência Social, até que o Fundo Nacional da Pessoa Idosa seja criado, os recursos… |
| Art. 116 | 1137 | Serão incluídos nos censos demográficos dados relativos à população idosa do País. |
| Art. 117 | 1139 | O Poder Executivo encaminhará ao Congresso Nacional projeto de lei revendo os critérios de concessão do Benefício de Prestação Continuada previsto na… |
| Art. 118 | 1141 | Esta Lei entra em vigor decorridos 90 (noventa) dias da sua publicação, ressalvado o disposto no caput do art. 36, que vigorará a partir de 1o de… |

## Lei nº 14.905/2024 — Atualização monetária e juros

`lei-14905.md` · 90 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 15 | Esta Lei altera a Lei nº 10.406, de 10 de janeiro de 2002 (Código Civil), para dispor sobre atualização monetária e juros. |
| Art. 2º | 17 | A Lei nº 10.406, de 10 de janeiro de 2002 (Código Civil), passa a vigorar com as seguintes alterações: |
| Art. 3º | 57 | Não se aplica o disposto no Decreto nº 22.626, de 7 de abril de 1933, às obrigações: |
| Art. 4º | 75 | O Banco Central do Brasil disponibilizará aplicação interativa, de acesso público, que permita simular o uso da taxa de juros legal estabelecida no… |
| Art. 5º | 77 | Esta Lei entra em vigor na data de sua publicação e produzirá efeitos: |

## Lei nº 9.099/1995 — Juizados Especiais

`lei-9099.md` · 640 linhas

| Dispositivo | Linha | Início do texto |
|---|---|---|
| Art. 1º | 19 | Os Juizados Especiais Cíveis e Criminais, órgãos da Justiça Ordinária, serão criados pela União, no Distrito Federal e nos Territórios, e pelos… |
| Art. 2º | 21 | O processo orientar-se-á pelos critérios da oralidade, simplicidade, informalidade, economia processual e celeridade, buscando, sempre que possível,… |
| Art. 3º | 31 | O Juizado Especial Cível tem competência para conciliação, processo e julgamento das causas cíveis de menor complexidade, assim consideradas: |
| Art. 4º | 51 | É competente, para as causas previstas nesta Lei, o Juizado do foro: |
| Art. 5º | 65 | O Juiz dirigirá o processo com liberdade para determinar as provas a serem produzidas, para apreciá-las e para dar especial valor às regras de… |
| Art. 6º | 67 | O Juiz adotará em cada caso a decisão que reputar mais justa e equânime, atendendo aos fins sociais da lei e às exigências do bem comum. |
| Art. 7º | 69 | Os conciliadores e Juízes leigos são auxiliares da Justiça, recrutados, os primeiros, preferentemente, entre os bacharéis em Direito, e os segundos,… |
| Art. 8º | 77 | Não poderão ser partes, no processo instituído por esta Lei, o incapaz, o preso, as pessoas jurídicas de direito público, as empresas públicas da… |
| Art. 9º | 95 | Nas causas de valor até vinte salários mínimos, as partes comparecerão pessoalmente, podendo ser assistidas por advogado; nas de valor superior, a… |
| Art. 10 | 107 | Não se admitirá, no processo, qualquer forma de intervenção de terceiro nem de assistência. Admitir-se-á o litisconsórcio. |
| Art. 11 | 109 | O Ministério Público intervirá nos casos previstos em lei. |
| Art. 12 | 115 | Os atos processuais serão públicos e poderão realizar-se em horário noturno, conforme dispuserem as normas de organização judiciária. |
| Art. 12-A | 117 | Na contagem de prazo em dias, estabelecido por lei ou pelo juiz, para a prática de qualquer ato processual, inclusive para a interposição de… |
| Art. 13 | 119 | Os atos processuais serão válidos sempre que preencherem as finalidades para as quais forem realizados, atendidos os critérios indicados no art. 2º… |
| Art. 14 | 133 | O processo instaurar-se-á com a apresentação do pedido, escrito ou oral, à Secretaria do Juizado. |
| Art. 15 | 147 | Os pedidos mencionados no art. 3º desta Lei poderão ser alternativos ou cumulados; nesta última hipótese, desde que conexos e a soma não ultrapasse o… |
| Art. 16 | 149 | Registrado o pedido, independentemente de distribuição e autuação, a Secretaria do Juizado designará a sessão de conciliação, a realizar-se no prazo… |
| Art. 17 | 151 | Comparecendo inicialmente ambas as partes, instaurar-se-á, desde logo, a sessão de conciliação, dispensados o registro prévio de pedido e a citação. |
| Art. 18 | 159 | A citação far-se-á: |
| Art. 19 | 173 | As intimações serão feitas na forma prevista para citação, ou por qualquer outro meio idôneo de comunicação. |
| Art. 20 | 183 | Não comparecendo o demandado à sessão de conciliação ou à audiência de instrução e julgamento, reputar-se-ão verdadeiros os fatos alegados no pedido… |
| Art. 21 | 189 | Aberta a sessão, o Juiz togado ou leigo esclarecerá as partes presentes sobre as vantagens da conciliação, mostrando-lhes os riscos e as… |
| Art. 22 | 191 | A conciliação será conduzida pelo Juiz togado ou leigo ou por conciliador sob sua orientação. |
| Art. 23 (revogado) | 199 | Não comparecendo o demandado, o Juiz togado proferirá sentença. |
| Art. 23 | 201 | Se o demandado não comparecer ou recusar-se a participar da tentativa de conciliação não presencial, o Juiz togado proferirá sentença. |
| Art. 24 | 203 | Não obtida a conciliação, as partes poderão optar, de comum acordo, pelo juízo arbitral, na forma prevista nesta Lei. |
| Art. 25 | 209 | O árbitro conduzirá o processo com os mesmos critérios do Juiz, na forma dos arts. 5º e 6º desta Lei, podendo decidir por eqüidade. |
| Art. 26 | 211 | Ao término da instrução, ou nos cinco dias subseqüentes, o árbitro apresentará o laudo ao Juiz togado para homologação por sentença irrecorrível. |
| Art. 27 | 217 | Não instituído o juízo arbitral, proceder-se-á imediatamente à audiência de instrução e julgamento, desde que não resulte prejuízo para a defesa. |
| Art. 28 | 221 | Na audiência de instrução e julgamento serão ouvidas as partes, colhida a prova e, em seguida, proferida a sentença. |
| Art. 29 | 223 | Serão decididos de plano todos os incidentes que possam interferir no regular prosseguimento da audiência. As demais questões serão decididas na… |
| Art. 30 | 231 | A contestação, que será oral ou escrita, conterá toda matéria de defesa, exceto argüição de suspeição ou impedimento do Juiz, que se processará na… |
| Art. 31 | 233 | Não se admitirá a reconvenção. É lícito ao réu, na contestação, formular pedido em seu favor, nos limites do art. 3º desta Lei, desde que fundado nos… |
| Art. 32 | 241 | Todos os meios de prova moralmente legítimos, ainda que não especificados em lei, são hábeis para provar a veracidade dos fatos alegados pelas partes. |
| Art. 33 | 243 | Todas as provas serão produzidas na audiência de instrução e julgamento, ainda que não requeridas previamente, podendo o Juiz limitar ou excluir as… |
| Art. 34 | 245 | As testemunhas, até o máximo de três para cada parte, comparecerão à audiência de instrução e julgamento levadas pela parte que as tenha arrolado,… |
| Art. 35 | 251 | Quando a prova do fato exigir, o Juiz poderá inquirir técnicos de sua confiança, permitida às partes a apresentação de parecer técnico. |
| Art. 36 | 255 | A prova oral não será reduzida a escrito, devendo a sentença referir, no essencial, os informes trazidos nos depoimentos. |
| Art. 37 | 257 | A instrução poderá ser dirigida por Juiz leigo, sob a supervisão de Juiz togado. |
| Art. 38 | 263 | A sentença mencionará os elementos de convicção do Juiz, com breve resumo dos fatos relevantes ocorridos em audiência, dispensado o relatório. |
| Art. 39 | 267 | É ineficaz a sentença condenatória na parte que exceder a alçada estabelecida nesta Lei. |
| Art. 40 | 269 | O Juiz leigo que tiver dirigido a instrução proferirá sua decisão e imediatamente a submeterá ao Juiz togado, que poderá homologá-la, proferir outra… |
| Art. 41 | 271 | Da sentença, excetuada a homologatória de conciliação ou laudo arbitral, caberá recurso para o próprio Juizado. |
| Art. 42 | 277 | O recurso será interposto no prazo de dez dias, contados da ciência da sentença, por petição escrita, da qual constarão as razões e o pedido do… |
| Art. 43 | 283 | O recurso terá somente efeito devolutivo, podendo o Juiz dar-lhe efeito suspensivo, para evitar dano irreparável para a parte. |
| Art. 44 | 285 | As partes poderão requerer a transcrição da gravação da fita magnética a que alude o § 3º do art. 13 desta Lei, correndo por conta do requerente as… |
| Art. 45 | 287 | As partes serão intimadas da data da sessão de julgamento. |
| Art. 46 | 289 | O julgamento em segunda instância constará apenas da ata, com a indicação suficiente do processo, fundamentação sucinta e parte dispositiva. Se a… |
| Art. 47 | 291 | (VETADO) |
| Art. 48 (revogado) | 297 | Caberão embargos de declaração quando, na sentença ou acórdão, houver obscuridade, contradição, omissão ou dúvida. |
| Art. 48 | 299 | Caberão embargos de declaração contra sentença ou acórdão nos casos previstos no Código de Processo Civil. |
| Art. 49 | 303 | Os embargos de declaração serão interpostos por escrito ou oralmente, no prazo de cinco dias, contados da ciência da decisão. |
| Art. 50 (revogado) | 305 | Quando interpostos contra sentença, os embargos de declaração suspenderão o prazo para recurso. |
| Art. 50 | 307 | Os embargos de declaração interrompem o prazo para a interposição de recurso. |
| Art. 51 | 313 | Extingue-se o processo, além dos casos previstos em lei: |
| Art. 52 | 335 | A execução da sentença processar-se-á no próprio Juizado, aplicando-se, no que couber, o disposto no Código de Processo Civil, com as seguintes… |
| Art. 53 | 363 | A execução de título executivo extrajudicial, no valor de até quarenta salários mínimos, obedecerá ao disposto no Código de Processo Civil, com as… |
| Art. 54 | 377 | O acesso ao Juizado Especial independerá, em primeiro grau de jurisdição, do pagamento de custas, taxas ou despesas. |
| Art. 55 | 381 | A sentença de primeiro grau não condenará o vencido em custas e honorários de advogado, ressalvados os casos de litigância de má-fé. Em segundo grau,… |
| Art. 56 | 395 | Instituído o Juizado Especial, serão implantadas as curadorias necessárias e o serviço de assistência judiciária. |
| Art. 57 | 397 | O acordo extrajudicial, de qualquer natureza ou valor, poderá ser homologado, no juízo competente, independentemente de termo, valendo a sentença… |
| Art. 58 | 401 | As normas de organização judiciária local poderão estender a conciliação prevista nos arts. 22 e 23 a causas não abrangidas por esta Lei. |
| Art. 59 | 403 | Não se admitirá ação rescisória nas causas sujeitas ao procedimento instituído por esta Lei. |
| Art. 60 (revogado) | 411 | O Juizado Especial Criminal, provido por Juízes togados ou togados e leigos, tem competência para a conciliação, o julgamento e a execução das… |
| Art. 60 | 413 | O Juizado Especial Criminal, provido por juízes togados ou togados e leigos, tem competência para a conciliação, o julgamento e a execução das… |
| Art. 61 (revogado) | 417 | Consideram-se infrações penais de menor potencial ofensivo, para os efeitos desta Lei, as contravenções penais e os crimes a que a lei comine pena… |
| Art. 61 | 419 | Consideram-se infrações penais de menor potencial ofensivo, para os efeitos desta Lei, as contravenções penais e os crimes a que a lei comine pena… |
| Art. 62 (revogado) | 421 | O processo perante o Juizado Especial orientar-se-á pelos critérios da oralidade, informalidade, economia processual e celeridade, objetivando,… |
| Art. 62 | 423 | O processo perante o Juizado Especial orientar-se-á pelos critérios da oralidade, simplicidade, informalidade, economia processual e celeridade,… |
| Art. 63 | 429 | A competência do Juizado será determinada pelo lugar em que foi praticada a infração penal. |
| Art. 64 | 431 | Os atos processuais serão públicos e poderão realizar-se em horário noturno e em qualquer dia da semana, conforme dispuserem as normas de organização… |
| Art. 65 | 433 | Os atos processuais serão válidos sempre que preencherem as finalidades para as quais foram realizados, atendidos os critérios indicados no art. 62… |
| Art. 66 | 441 | A citação será pessoal e far-se-á no próprio Juizado, sempre que possível, ou por mandado. |
| Art. 67 | 445 | A intimação far-se-á por correspondência, com aviso de recebimento pessoal ou, tratando-se de pessoa jurídica ou firma individual, mediante entrega… |
| Art. 68 | 449 | Do ato de intimação do autor do fato e do mandado de citação do acusado, constará a necessidade de seu comparecimento acompanhado de advogado, com a… |
| Art. 69 | 455 | A autoridade policial que tomar conhecimento da ocorrência lavrará termo circunstanciado e o encaminhará imediatamente ao Juizado, com o autor do… |
| Art. 70 | 461 | Comparecendo o autor do fato e a vítima, e não sendo possível a realização imediata da audiência preliminar, será designada data próxima, da qual… |
| Art. 71 | 463 | Na falta do comparecimento de qualquer dos envolvidos, a Secretaria providenciará sua intimação e, se for o caso, a do responsável civil, na forma… |
| Art. 72 | 465 | Na audiência preliminar, presente o representante do Ministério Público, o autor do fato e a vítima e, se possível, o responsável civil, acompanhados… |
| Art. 73 | 467 | A conciliação será conduzida pelo Juiz ou por conciliador sob sua orientação. |
| Art. 74 | 471 | A composição dos danos civis será reduzida a escrito e, homologada pelo Juiz mediante sentença irrecorrível, terá eficácia de título a ser executado… |
| Art. 75 | 475 | Não obtida a composição dos danos civis, será dada imediatamente ao ofendido a oportunidade de exercer o direito de representação verbal, que será… |
| Art. 76 | 479 | Havendo representação ou tratando-se de crime de ação penal pública incondicionada, não sendo caso de arquivamento, o Ministério Público poderá… |
| Art. 77 | 503 | Na ação penal de iniciativa pública, quando não houver aplicação de pena, pela ausência do autor do fato, ou pela não ocorrência da hipótese prevista… |
| Art. 78 | 511 | Oferecida a denúncia ou queixa, será reduzida a termo, entregando-se cópia ao acusado, que com ela ficará citado e imediatamente cientificado da… |
| Art. 79 | 519 | No dia e hora designados para a audiência de instrução e julgamento, se na fase preliminar não tiver havido possibilidade de tentativa de conciliação… |
| Art. 80 | 521 | Nenhum ato será adiado, determinando o Juiz, quando imprescindível, a condução coercitiva de quem deva comparecer. |
| Art. 81 | 523 | Aberta a audiência, será dada a palavra ao defensor para responder à acusação, após o que o Juiz receberá, ou não, a denúncia ou queixa; havendo… |
| Art. 82 | 537 | Da decisão de rejeição da denúncia ou queixa e da sentença caberá apelação, que poderá ser julgada por turma composta de três Juízes em exercício no… |
| Art. 83 (revogado) | 549 | Caberão embargos de declaração quando, em sentença ou acórdão, houver obscuridade, contradição, omissão ou dúvida. |
| Art. 83 | 551 | Cabem embargos de declaração quando, em sentença ou acórdão, houver obscuridade, contradição ou omissão. |
| Art. 84 | 565 | Aplicada exclusivamente pena de multa, seu cumprimento far-se-á mediante pagamento na Secretaria do Juizado. |
| Art. 85 | 569 | Não efetuado o pagamento de multa, será feita a conversão em pena privativa da liberdade, ou restritiva de direitos, nos termos previstos em lei. |
| Art. 86 | 571 | A execução das penas privativas de liberdade e restritivas de direitos, ou de multa cumulada com estas, será processada perante o órgão competente,… |
| Art. 87 | 577 | Nos casos de homologação do acordo civil e aplicação de pena restritiva de direitos ou multa (arts. 74 e 76, § 4º), as despesas processuais serão… |
| Art. 88 | 583 | Além das hipóteses do Código Penal e da legislação especial, dependerá de representação a ação penal relativa aos crimes de lesões corporais leves e… |
| Art. 89 | 585 | Nos crimes em que a pena mínima cominada for igual ou inferior a um ano, abrangidas ou não por esta Lei, o Ministério Público, ao oferecer a… |
| Art. 90 | 609 | As disposições desta Lei não se aplicam aos processos penais cuja instrução já estiver iniciada. |
| Art. 90-A | 611 | As disposições desta Lei não se aplicam no âmbito da Justiça Militar. (Artigo incluído pela Lei nº 9.839, de 27.9.1999) |
| Art. 91 | 613 | Nos casos em que esta Lei passa a exigir representação para a propositura da ação penal pública, o ofendido ou seu representante legal será intimado… |
| Art. 92 | 615 | Aplicam-se subsidiariamente as disposições dos Códigos Penal e de Processo Penal, no que não forem incompatíveis com esta Lei. |
| Art. 93 | 621 | Lei Estadual disporá sobre o Sistema de Juizados Especiais Cíveis e Criminais, sua organização, composição e competência. |
| Art. 94 | 623 | Os serviços de cartório poderão ser prestados, e as audiências realizadas fora da sede da Comarca, em bairros ou cidades a ela pertencentes, ocupando… |
| Art. 95 | 625 | Os Estados, Distrito Federal e Territórios criarão e instalarão os Juizados Especiais no prazo de seis meses, a contar da vigência desta Lei. |
| Art. 96 | 629 | Esta Lei entra em vigor no prazo de sessenta dias após a sua publicação. |
| Art. 97 | 631 | Ficam revogadas a Lei nº 4.611, de 2 de abril de 1965 e a Lei nº 7.244, de 7 de novembro de 1984. |
