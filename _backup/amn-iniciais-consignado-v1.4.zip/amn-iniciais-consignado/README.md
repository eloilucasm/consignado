# AMN — Iniciais de Consignado (v1.4)

Pacote com cinco skills do Claude Code para a produção de iniciais de fraude em
consignado INSS. Elas foram feitas para rodar em sequência:

1. **`/triagem-consignado`**: cruza a *Análise Jurídico-Documental* com o *Termo de
   Responsabilidade* e com os extratos do INSS e gera a **ficha de ajuizamento**
   (`ficha.md` + `ficha.json`).
2. **`/redacao-nao-contratado`**: a partir da ficha aprovada, gera as iniciais do
   modelo **Emp. Não Contratado** (blocos B, C e Caixa) em .docx timbrado, com uma
   ficha de conferência para cada peça.
3. **`/redacao-migrado`**: o mesmo, para o bloco A, nos modelos **Emp. Migrados Ativos
   C/ Liminar** e **Inativos S/ Liminar**. Ativo ou inativo é decidido pelo extrato.
4. **`/redacao-tese1000`**: o mesmo, para o bloco E (**Tese 1000 Contra**). Localiza
   no extrato o contrato derivado e o contrato-raiz e preenche os diagramas.
5. **`/redacao-rmc`**: o mesmo, para o bloco D (**Nulidade de Refinanciamento de cartão
   RMC/RCC — Lei Desenrola**). Lê no extrato o histórico do cartão, detecta o
   refinanciamento e calcula o marco de 200%. Se o extrato não trouxer o histórico
   completo, a skill não redige e pede o HISCRE ou as faturas.

## Instalação

**Requisitos:** Python 3 e a biblioteca `pypdf`.

```bash
pip3 install pypdf
```

**Opção A, como plugin.** Coloque a pasta `amn-iniciais-consignado` onde o seu
Claude Code carrega plugins locais (ou num marketplace interno) e ative o plugin.

**Opção B, como skills soltas.** Copie as cinco pastas de `skills/` para
`~/.claude/skills/`. Elas precisam ficar **lado a lado**: a redação usa as tabelas da
triagem, e as de migrado, Tese 1000 e RMC usam o motor de geração da de não contratado.

## Regras do escritório já embutidas

- Só entra contrato que está no termo. O que não está no termo não é ajuizado, e a triagem não pergunta.
- O texto do termo é sempre limpo antes do cruzamento: páginas juntadas, rodapé do ZapSign removido e números quebrados entre páginas recompostos.
- Um processo por **benefício + banco + tese**. Mesmo banco, mesma tese e mesmo benefício juntam num processo, mesmo com anos e blocos diferentes.
- Mesmo banco em outro benefício, ou em outra tese, gera o tópico de **ausência de litispendência**.
- Modelos: A ativo → Migrados Ativos C/ Liminar · A excluído → Migrados Inativos S/ Liminar · B/C → Não Contratado · Caixa → Não Contratado (ativo com liminar) · E → Tese 1000 Contra · D → Nulidade de Refinanciamento RMC (Desenrola).
- Juízo: réu Caixa → **Vara Federal** da (sub)seção do TRF1. Demais réus → **Vara Cível** da comarca do TJBA. As duas tabelas estão em `triagem-consignado/dados/`.
- Dano moral de R$ 20.000,00. Valor da causa = restituição em dobro + dano moral.
- Tópico de prescrição decenal quando houver desconto com mais de 5 anos. As citações saem marcadas com `[VERIFICAR ANTES DE PROTOCOLAR]`.

## Arquivos de dados (manter atualizados)

| Arquivo | Conteúdo |
|---|---|
| `triagem-consignado/dados/reus.json` | CNPJ e endereço dos réus (5 por enquanto). **Acrescente novos réus aqui.** Réu ausente sai como `[CONFERIR]` na peça. |
| `triagem-consignado/dados/tjba_comarcas.json` | Município → comarca (TJBA, 417 municípios) |
| `triagem-consignado/dados/trf1_jurisdicao.json` | Município → seção/subseção (TRF1) |
| `redacao-nao-contratado/assets/modelo_formatado_amn.docx` | Base de formatação e timbre (sem dados de cliente) |

## Observação

Todas as teses da análise (blocos A, B, C, Caixa, D e E) já têm agente de redação.
