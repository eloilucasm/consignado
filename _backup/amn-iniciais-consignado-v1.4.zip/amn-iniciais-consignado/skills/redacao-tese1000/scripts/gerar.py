#!/usr/bin/env python3
"""Gera a inicial da TESE 1000 CONTRA (.docx timbrado do AMN) para um processo da
ficha de ajuizamento (tese TESE_1000, bloco E da análise).

Uso:
  python3 gerar.py --ficha ficha.json --processo N --extrato EXTRATO_DO_NB.pdf \
                   --qualificacao qualificacao.json --saida PASTA [--data AAAA-MM-DD] \
                   [--complemento complemento.json]

complemento.json (opcional), para o que o extrato não traz ou exige leitura humana:
  {"paragrafos_fatos": ["parágrafo extra, inserido ao fim da narrativa dos fatos", ...]}

Texto-base: inicial protocolada mais recente da tese (Maria x BNP, Vara Cível) sobre o
modelo do escritório; diagramas (anatomia, linha do tempo, quadro da IN 138/2022)
copiados de assets/modelo_tese1000.docx e preenchidos com os dados do extrato.
Timbre, juízo, réu, qualificação, cálculos e assinatura: os mesmos do motor da
redacao-nao-contratado.
"""
import argparse
import datetime as dt
import json
import re
import sys
import zipfile
from pathlib import Path

AQUI = Path(__file__).resolve().parent
MODELO_T1000 = AQUI.parent / "assets" / "modelo_tese1000.docx"
MOTOR = AQUI.parent.parent / "redacao-nao-contratado" / "scripts"
if not MOTOR.exists():
    MOTOR = Path.home() / ".claude/skills/redacao-nao-contratado/scripts"
sys.path.insert(0, str(MOTOR))
import gerar as M  # noqa: E402
ext = M.ext

ROMANOS = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI", "XII"]
VERIF = " [VERIFICAR ANTES DE PROTOCOLAR]"


LARGURA_TEXTO = 9638   # área útil da página no timbre AMN (11906 - 2 x 1133 de margem)
LARGURA_CAIXA = 7400   # caixas do fluxograma: todas iguais e centralizadas


def normalizar_tabela(tbl):
    """Padroniza as tabelas do modelo da Tese 1000 no timbre AMN: caixas de uma
    coluna com largura única e centralizadas; tabelas de várias colunas na largura
    total da página, colunas proporcionais; layout fixo (não deixa o Word "encolher")."""
    grid = [int(g) for g in re.findall(r'<w:gridCol w:w="(\d+)"', tbl)]
    if not grid:
        return tbl
    alvo = LARGURA_CAIXA if len(grid) == 1 else LARGURA_TEXTO
    fator = alvo / sum(grid)
    novos = [round(g * fator) for g in grid]
    novos[-1] += alvo - sum(novos)
    it = iter(novos)
    tbl = re.sub(r'<w:gridCol w:w="\d+"/>', lambda _: f'<w:gridCol w:w="{next(it)}"/>', tbl)
    # largura de cada célula = soma das colunas da grade que ela ocupa (gridSpan)
    def linha(m):
        tr = m.group(0)
        pos = [0]

        def cel(mc):
            tc = mc.group(0)
            sp = re.search(r'<w:gridSpan w:val="(\d+)"/>', tc)
            n = int(sp.group(1)) if sp else 1
            larg = sum(novos[pos[0]:pos[0] + n]) or novos[-1]
            pos[0] += n
            if "<w:tcW " in tc:
                return re.sub(r'<w:tcW w:w="\d+" w:type="\w+"/>', f'<w:tcW w:w="{larg}" w:type="dxa"/>', tc, count=1)
            return tc.replace("<w:tcPr>", f'<w:tcPr><w:tcW w:w="{larg}" w:type="dxa"/>', 1)
        return re.sub(r"<w:tc>.*?</w:tc>", cel, tr, flags=re.S)
    tbl = re.sub(r"<w:tr[ >].*?</w:tr>", linha, tbl, flags=re.S)
    tbl = re.sub(r'<w:tblW w:w="\d+" w:type="\w+"/>', f'<w:tblW w:w="{alvo}" w:type="dxa"/>', tbl, count=1)
    tbl = re.sub(r"<w:jc w:val=\"\w+\"/>(?=[^<]*(?:<(?!/w:tblPr)[^<]*)*</w:tblPr>)", "", tbl, count=0)
    tbl = re.sub(r"<w:tblLayout [^>]*/>", "", tbl)
    tbl = tbl.replace("</w:tblBorders>", '</w:tblBorders><w:tblLayout w:type="fixed"/>', 1) \
        if "</w:tblBorders>" in tbl else tbl.replace("<w:tblPr>", '<w:tblPr><w:tblLayout w:type="fixed"/>', 1)
    # ordem do esquema OOXML em tblPr: tblStyle, tblW, jc, ..., tblBorders, tblLayout, tblCellMar, tblLook
    tbl = re.sub(r'(<w:tblW w:w="\d+" w:type="dxa"/>)', r'\1<w:jc w:val="center"/>', tbl, count=1)
    return tbl


def blocos_t1000():
    with zipfile.ZipFile(MODELO_T1000) as z:
        x = z.read("word/document.xml").decode("utf-8")
    corpo = x[x.index("<w:body>") + 8:x.index("<w:sectPr", x.index("<w:body>"))]
    blocos = []
    for m in re.finditer(r"<w:p[ >].*?</w:p>|<w:tbl>.*?</w:tbl>", corpo, re.S):
        b = M.limpar_ids(m.group(0))
        b = b.replace('<w:color w:val="EE0000"/>', "")      # vermelho = marcação de campo no modelo
        if b.startswith("<w:tbl>"):
            b = normalizar_tabela(b)
        blocos.append(b)
    return blocos


def celulas_texto(tbl, textos_por_celula):
    """Troca o texto de cada parágrafo de cada célula, na ordem, mantendo a formatação.
    textos_por_celula: lista (uma por célula) de listas de textos (um por parágrafo);
    None mantém a célula como está."""
    tcs = re.findall(r"<w:tc>.*?</w:tc>", tbl, re.S)
    novo = tbl
    for tc, textos in zip(tcs, textos_por_celula):
        if textos is None:
            continue
        ps = re.findall(r"<w:p[ >].*?</w:p>", tc, re.S)
        tc_novo = tc
        for p, t in zip(ps, textos + [""] * (len(ps) - len(textos))):
            r = M.rprs(p)
            p_novo = f"<w:p>{M.ppr(p)}{M.run(t, r[0] if r else '') if t else ''}</w:p>"
            tc_novo = tc_novo.replace(p, p_novo, 1)
        novo = novo.replace(tc, tc_novo, 1)
    return novo


def dias(d1, d2):
    f = lambda s: dt.datetime.strptime(s, "%d/%m/%y" if len(s) == 8 else "%d/%m/%Y").date()
    return (f(d2) - f(d1)).days


def data4(d):
    return f"{d[:6]}20{d[6:]}" if d and len(d) == 8 else (d or M.CONFERIR)


def raiz_de(numero):
    m = re.match(r"^(.*?)[ _]+0*(\d{1,4})$", numero.strip())
    return (m.group(1), "_" + numero.strip().split("_")[-1]) if m else (None, None)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ficha", required=True)
    ap.add_argument("--processo", type=int, required=True)
    ap.add_argument("--extrato", required=True)
    ap.add_argument("--qualificacao", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--data", default=dt.date.today().isoformat())
    ap.add_argument("--complemento")
    a = ap.parse_args()

    ficha = json.loads(Path(a.ficha).read_text(encoding="utf-8"))
    proc = next(p for p in ficha["processos"] if p["processo"] == a.processo)
    if proc["tese"] != "TESE_1000":
        sys.exit(f"Processo {a.processo} é da tese {proc['tese']} — este gerador atende só: TESE_1000.")
    q = json.loads(Path(a.qualificacao).read_text(encoding="utf-8"))
    comp_json = json.loads(Path(a.complemento).read_text(encoding="utf-8")) if a.complemento else {}
    hoje = dt.date.fromisoformat(a.data)
    alertas, conferir = [], []
    gen = q.get("genero")
    F = lambda m, f: M.flex(gen, m, f)
    if not gen:
        conferir.append("Gênero do(a) autor(a) não informado — flexões podem estar erradas.")

    # ---- réu
    reu, cod = M.carregar_reu(proc["reu"])
    if not reu:
        reu = {"nome": f"{M.CONFERIR} {proc['reu']}", "artigo": "do",
               "descricao": f"pessoa jurídica de direito privado, inscrito no CNPJ sob o n° {M.CONFERIR}, "
                            f"com endereço na {M.CONFERIR}"}
        conferir.append(f"Réu {proc['reu']} (código {cod}) não está em dados/reus.json — preencher CNPJ e endereço.")

    # ---- contratos derivados e raízes (extrato)
    lista = [r for r in ext.contratos(a.extrato) if r["inicio"]]
    mes_ref = hoje.year * 12 + hoje.month - 2
    derivs = []
    for c in proc["contratos"]:
        occ = ext.buscar(lista, c["contrato"])
        do_reu = [x for x in occ if x["banco"].replace(" ", "").startswith(f"{cod}-")]
        outros = [x for x in occ if x not in do_reu]
        if not do_reu:
            conferir.append(f"Derivado {c['contrato']} não localizado no extrato com o código do réu ({cod}).")
            continue
        r = next((x for x in do_reu if x["secao"] == "ATIVO"), do_reu[-1])
        raiz_num, sufixo = raiz_de(r["contrato"])
        raizes = [x for x in ext.buscar(lista, raiz_num or "") if x["banco"].replace(" ", "").startswith(f"{cod}-")]
        raiz = raizes[-1] if raizes else None
        if not raiz:
            conferir.append(f"Contrato-raiz {raiz_num} do derivado {r['contrato']} não localizado no extrato.")
        ini, fim = M.comp(r["inicio"]), M.comp(r["fim"])
        ativo = r["secao"] == "ATIVO"
        ate = min(fim, mes_ref) if ativo else fim
        qtde = max(0, ate - ini + 1)
        total = round(qtde * r["parcela"], 2)
        intervalo = dias(raiz["exclusao"], r["inclusao"]) if (raiz and raiz.get("exclusao") and r["inclusao"]) else None
        derivs.append({"d": r, "raiz": raiz, "raiz_num": raiz_num, "sufixo": sufixo, "outros": outros,
                       "ativo": ativo, "qtde": qtde, "total": total, "rest": round(2 * total, 2),
                       "ini": ini, "ate": ate, "intervalo": intervalo})
        if qtde and ini < M.comp("04/2021"):
            alertas.append(f"Derivado {r['contrato']}: descontos anteriores a 30/03/2021 — a peça inclui o argumento "
                           f"de má-fé pelo modus operandi (modulação do EAREsp 676.608/RS); conferir.")
        if intervalo is not None and intervalo < 0:
            alertas.append(f"Derivado {r['contrato']}: incluído ANTES da exclusão da raiz — rever a narrativa.")
    if not derivs:
        sys.exit("Nenhum contrato derivado localizado no extrato — nada a gerar.")
    if len({x["raiz_num"] for x in derivs}) > 1:
        alertas.append("Mais de um contrato-raiz no processo: os diagramas mostram só o primeiro — revisar.")
    D0 = derivs[0]
    d0, r0 = D0["d"], D0["raiz"] or {}
    ativos = [x["d"]["contrato"] for x in derivs if x["ativo"]]
    liminar = bool(ativos)
    com_desc = [x for x in derivs if x["qtde"] > 0]
    tot_desc = round(sum(x["total"] for x in derivs), 2)
    tot_rest = round(sum(x["rest"] for x in derivs), 2)
    valor_causa = round(tot_rest + M.DANO_MORAL, 2)
    pre2021 = any(x["qtde"] and x["ini"] < M.comp("04/2021") for x in derivs)
    emissao = M.data_extrato(a.extrato) or M.CONFERIR
    lista_der = ", ".join(f"nº {x['d']['contrato']}" for x in derivs)
    um = len(derivs) == 1
    deriv_txt = f"contrato derivado nº {d0['contrato']}" if um else f"contratos derivados {lista_der}"

    # ---- vocabulário flexionado
    A_ = F("O Autor", "A Autora"); a_ = F("o Autor", "a Autora")
    da_ = F("do Autor", "da Autora"); aa_ = F("ao Autor", "à Autora")
    benef = F("beneficiário", "beneficiária"); cons = F("consumidor", "consumidora")
    da_cons = F("do consumidor", "da consumidora")
    especie = M.especie_fmt(next((e.get("especie") for e in ficha.get("extratos", []) if e.get("nb") == proc["nb"]),
                                 None)) or M.CONFERIR

    # ---- juízo
    comp_txt = proc.get("competencia", "")
    if cod == "104":
        m = re.search(r"((?:Sub)?[Ss]eção Judiciária d[aeo] .+?)(?:/[A-Z]{2})?$", comp_txt)
        enderecamento = (f"AO JUÍZO FEDERAL DA ___ VARA FEDERAL CÍVEL DA "
                         f"{m.group(1).upper() if m else M.CONFERIR}, ESTADO DA BAHIA")
    else:
        m = re.search(r"Comarca de (.+?)/[A-Z]{2}", comp_txt)
        enderecamento = f"AO JUÍZO DA ___ VARA CÍVEL DA COMARCA DE {m.group(1).upper() if m else M.CONFERIR}, ESTADO DA BAHIA"
    if "CONFERIR" in comp_txt or "NÃO" in comp_txt:
        conferir.append(f"Juízo: {comp_txt}")

    # ---- montagem
    cab, B, rod = M.ler_modelo()          # timbre + protótipos AMN
    B = [M.limpar_ids(b) for b in B]
    T = blocos_t1000()                    # diagramas e quadro da tese
    RN = M.rprs(B[48])[0] if M.rprs(B[48]) else ""
    RBB = M.rprs(B[105])[1]
    P_CORPO, P_CIT, P_H1, P_H2, P_PED = B[13], B[33], B[12], B[28], B[96]
    out = []
    n1 = [0]; n2 = [0]

    P_H1 = P_H1 if '<w:jc ' in M.ppr(P_H1) else P_H1.replace("</w:pPr>", '<w:jc w:val="left"/></w:pPr>', 1)

    def h1(nome):
        out.append(M.par(P_H1, [(f"{ROMANOS[n1[0]]} – {nome}", "")])); n1[0] += 1; n2[0] = 0

    def h2(nome):
        n2[0] += 1
        out.append(M.par(P_H2, [(f"            {ROMANOS[n1[0] - 1]}.{n2[0]} – {nome}", "")]))

    def corpo(t):
        out.append(M.par(P_CORPO, [(t, RN)]))

    def ped(segs):
        out.append(M.par(P_PED, [(t, RBB if neg else RN) for t, neg in segs]))

    # cabeçalho
    out.append(M.par(B[0], [(enderecamento, (M.rprs(B[0]) or [""])[0])]))
    out += [B[1], T[2], T[3], T[4]]       # "TRAMITAÇÃO PRIORITÁRIA" / Estatuto do Idoso
    qualif = (f"{M.g(q, 'nome')}, {M.g(q, 'nacionalidade', F('brasileiro', 'brasileira'))}, {M.g(q, 'estado_civil')}, "
              f"{M.g(q, 'profissao')}, {F('inscrito', 'inscrita')} no CPF sob o nº {M.g(q, 'cpf')}, RG nº "
              f"{M.g(q, 'rg')}, {benef} do Regime Geral de Previdência Social sob o benefício nº {proc['nb']} "
              f"({especie}), residente e {F('domiciliado', 'domiciliada')} na {M.g(q, 'endereco')}, CEP "
              f"{M.g(q, 'cep')}, {M.g(q, 'cidade')}/{M.g(q, 'uf', 'BA')}, por intermédio de seus advogados que esta "
              "subscrevem, com procuração anexa e endereço profissional indicado no rodapé, vem, mui respeitosamente, "
              "perante Vossa Excelência, com fundamento no Código de Defesa do Consumidor, no Código de Processo Civil "
              "e nos demais diplomas aplicáveis, propor a presente:")
    if M.CONFERIR in qualif:
        conferir.append("Qualificação com campo(s) [CONFERIR] — completar com os documentos pessoais.")
    out.append(M.par(B[6], [(qualif, (M.rprs(B[6]) or [""])[0])]))
    titulo = "AÇÃO DECLARATÓRIA DE INEXISTÊNCIA DE DÉBITO C/C REPETIÇÃO DO INDÉBITO EM DOBRO C/C INDENIZAÇÃO POR DANOS MORAIS"
    if liminar:
        titulo += ", COM PEDIDO DE TUTELA PROVISÓRIA DE URGÊNCIA"
    out.append(M.par(B[8], [(titulo, (M.rprs(B[8]) or [""])[0])]))
    out.append(M.par(B[9], [(f"em face {reu['artigo']} {reu['nome']}, {reu['descricao']}, pelas razões de fato e de "
                             "direito a seguir expostas.", (M.rprs(B[9]) or [""])[0])]))

    # I – gratuidade
    h1("DA GRATUIDADE DA JUSTIÇA")
    corpo(f"{A_}, pessoa idosa, {M.g(q, 'estado_civil')} e {M.g(q, 'profissao')}, não dispõe de condições econômicas "
          "para arcar com as custas e despesas processuais sem prejuízo do próprio sustento e de sua família, conforme "
          "declaração de hipossuficiência anexa. Requer, por isso, a concessão dos benefícios da gratuidade da justiça, "
          "nos termos do art. 5º, LXXIV, da Constituição Federal e dos arts. 98 e 99, § 3º, do Código de Processo Civil.")

    # litispendência (quando a ficha marcar)
    if proc.get("litispendencia"):
        def _h(nivel, nome):
            h1(nome)
        M.bloco_litispendencia(proc, ficha, _h, corpo)

    # II – fatos
    h1("DOS FATOS")
    periodo = (f"com descontos efetuados em seu benefício nas competências de {M.comp_str(D0['ini'])} a "
               f"{M.comp_str(D0['ate'])}" if D0["qtde"] else "sem desconto efetivado segundo o extrato")
    if D0["ativo"]:
        periodo = f"com descontos iniciados na competência {M.comp_str(D0['ini'])} e ainda em curso"
    corpo(f"{A_} é {benef} do Regime Geral de Previdência Social e, em conferência ao Histórico de Empréstimo "
          f"Consignado emitido pelo INSS em {emissao}, constatou a existência de contrato com numeração contendo o "
          f"sufixo “{D0['sufixo']}” — nº {d0['contrato']} —, vinculado ao ora Réu, {periodo}.")
    corpo(f"A análise do histórico revelou padrão inequívoco: o número-raiz desse contrato derivado ({D0['raiz_num']}) é "
          f"exatamente o mesmo de um contrato anterior atribuído {aa_}, averbado em {data4(r0.get('inclusao'))} e "
          f"POSTERIORMENTE EXCLUÍDO pela própria instituição financeira em {data4(r0.get('exclusao'))}.")
    iv = D0["intervalo"]
    recente = iv is not None and 0 <= iv <= 30
    corpo(f"Em outras palavras, o Réu reinseriu, no benefício previdenciário {da_}, sob nova numeração, contrato que "
          f"{'acabara de ser' if recente else 'havia sido'} excluído do sistema do INSS, modificando apenas a terminação "
          "numérica para contornar a barreira técnica da Dataprev, que impede a reaverbação sob o mesmo número.")
    mot_raiz = r0.get("motivo_exclusao") or M.CONFERIR
    if iv == 0:
        corpo(f"Chama a atenção que a reinclusão se deu no próprio dia da exclusão: o extrato registra a exclusão do "
              f"contrato-raiz (“{mot_raiz}”) e a averbação do contrato derivado (“{d0.get('origem_averbacao') or 'Averbação nova'}”) "
              f"na mesma data, {data4(d0['inclusao'])}, sem qualquer intervalo entre uma e outra.")
    elif recente:
        corpo(f"Chama a atenção a proximidade entre os dois atos: o extrato registra a exclusão do contrato-raiz "
              f"(“{mot_raiz}”) em {data4(r0.get('exclusao'))} e a averbação do contrato derivado "
              f"(“{d0.get('origem_averbacao') or 'Averbação nova'}”) em {data4(d0['inclusao'])} — apenas {iv} "
              f"{'dia' if iv == 1 else 'dias'} depois.")
    elif iv is not None:
        corpo(f"O extrato registra a exclusão do contrato-raiz (“{mot_raiz}”) em {data4(r0.get('exclusao'))} e a "
              f"averbação do contrato derivado (“{d0.get('origem_averbacao') or 'Averbação nova'}”) em "
              f"{data4(d0['inclusao'])}, decorridos {iv} dias, período em que não houve qualquer ato "
              f"{da_cons}.")
    corpo(f"Importante consignar, desde já, que a presente ação tem por objeto exclusivamente o {deriv_txt}, sem que "
          "se reconheça ou se discuta, neste feito, a validade do contrato anterior já excluído. A irregularidade ora "
          "impugnada existe por si só, em decorrência da reinclusão unilateral, e independe da regularidade da operação "
          "anterior.")
    for x in derivs:
        d = x["d"]
        prazo = f" e prazo de {d['qtde_contratada']} meses" if d.get("qtde_contratada") else ""
        t = (f"Segundo o extrato, o contrato derivado {'' if um else 'nº ' + d['contrato'] + ' '}foi incluído em "
             f"{data4(d['inclusao'])}, com parcela de {M.brl(d['parcela'])}{prazo}. ")
        if x["ativo"]:
            t += (f"Até o momento, foram descontadas {x['qtde']} ({M._inteiro(x['qtde'])}) parcelas, nas competências "
                  f"de {M.comp_str(x['ini'])} a {M.comp_str(x['ate'])}, no total de {M.brl(x['total'])}, e os "
                  "descontos permanecem em curso.")
        elif x["qtde"]:
            t += (f"Foram efetivamente descontadas {x['qtde']} ({M._inteiro(x['qtde'])}) parcelas, nas competências de "
                  f"{M.comp_str(x['ini'])} a {M.comp_str(x['ate'])}, no total de {M.brl(x['total'])}, até a exclusão "
                  f"do contrato em {data4(d.get('exclusao'))} (“{d.get('motivo_exclusao') or M.CONFERIR}”).")
        else:
            t += (f"O contrato foi excluído em {data4(d.get('exclusao'))} (“{d.get('motivo_exclusao') or M.CONFERIR}”) "
                  "sem desconto efetivado.")
        corpo(t)
        for o in x["outros"]:
            sit = "baixado" if o["secao"] == "EXCLUIDO" else "ativo"
            quando = f" em {data4(o['exclusao'])}" if o.get("exclusao") else ""
            por = f" por “{o['motivo_exclusao']}”" if o.get("motivo_exclusao") else ""
            origem = f", com origem “{o['origem_averbacao']}”" if o.get("origem_averbacao") else ""
            corpo(f"Consta, ainda, registro do mesmo contrato sob o código {o['banco'].split('-')[0].strip()} "
                  f"({o['banco'].split('-', 1)[-1].strip()}), {sit}{quando}{por}{origem}.")
            alertas.append(f"Derivado {d['contrato']} aparece também no banco {o['banco']} — conferir o parágrafo "
                           "gerado sobre esse registro (nome do banco vem do extrato, sem espaços).")
    for p in comp_json.get("paragrafos_fatos", []):
        corpo(p)
    lib = d0.get("liberado")
    corpo(f"Em nenhum momento {a_} foi {F('contatado', 'contatada')}, {F('notificado', 'notificada')} ou "
          f"{F('consultado', 'consultada')} acerca da inclusão do contrato derivado. Não houve nova assinatura de Cédula "
          "de Crédito Bancário (CCB). Não houve captura de nova biometria. Não há comprovação de que valor novo tenha "
          f"sido creditado em conta de titularidade {da_}"
          + (f" — ainda que o extrato registre, no campo “liberado”, o montante de {M.brl(lib)}, cuja destinação "
             "incumbe ao Réu demonstrar" if lib else "")
          + f". Não houve, em síntese, qualquer ato volitivo {da_cons} que justifique a inscrição.")
    corpo("Para que a compreensão deste Juízo seja imediata, transcreve-se abaixo a representação esquemática da "
          "operação ora impugnada, denominada pela doutrina especializada como “Tese 1000 Contra”:")

    # diagramas (blocos 16–38 do modelo), preenchidos
    ex_raiz = data4(r0.get("exclusao"))
    inc_der = data4(d0["inclusao"])
    if iv == 0:
        caixa_periodo = ["SEM INTERVALO", f"Exclusão do contrato-raiz e averbação do derivado em {inc_der} • "
                                          f"Nenhum ato {da_cons}"]
        marco3 = ["MARCO 3", "MESMO DIA", "Exclusão e reinclusão", "sem intervalo", inc_der, ""]
    elif iv is not None:
        caixa_periodo = ["PERÍODO SEM AVERBAÇÃO", f"{iv} {'dia' if iv == 1 else 'dias'} entre a exclusão ({ex_raiz}) "
                                                  f"e a reaverbação ({inc_der}) • Nenhum ato {da_cons}"]
        marco3 = ["MARCO 3", "PERÍODO MORTO", f"{iv} {'dia' if iv == 1 else 'dias'}", "Sem contrato ativo",
                  "Margem liberada", ""]
    else:
        caixa_periodo = None
        marco3 = None
    diag = {
        18: [["CONTRATO RAIZ", f"Nº {D0['raiz_num']}", f"Averbação em {data4(r0.get('inclusao'))} • EXCLUÍDA pela "
                                                     f"própria instituição em {ex_raiz}"]],
        22: [caixa_periodo],
        26: [["CONTRATO DERIVADO", f"Nº {d0['contrato']}", f"“{d0.get('origem_averbacao') or 'Averbação nova'}” em "
                                                         f"{inc_der} — sem CCB própria"]],
        34: [["MARCO 1", "CONTRATO RAIZ", f"Averbação em {data4(r0.get('inclusao'))}", "Figura no extrato",
              f"Excluída em {ex_raiz}", ""],
             ["MARCO 2", "EXCLUSÃO DO CONTRATO", "Banco encerra a averbação",
              f"(motivo: {mot_raiz}). Essa exclusão é", "DEFINITIVA"],
             marco3,
             ["MARCO 4", "REAPARECIMENTO SOB SUFIXO", f"Averbado em {inc_der}", "Sem nova CCB",
              "Sem nova biometria", "ILEGAL"]],
    }
    for i in range(16, 38):
        b = T[i]
        if i == 31:
            corpo(M.texto(b))
            continue
        if i in diag:
            b = celulas_texto(b, diag[i])
        out.append(b)
    corpo(f"Em resumo: {a_} viu surgir, em seu benefício previdenciário, descontos derivados de contrato que "
          "ressuscita, sob nova roupagem numérica, dívida anteriormente extinta no sistema do INSS, sem que "
          f"{F('o consumidor', 'a consumidora')} tenha autorizado a operação por qualquer meio admitido em direito.")

    # III – tese
    h1("DA TESE 1000 CONTRA: PRÁTICA SISTÊMICA DE REAVERBAÇÃO IRREGULAR")
    for i in range(40, 46):
        corpo(M.texto(T[i]).replace("o(a) cliente", "o cliente"))
    corpo(f"O resultado é nefasto: {F('o beneficiário', 'a beneficiária')} volta a ter descontos em seu benefício, "
          "frequentemente por prazo SUPERIOR ao originalmente contratado, sem ter manifestado qualquer vontade nesse "
          "sentido. A irregularidade é estrutural e, por sua natureza sistêmica, dispensa demonstração de dolo "
          "individualizado.")

    # IV – direito
    h1("DO DIREITO")
    h2("Da relação de consumo e da inversão do ônus da prova")
    corpo(f"A relação travada entre as partes é típica relação de consumo, regida pelo Código de Defesa do Consumidor "
          f"(Súmula 297 do STJ). {A_}, {benef} {F('idoso', 'idosa')} do INSS, é parte hipossuficiente em duplo sentido: "
          "técnico e econômico. A verossimilhança das alegações é manifesta diante do encadeamento dos fatos e da "
          "própria geometria da fraude documentada nos diagramas acima.")
    corpo("Requer-se, desde já, a inversão do ônus da prova, nos termos do art. 6º, VIII, do CDC, competindo ao Réu "
          "apresentar, para cada contrato derivado impugnado, sob pena de presunção de inexistência: (a) CCB autônoma "
          "datada da averbação; (b) registro biométrico capturado na referida data; (c) comprovante de liberação de "
          f"valor novo em conta de titularidade {da_}; e (d) demonstrativo prévio de CET, valor remanescente e prazo, "
          f"entregue {F('ao consumidor', 'à consumidora')} antes da operação.")
    h2("Da violação à Instrução Normativa INSS/PRES nº 138/2022")
    corpo(M.texto(T[52]))
    out.append(T[53])
    corpo(M.texto(T[55]))
    h2("Da inexistência da relação jurídica - ausência de consentimento expresso")
    corpo(M.texto(T[57]))
    corpo("Inexistindo qualquer desses elementos quanto aos contratos derivados, sendo que a prova dessa existência "
          "incumbe ao Réu por força da inversão do ônus da prova, a conclusão jurídica é uma só: jamais houve formação "
          "válida de vínculo contratual no que toca aos contratos com sufixo numérico. O que existe materialmente é um "
          "ato unilateral da instituição financeira, despido de força obrigatória, que se vale do sistema do INSS para "
          f"retirar valores do benefício {da_} sem causa jurídica que {F('o', 'a')} sustente.")
    h2("Da repetição em dobro")
    corpo(M.texto(T[60]))
    out.append(M.par(P_CIT, [(M.texto(T[61]), (M.rprs(P_CIT) or [""])[0])]))
    if pre2021:
        mo = ("com reinclusão no mesmo dia da exclusão" if iv == 0 else
              f"com reinclusão {iv} {'dia' if iv == 1 else 'dias'} após a exclusão" if recente else
              "com reaproveitamento do número de contrato já excluído")
        corpo("A prática ilegal do Réu é inegável, assim como o enriquecimento ilícito auferido em situações idênticas "
              "e repetitivas. Ainda que os descontos tenham ocorrido, ao menos em parte, antes de 30/03/2021, termo "
              "inicial da modulação fixada pela Corte Especial do STJ no EAREsp 676.608/RS, a má-fé está caracterizada "
              "pelo próprio modus operandi — contorno deliberado de barreira técnica do sistema do INSS mediante "
              f"subterfúgio numérico, {mo} —, o que justifica a devolução em dobro, com a devida correção monetária, dos "
              "valores indevidamente descontados.")
    else:
        corpo("A prática ilegal do Réu é inegável, assim como o enriquecimento ilícito auferido em situações idênticas "
              "e repetitivas. Prova suficiente para caracterizar a má-fé do Réu e, por conseguinte, a devolução em "
              "dobro e com a devida correção monetária dos valores indevidamente descontados.")
    corpo(M.texto(T[63]).strip())
    for x in com_desc:
        d = x["d"]
        corpo(f"{'Foram descontadas' if not x['ativo'] else 'Até a presente data, foram descontadas'} do benefício da "
              f"parte autora{'' if um else ', quanto ao contrato nº ' + d['contrato'] + ','} {x['qtde']} "
              f"({M._inteiro(x['qtde'])}) parcelas de {M.brl(d['parcela'])}, nas competências de "
              f"{M.comp_str(x['ini'])} a {M.comp_str(x['ate'])}, cuja soma resulta no valor de {M.brl_ext(x['total'])}. "
              f"Assim, a parte ré deve restituir os valores descontados de forma dobrada, o que equivale ao valor de "
              f"{M.brl_ext(x['rest'])}.")
    if not com_desc:
        conferir.append("Nenhum desconto efetivo nos derivados — rever o pedido de restituição.")
    if liminar:
        corpo(M.texto(T[65]).replace("até o até o", "até o"))
    h2("Do dano moral in re ipsa")
    corpo(M.texto(T[67]).replace("do(a) beneficiário(a)", F("do beneficiário", "da beneficiária")))
    corpo(M.texto(T[68]).replace("o(a) Autor(a)", a_))
    corpo("Pleiteia-se, em razão de tudo, a fixação do dano moral em R$ 20.000,00 (vinte mil reais), valor que atende "
          "aos parâmetros da razoabilidade e da proporcionalidade, observa o caráter pedagógico-punitivo da reparação e "
          "dialoga com a jurisprudência consolidada para casos análogos de consignado fraudulento em benefício "
          "previdenciário.")
    h2("Do prazo prescricional decenal")
    corpo("Cumpre, por fim, antecipar resposta a eventual arguição de prescrição pelo Réu. Tratando-se de pretensão de "
          "repetição de indébito decorrente de cobrança indevida em relação de consumo, aplica-se o prazo decenal do "
          "art. 205 do Código Civil, conforme firmado pela Corte Especial do Superior Tribunal de Justiça no EAREsp "
          f"676.608/RS (Rel. Min. Og Fernandes, 21/10/2020) e no EAREsp 738.991/RS{VERIF}. Ademais, sendo prestação de "
          "trato sucessivo, renova-se o termo inicial a cada novo desconto indevido.")

    # tutela
    lista_at = ", ".join(f"nº {c}" for c in ativos)
    if liminar:
        h1("DA TUTELA PROVISÓRIA DE URGÊNCIA")
        corpo("Presentes os requisitos do art. 300 do CPC, requer-se a concessão de tutela provisória de urgência, em "
              "caráter liminar e inaudita altera parte, para determinar a IMEDIATA SUSPENSÃO DOS DESCONTOS referente "
              f"ao(s) contrato(s) derivado(s) {lista_at} no benefício previdenciário {da_}, sob pena de multa diária a "
              "ser arbitrada por este Juízo.")
        corpo("A probabilidade do direito exsurge da própria geometria da fraude documentada nos diagramas acima: a "
              "identidade do número-raiz, somada à ausência absoluta de qualquer evento de consentimento entre a "
              "exclusão e o reaparecimento sob sufixo, comprova de plano a irregularidade. O perigo de dano é "
              f"manifesto: cada mês adicional de desconto subtrai {F('do Autor', 'da Autora')}, pessoa "
              f"{F('idosa', 'idosa')}, {benef} de prestação alimentar, parcela do mínimo necessário à sua subsistência, "
              "prejuízo de difícil ou impossível reparação na via ressarcitória.")

    # pedidos
    h1("DOS PEDIDOS")
    corpo("Ante o exposto, requer-se a Vossa Excelência:")
    L = iter("abcdefghij")
    ped([(f"{next(L)}) A concessão dos benefícios da ", False), ("GRATUIDADE DA JUSTIÇA", True),
         (", nos termos do art. 98 e seguintes do CPC, ante a declaração de hipossuficiência anexa;", False)])
    ped([(f"{next(L)}) A ", False), ("TRAMITAÇÃO PRIORITÁRIA", True),
         (" do feito, nos termos do art. 71 da Lei nº 10.741/2003 e do art. 1.048, I, do CPC, por ser "
          f"{a_} pessoa com idade superior a 60 anos;", False)])
    if liminar:
        ped([(f"{next(L)}) A concessão de ", False), ("TUTELA PROVISÓRIA DE URGÊNCIA", True),
             (", em caráter liminar e inaudita altera parte, determinando-se ao Réu a IMEDIATA SUSPENSÃO DOS DESCONTOS "
              f"referente ao(s) contrato(s) derivado(s) {lista_at} no benefício previdenciário {da_}, sob pena de "
              "multa diária a ser arbitrada por este Juízo;", False)])
    ped([(f"{next(L)}) A ", False), ("CITAÇÃO", True), (" do Réu para, querendo, comparecer à audiência de conciliação "
                                                       "e apresentar contestação no prazo legal, sob pena de revelia;", False)])
    ped([(f"{next(L)}) A ", False), ("INVERSÃO DO ÔNUS DA PROVA", True),
         (", nos termos do art. 6º, VIII, do CDC, atribuindo-se ao Réu o encargo de demonstrar, quanto a cada contrato "
          "derivado impugnado: (i) a existência de CCB autônoma datada da averbação; (ii) o registro biométrico "
          f"contemporâneo à operação; (iii) o comprovante de liberação de valor novo em conta de titularidade {da_}; "
          "(iv) a entrega prévia de demonstrativo de CET, valor remanescente e prazo;", False)])
    lp = next(L)
    ped([(f"{lp}) Ao final, a procedência integral dos pedidos para:", False)])
    ped([(f"{lp}.1) ", False), ("DECLARAR a INEXISTÊNCIA", True),
         (f" da relação jurídica e, por consequência, a INEXIGIBILIDADE dos débitos referentes ao {deriv_txt};", False)])
    ped([(f"{lp}.2) ", False), ("CONDENAR", True),
         (f" o Réu a restituir, de forma dobrada, os valores cobrados indevidamente da parte autora, que correspondem "
          f"ao valor de {M.brl_ext(tot_rest)}, com correção monetária desde a data de cada desconto (Súmula 43 do STJ) "
          "e juros moratórios a contar do evento danoso (Súmula 54 do STJ), observados, a partir de 30 de agosto de "
          "2024, os critérios da Lei nº 14.905/2024"
          + ("; requer, ainda, que sejam acrescidos à condenação os eventuais descontos que possam ocorrer até o "
             "trânsito em julgado, a serem computados em liquidação;" if liminar else ";"), False)])
    ped([(f"{lp}.3) ", False), ("CONDENAR", True),
         (" o Réu ao pagamento de INDENIZAÇÃO POR DANOS MORAIS no valor de R$ 20.000,00 (vinte mil reais), corrigida "
          "monetariamente da publicação da sentença e acrescida de juros legais da citação;", False)])
    if liminar:
        e4 = ("a EXCLUSÃO DEFINITIVA do(s) contrato(s) derivado(s) impugnado(s) do histórico de empréstimo consignado "
              f"{da_}, com registro de que a exclusão se dá por inexistência de relação jurídica")
    else:
        e4 = (f"a retificação do histórico de empréstimo consignado {da_}, para que conste que o {deriv_txt} "
              f"{'foi excluído' if um else 'foram excluídos'} por inexistência de relação jurídica")
    ped([(f"{lp}.4) ", False), ("DETERMINAR", True),
         (f" ao Réu a OBRIGAÇÃO DE FAZER consistente em providenciar, junto à Dataprev e ao INSS, {e4}, sob pena de "
          "multa diária;", False)])
    ped([(f"{next(L)}) A ", False), ("PRODUÇÃO DE TODAS AS PROVAS", True),
         (" em direito admitidas, especialmente a documental complementar, dispensando-se desde já a prova pericial em "
          "razão da natureza eminentemente jurídica da controvérsia.", False)])

    h1("DO VALOR DA CAUSA")
    out.append(M.par(B[117], [("Dá-se à causa o valor de ", RN), (f"{M.brl_ext(valor_causa)}", RBB),
                              (f", correspondente à soma da repetição do indébito em dobro ({M.brl(tot_rest)}) com os "
                               "danos morais (R$ 20.000,00).", RN)]))
    # fecho e assinaturas do modelo AMN (118 em diante)
    for i in range(118, len(B)):
        b = B[i]
        if i == 120:
            b = M.par(b, [(f"{M.g(q, 'cidade')}, {hoje.day} de {M.MESES[hoje.month - 1]} de {hoje.year}.",
                           (M.rprs(b) or [""])[0])])
        out.append(b)

    # ---- salvar
    saida = Path(a.saida)
    saida.mkdir(parents=True, exist_ok=True)
    nome_reu = re.sub(r"[^\w]+", "_", reu["nome"].split(" S.A")[0].split(" S A")[0]).strip("_")
    nome_aut = re.sub(r"[^\w]+", "_", M.g(q, "nome", "AUTOR")).strip("_")
    base = f"Inicial_Tese1000_{nome_aut}_x_{nome_reu}_NB{(proc.get('nb') or '').replace('.', '').replace('-', '')}"
    destino = saida / f"{base}.docx"
    M.salvar_docx(destino, cab, out, rod)

    Lr = [f"# Conferência — {destino.name}\n",
          f"- Processo {proc['processo']} da ficha · NB {proc.get('nb')} · réu {reu['nome']} · {enderecamento}",
          f"- Liminar: {'SIM, sobre ' + lista_at if liminar else 'não'} · Litispendência (tópico): "
          f"{'incluído' if proc.get('litispendencia') else 'não'}\n",
          "| Derivado | Raiz | Raiz: averbação → exclusão (motivo) | Derivado: inclusão | Intervalo | Parcela | Qtde | "
          "Descontado | Restituição | Situação |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for x in derivs:
        d, r = x["d"], x["raiz"] or {}
        Lr.append(f"| {d['contrato']} | {x['raiz_num']} | {data4(r.get('inclusao'))} → {data4(r.get('exclusao'))} "
                  f"({r.get('motivo_exclusao') or '?'}) | {data4(d['inclusao'])} | "
                  f"{x['intervalo'] if x['intervalo'] is not None else '?'} dia(s) | {M.brl(d['parcela'])} | "
                  f"{x['qtde']} | {M.brl(x['total'])} | {M.brl(x['rest'])} | {'ATIVO' if x['ativo'] else 'excluído'} |")
    Lr.append(f"\n- Liberado (extrato): {M.brl(lib) if lib else '—'} · Dano moral: R$ 20.000,00 · "
              f"**Valor da causa: {M.brl_ext(valor_causa)}**\n")
    Lr.append("- O tópico de prescrição tem marcação [VERIFICAR ANTES DE PROTOCOLAR] (atribuição do prazo decenal ao "
              "EAREsp 676.608/RS).")
    if conferir:
        Lr.append("\n## ⚠️ Conferir antes de protocolar\n")
        Lr += [f"- {c}" for c in conferir]
    if alertas:
        Lr.append("\n## Alertas\n")
        Lr += [f"- {x}" for x in alertas]
    (saida / f"{base}_conferencia.md").write_text("\n".join(Lr), encoding="utf-8")
    print(destino)
    print("\n".join(Lr))


if __name__ == "__main__":
    main()
