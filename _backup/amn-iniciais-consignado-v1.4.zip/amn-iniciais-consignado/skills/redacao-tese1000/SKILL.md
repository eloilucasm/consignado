---
name: redacao-tese1000
description: Redige a petição inicial da TESE 1000 CONTRA (.docx timbrado do AMN) — contrato derivado com sufixo (_0001, _01…) reaverbado sobre contrato-raiz excluído — para processos da ficha de ajuizamento da /triagem-consignado com tese TESE_1000 (bloco E). Acione com "tese 1000", "1000 contra", "contrato derivado", "reaverbação com sufixo", ou depois de aprovada a ficha de um cliente. Não serve para não contratado, migrado nem RMC.
---

# Redação — Tese 1000 Contra

Entradas iguais às das outras redações: **ficha aprovada** + **extrato do benefício do
processo** + **qualificação** (`clientes/<cliente>/qualificacao.json`, ver Passo 1 da
`/redacao-nao-contratado`). Requer `triagem-consignado` e `redacao-nao-contratado`
instaladas ao lado (usa as tabelas e o motor de formatação delas).

## Passo 1 — ler o extrato antes de gerar

O gerador tira tudo do extrato, mas a Tese 1000 é a peça mais "contada" do pipeline.
Antes de rodar, olhe no extrato o contrato-raiz e o derivado e veja se há algo que a
narrativa padrão não cobre (ex.: derivado que depois foi refinanciado ou migrado para
outro banco, vários derivados com sufixos _0002/_0003, valor liberado incomum). Se
houver, escreva o parágrafo factual e passe em `--complemento`:

```json
{"paragrafos_fatos": ["Texto factual, só com o que está no extrato."]}
```

Nada de inventar fato: só o que o extrato mostra. Avise o usuário que o parágrafo é seu.

## Passo 2 — gerar

```bash
python3 <pasta desta skill>/scripts/gerar.py \
  --ficha "<cliente>/triagem/ficha.json" --processo N \
  --extrato "<EXTRATO DO NB DO PROCESSO>.pdf" \
  --qualificacao "<cliente>/qualificacao.json" \
  --saida "<cliente>/iniciais" [--data AAAA-MM-DD] [--complemento complemento.json]
```

`<pasta desta skill>` = o diretório base desta skill (informado ao carregá-la).

O gerador:
- localiza no extrato o **derivado** (no banco réu) e o **contrato-raiz** (número sem o sufixo): averbação, exclusão e motivo da raiz; inclusão, parcela, prazo, competências, valor liberado e exclusão do derivado;
- calcula o **intervalo** entre a exclusão da raiz e a reaverbação e adapta a narrativa: mesmo dia ("no próprio dia da exclusão"), até 30 dias ("apenas N dias depois") ou intervalo maior;
- registra, nos fatos, outras ocorrências do mesmo número em outros bancos (migração/troca de titularidade);
- preenche os **diagramas** do modelo (anatomia da reaverbação e linha do tempo) com números e datas do caso; o quadro da IN 138/2022 vai como está;
- descontos **antes de 30/03/2021** → acrescenta o argumento da má-fé pelo modus operandi (modulação do EAREsp 676.608/RS);
- derivado **ativo** → tutela de urgência (título, tópico e pedido) só sobre os derivados ativos, e o pedido final vira exclusão definitiva; derivado **excluído** → sem tutela, pedido de retificação do histórico;
- dano moral **R$ 20.000,00**; valor da causa = dobro + dano moral;
- **prescrição decenal** sempre (padrão da tese), com a marcação `[VERIFICAR ANTES DE PROTOCOLAR]` — a inicial de referência atribui o prazo decenal ao EAREsp 676.608/RS, julgado conhecido pela tese do dobro; conferir a citação;
- tópico de **ausência de litispendência** quando a ficha marcar (ex.: mesmo banco com processo de não contratado).

## Passo 3 — conferir e entregar

Apresente o `_conferencia.md`: derivado × raiz, datas, intervalo, parcelas, valores,
liberado, valor da causa, liminar, tópicos condicionais, itens a conferir e alertas.
Entregue o `.docx`. Peça com `[CONFERIR]` ou `[VERIFICAR ANTES DE PROTOCOLAR]` não está
pronta para protocolo.

Formatação: timbre e assinatura iguais às demais peças do escritório; corpo e diagramas
do modelo da Tese 1000 (`assets/modelo_tese1000.docx`). A inicial de referência (Maria x
BNP) usou o visual Lato com rodapé em texto — se o usuário preferir esse visual, trocar a
base em `scripts/gerar.py`.
