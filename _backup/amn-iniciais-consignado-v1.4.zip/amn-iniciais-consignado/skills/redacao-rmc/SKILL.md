---
name: redacao-rmc
description: Redige a petição inicial de NULIDADE DE REFINANCIAMENTO COMPULSÓRIO de cartão consignado RMC/RCC (Lei 14.690/2023 — Desenrola; marco extintivo de 200%) em .docx timbrado do AMN, para processos da ficha da /triagem-consignado com tese RMC_REFINANCIAMENTO (bloco D). Acione com "RMC", "RCC", "cartão consignado", "refinanciamento do cartão", "Desenrola", "marco de 200%", ou depois de aprovada a ficha de um cliente. Não serve para empréstimo não contratado, migrado nem Tese 1000.
---

# Redação — RMC/RCC: Nulidade de Refinanciamento Compulsório (Lei Desenrola)

Entradas: **ficha aprovada** + **extrato do benefício do cartão** + **qualificação**
(`clientes/<cliente>/qualificacao.json`, ver Passo 1 da `/redacao-nao-contratado`).
Requer `triagem-consignado` e `redacao-nao-contratado` instaladas ao lado.

## Como a tese é montada (tudo do extrato)

O gerador lê o cartão na seção **CARTÃO DE CRÉDITO** (limite = capital original, data de
inclusão, situação) e o histórico mês a mês na seção **DESCONTOS DE CARTÃO**, e:

1. **detecta o refinanciamento**: competência em que o "utilizado no mês" salta para
   (quase) todo o saldo devedor, bem acima do desconto mensal, com **IOF** lançado;
2. monta a **planilha** de descontos acumulados e o **% do capital** mês a mês;
3. acha o **marco de 200%** e conta quantos meses antes do refinanciamento ele ocorreu;
4. calcula: pago até o refinanciamento, pago depois (repetição em dobro), total pago,
   saldo atual, custo total mínimo e onerosidade;
5. valor da causa = saldo refinanciado (registrado no INSS) + dobro + R$ 20.000,00.

O argumento "(c) queda da taxa de juros" só entra se a taxa do mês do refinanciamento
for menor que a de **todos** os meses vizinhos.

## Travas — o gerador NÃO redige e explica o motivo

- **Histórico incompleto**: o extrato só traz parte do histórico (comum — às vezes começa
  anos depois da inclusão do cartão). Sem os descontos anteriores não se prova o marco de
  200%. Peça ao usuário o **HISCRE** (histórico de créditos do INSS, rubrica do cartão)
  ou as **faturas**, transcreva as competências faltantes em um CSV e rode de novo com
  `--historico-extra` (o documento vai anexado à inicial):
  ```
  MM/AAAA;valor;fonte        ex.: 03/2017;55,00;HISCRE
  ```
  Transcreva exatamente o que está no documento — nunca estimar ou repetir valores para
  "completar" meses.
- **Sem refinanciamento detectado** → a tese não se aplica.
- **200% não atingido antes do refinanciamento** → o núcleo da tese não se sustenta;
  devolver ao advogado responsável com os números.

## Gerar

```bash
python3 <pasta desta skill>/scripts/gerar.py \
  --ficha "<cliente>/triagem/ficha.json" --processo N \
  --extrato "<EXTRATO DO NB DO CARTÃO>.pdf" \
  --qualificacao "<cliente>/qualificacao.json" \
  --saida "<cliente>/iniciais" [--data AAAA-MM-DD] \
  [--historico-extra historico.csv] [--processos-anteriores "nº ...; nº ..."]
```

`<pasta desta skill>` = o diretório base desta skill (informado ao carregá-la).

**Antes de gerar, pergunte ao usuário se houve ação anterior sobre esse cartão.** Se
houve, passe os números em `--processos-anteriores`: entra o tópico de inaplicabilidade
da coisa julgada (distinguishing em seis dimensões, do modelo do escritório).

## Estrutura da peça

Vara Cível (ou Federal, se Caixa), gratuidade, [coisa julgada], [litispendência], tutela
(cartão ativo), fatos (cronologia, prova documental do refinanciamento, planilha completa,
resumo financeiro), direito (CDC/inversão, nulidade por fraude à lei — art. 166, VI, CC,
art. 28, § 1º, Lei 14.690/2023 e art. 2º-C Res. CMN 5.112/2023 —, marco de 200%, boa-fé,
dobro, danos morais), pedidos (tutela, preliminares, mérito, subsidiários, instrução com
perícia contábil) e composição do valor da causa. Base: inicial protocolada Francisco x BMG
+ modelo "Nulidade de Refinanciamento — Lei do Desenrola", adaptados à Vara Cível.

## Conferir e entregar

Apresente o `_conferencia.md` (cartão, histórico usado e fonte, refinanciamento e seus
sinais, marco, totais, valor da causa, alertas) e entregue o `.docx`. Chame atenção para:
competências ausentes (planilha é piso), histórico complementado (juntar o documento) e
tópico de coisa julgada (conferir números e resultado das ações anteriores).
