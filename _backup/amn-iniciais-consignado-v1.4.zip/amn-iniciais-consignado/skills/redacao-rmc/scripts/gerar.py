#!/usr/bin/env python3
"""Gera a inicial de NULIDADE DE REFINANCIAMENTO COMPULSÓRIO de cartão RMC/RCC
(Lei 14.690/2023 — "Desenrola") para um processo da ficha (tese RMC_REFINANCIAMENTO).

Uso:
  python3 gerar.py --ficha ficha.json --processo N --extrato EXTRATO_DO_NB.pdf \
                   --qualificacao qualificacao.json --saida PASTA [--data AAAA-MM-DD] \
                   [--historico-extra historico.csv] [--processos-anteriores "nº 1; nº 2"]

historico.csv (opcional): competências que faltam no extrato, uma por linha
  "MM/AAAA;valor;fonte"  (ex.: "03/2017;55,00;HISCRE") — tiradas de HISCRE/faturas.

TRAVAS (o gerador não redige e explica o motivo):
  - nenhum refinanciamento detectado no histórico do cartão;
  - histórico incompleto: o extrato começa muito depois da inclusão do cartão e não
    foi fornecido histórico complementar;
  - os pagamentos não atingem 200% do capital ANTES do refinanciamento (o núcleo da
    tese — "dívida já extinta por lei" — não se sustenta com os dados).
"""
import argparse
import datetime as dt
import json
import re
import sys
from pathlib import Path
from xml.sax.saxutils import escape

AQUI = Path(__file__).resolve().parent
MOTOR = AQUI.parent.parent / "redacao-nao-contratado" / "scripts"
if not MOTOR.exists():
    MOTOR = Path.home() / ".claude/skills/redacao-nao-contratado/scripts"
sys.path.insert(0, str(MOTOR))
import gerar as M  # noqa: E402
sys.path.insert(0, str(M.TRIAGEM / "scripts"))
import cartao as CT  # noqa: E402

LARG = 9638


def pct(x):
    return f"{x:,.1f}%".replace(",", "X").replace(".", ",").replace("X", ".")


def num(v):
    return M.brl(v).replace("R$", "")


def tabela(cab, linhas, larguras, destaque_ultima=False):
    """Tabela simples no padrão das peças (bordas finas, cabeçalho sombreado, 9 pt)."""
    tot = sum(larguras)
    larguras = [round(w * LARG / tot) for w in larguras]
    grid = "".join(f'<w:gridCol w:w="{w}"/>' for w in larguras)
    borda = ('<w:tblBorders>' + "".join(f'<w:{b} w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
                                         for b in ("top", "left", "bottom", "right", "insideH", "insideV"))
             + '</w:tblBorders>')

    def cel(t, w, negrito=False, fundo=None, alinh="center"):
        shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{fundo}"/>' if fundo else ""
        rpr = f'<w:rPr>{"<w:b/><w:bCs/>" if negrito else ""}<w:sz w:val="18"/><w:szCs w:val="18"/></w:rPr>'
        return (f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>{shd}<w:vAlign w:val="center"/></w:tcPr>'
                f'<w:p><w:pPr><w:spacing w:before="20" w:after="20" w:line="240" w:lineRule="auto"/>'
                f'<w:jc w:val="{alinh}"/>{rpr}</w:pPr><w:r>{rpr}<w:t xml:space="preserve">{escape(t)}</w:t></w:r></w:p></w:tc>')

    rows = []
    if cab:
        rows.append('<w:tr><w:trPr><w:tblHeader/></w:trPr>' + "".join(cel(t, w, True, "D9E2F3") for t, w in zip(cab, larguras))
                    + "</w:tr>")
    for i, ln in enumerate(linhas):
        ult = destaque_ultima and i == len(linhas) - 1
        rows.append("<w:tr>" + "".join(cel(t, w, ult, "F2F2F2" if ult else None, "left" if (j == 0 and not cab) else "center")
                                       for j, (t, w) in enumerate(zip(ln, larguras))) + "</w:tr>")
    return (f'<w:tbl><w:tblPr><w:tblW w:w="{LARG}" w:type="dxa"/><w:jc w:val="center"/>{borda}'
            f'<w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>{grid}</w:tblGrid>{"".join(rows)}</w:tbl>')


def base_calculo(extrato_pdf):
    t = CT.texto(extrato_pdf)
    m = re.search(r"VALORES DO BENEF[IÍ]CIO.*?R\$([\d.]+,\d{2})", t, re.S)
    return CT.v(m.group(1)) if m else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ficha", required=True)
    ap.add_argument("--processo", type=int, required=True)
    ap.add_argument("--extrato", required=True)
    ap.add_argument("--qualificacao", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--data", default=dt.date.today().isoformat())
    ap.add_argument("--historico-extra")
    ap.add_argument("--processos-anteriores")
    a = ap.parse_args()

    ficha = json.loads(Path(a.ficha).read_text(encoding="utf-8"))
    proc = next(p for p in ficha["processos"] if p["processo"] == a.processo)
    if proc["tese"] != "RMC_REFINANCIAMENTO":
        sys.exit(f"Processo {a.processo} é da tese {proc['tese']} — este gerador atende só: RMC_REFINANCIAMENTO.")
    if len(proc["contratos"]) != 1:
        sys.exit("Este gerador trata um cartão por processo — separar os cartões em processos distintos.")
    q = json.loads(Path(a.qualificacao).read_text(encoding="utf-8"))
    hoje = dt.date.fromisoformat(a.data)
    gen = q.get("genero")
    F = lambda m, f: M.flex(gen, m, f)
    alertas, conferir = [], []

    # ---- cartão e histórico
    txt = CT.texto(a.extrato)
    numero = proc["contratos"][0]["contrato"]
    cart = CT.contrato_cartao(txt, numero)
    if not cart:
        sys.exit(f"Cartão {numero} não encontrado na seção CARTÃO DE CRÉDITO do extrato.")
    hist = CT.historico(txt, numero, cart["banco_cod"], proc.get("nb"))
    cont = CT.continuidade(hist)
    cad = CT.cadeia(txt, cart["banco_cod"], cart.get("tipo") or "RMC")
    fontes_extra = set()
    if a.historico_extra:
        conhecidas = {h["competencia"] for h in hist}
        for ln in Path(a.historico_extra).read_text(encoding="utf-8").splitlines():
            if not ln.strip() or ln.startswith("#"):
                continue
            partes = [p.strip() for p in ln.split(";")]
            comp, val = partes[0], CT.v(partes[1])
            if comp not in conhecidas:
                hist.append({"competencia": comp, "desconto": val, "saldo": None, "utilizado": None, "iof": None,
                             "juros_m": None, "fonte": partes[2] if len(partes) > 2 else "histórico complementar"})
                fontes_extra.add(partes[2] if len(partes) > 2 else "histórico complementar")
        hist.sort(key=lambda h: CT.comp_n(h["competencia"]))
    if not hist:
        sys.exit("Nenhuma competência do cartão na seção DESCONTOS DE CARTÃO do extrato.")
    refs = CT.detectar_refinanciamento(hist)
    if not refs:
        sys.exit("TRAVA: nenhum refinanciamento detectado (salto do 'utilizado no mês' ≈ saldo, com IOF). "
                 "A tese não se aplica com estes dados.")
    if len(refs) > 1:
        alertas.append(f"Mais de um refinanciamento detectado ({', '.join(r['competencia'] for r in refs)}) — a peça "
                       "trata o primeiro; avaliar se cabe mencionar os demais.")
    R = refs[0]
    incl = cart["inclusao"]
    incl4 = f"{incl[:6]}20{incl[6:]}"
    inicio_cartao = CT.comp_n(f"{incl[3:5]}/20{incl[6:]}")
    primeira = CT.comp_n(hist[0]["competencia"])
    if primeira - inicio_cartao > 2:
        sys.exit(f"TRAVA: histórico incompleto — o cartão foi incluído em {incl4}, mas o histórico disponível começa em "
                 f"{hist[0]['competencia']} (faltam {primeira - inicio_cartao - 1} competências, de "
                 f"{CT.comp_s(inicio_cartao + 1)} a {CT.comp_s(primeira - 1)}). Sem esses descontos não se prova o "
                 "marco de 200% antes do refinanciamento. Forneça o histórico (HISCRE/faturas) em --historico-extra.")
    capital = cart["limite"]
    calc = CT.calcular(hist, capital, R["competencia"], 10 ** 6)  # todas as competências registradas no extrato
    marco = calc["marco_200"]
    rn = CT.comp_n(R["competencia"])
    if not marco or CT.comp_n(marco) >= rn:
        sys.exit(f"TRAVA: com o histórico disponível, os pagamentos não atingem 200% do capital (R$ {num(capital)}) antes "
                 f"do refinanciamento de {R['competencia']} (pago até então: R$ {num(calc['total_ate_refin'])}, "
                 f"{pct(calc['total_ate_refin'] / capital * 100)}). O núcleo da tese não se sustenta — avaliar com o "
                 "advogado responsável.")
    marco_linha = next(p for p in calc["planilha"] if p["competencia"] == marco)
    meses_teto = rn - CT.comp_n(marco)
    saldo_ref = R["utilizado"]
    pos = calc["total_pos_refin"]
    dobro = round(2 * pos, 2)
    saldo_atual = next((h["saldo"] for h in reversed(calc["planilha"]) if h.get("saldo")), None) or 0.0
    total_pago = calc["total_pago"]
    custo = round(total_pago + saldo_atual, 2)
    oneros = custo / capital * 100
    valor_causa = round(saldo_ref + dobro + M.DANO_MORAL, 2)
    emissao = M.data_extrato(a.extrato) or M.CONFERIR
    base = base_calculo(a.extrato)
    ativo = (cart["situacao"] or "").lower().startswith("ativ")
    if calc["ausentes"]:
        alertas.append(f"Competências ausentes no histórico (não interpoladas): {', '.join(calc['ausentes'])}.")
    if fontes_extra:
        alertas.append(f"Histórico complementado com: {', '.join(sorted(fontes_extra))} — juntar o documento à inicial.")
    for c_ in cont:
        if c_["variacao"] > 0.05:
            alertas.append(f"Saldo devedor NÃO é contínuo na mudança de registro {c_['de']}→{c_['para']} "
                           f"({M.brl(c_['saldo_de'])} → {M.brl(c_['saldo_para'])}) — conferir se as linhas antigas "
                           "(código do benefício) são mesmo deste cartão.")
    anteriores_cad = [c_ for c_ in cad if c_["numero"] != numero]
    if anteriores_cad:
        mesmo_dia = [c_ for c_ in anteriores_cad if c_.get("exclusao")
                     and any(d["inclusao"] == c_["exclusao"] for d in cad)]
        alertas.append("Cadeia de cartões do mesmo banco no extrato: "
                       + "; ".join(f"{c_['numero']} ({c_['inclusao']}→{c_.get('exclusao') or 'ativo'})" for c_ in cad)
                       + (f". Em {len(mesmo_dia)} troca(s) o cartão anterior foi excluído no MESMO DIA da averbação do "
                          "seguinte — fato possivelmente relevante para a estratégia (não incluído na peça)."
                          if mesmo_dia else "."))
    saltos_ant = [h for h in hist if h is not R and h.get("utilizado") and h.get("saldo") and h.get("desconto")
                  and h["utilizado"] >= 0.9 * h["saldo"] and h["utilizado"] >= 5 * h["desconto"]
                  and CT.comp_n(h["competencia"]) < CT.comp_n(R["competencia"])]
    for h in saltos_ant:
        alertas.append(f"Outro salto do 'utilizado no mês' ≈ saldo em {h['competencia']} ({M.brl(h['utilizado'])}), "
                       "sem IOF registrado — não tratado como refinanciamento na peça; avaliar.")
    juros_tipicos = [j for j in R["juros_vizinhos"] if j]
    # "queda abrupta da taxa" só se a taxa do mês do refinanciamento for menor que a de TODOS os vizinhos
    juros_cai = (bool(juros_tipicos) and R.get("juros_m") is not None
                 and all(R["juros_m"] < 0.8 * j for j in juros_tipicos))
    if juros_tipicos and not juros_cai:
        alertas.append(f"Taxa de juros no refinanciamento ({R.get('juros_m')}%) não é menor que a de todos os meses "
                       f"vizinhos ({juros_tipicos}) — o argumento (c) da queda da taxa foi omitido.")
    especie = M.especie_fmt(next((e.get("especie") for e in ficha.get("extratos", []) if e.get("nb") == proc["nb"]),
                                 None)) or M.CONFERIR
    tipo = cart.get("tipo") or "RMC"
    nome_cartao = ("Cartão de Crédito com Reserva de Margem Consignável — RMC" if tipo == "RMC"
                   else "Cartão Consignado de Benefício — RCC")
    mes_ext = lambda c: f"{M.MESES[int(c[:2]) - 1].lower()} de {c[3:]}"

    # ---- réu / juízo
    reu, cod = M.carregar_reu(proc["reu"])
    if not reu:
        reu = {"nome": f"{M.CONFERIR} {proc['reu']}", "artigo": "do",
               "descricao": f"pessoa jurídica de direito privado, inscrito no CNPJ sob o n° {M.CONFERIR}, com endereço "
                            f"na {M.CONFERIR}"}
        conferir.append(f"Réu {proc['reu']} não está em dados/reus.json — preencher CNPJ e endereço.")
    comp_txt = proc.get("competencia", "")
    if cod == "104":
        m = re.search(r"((?:Sub)?[Ss]eção Judiciária d[aeo] .+?)(?:/[A-Z]{2})?$", comp_txt)
        enderec = f"AO JUÍZO FEDERAL DA ___ VARA FEDERAL CÍVEL DA {m.group(1).upper() if m else M.CONFERIR}, ESTADO DA BAHIA"
    else:
        m = re.search(r"Comarca de (.+?)/[A-Z]{2}", comp_txt)
        enderec = f"AO JUÍZO DA ___ VARA CÍVEL DA COMARCA DE {m.group(1).upper() if m else M.CONFERIR}, ESTADO DA BAHIA"
    if "CONFERIR" in comp_txt or "NÃO" in comp_txt or not comp_txt:
        conferir.append(f"Juízo: {comp_txt or 'não informado na ficha'}")

    # ---- montagem
    cab, B, rod = M.ler_modelo()
    B = [M.limpar_ids(b) for b in B]
    RN = M.rprs(B[48])[0] if M.rprs(B[48]) else ""
    RBB = M.rprs(B[105])[1]
    P_CORPO, P_CIT, P_PED = B[13], B[33], B[96]
    P_H1 = B[12].replace("</w:pPr>", '<w:jc w:val="left"/></w:pPr>', 1) if "<w:jc " not in M.ppr(B[12]) else B[12]
    P_H2 = B[28]
    out = []
    ROM = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"]
    n1, n2 = [0], [0]

    def h1(nome):
        out.append(M.par(P_H1, [(f"{ROM[n1[0]]} — {nome}", "")])); n1[0] += 1; n2[0] = 0

    def h2(nome):
        n2[0] += 1
        out.append(M.par(P_H2, [(f"            {ROM[n1[0] - 1]}.{n2[0]} — {nome}", "")]))

    def corpo(t, segs=None):
        out.append(M.par(P_CORPO, segs or [(t, RN)]))

    def ped(rotulo, t):
        out.append(M.par(P_PED, [(f"{rotulo}) ", RN), (t, RN)]))

    A_, a_, da_ = F("O Autor", "A Autora"), F("o Autor", "a Autora"), F("do Autor", "da Autora")
    benef = F("beneficiário", "beneficiária")
    anteriores = (a.processos_anteriores or "").strip()

    # cabeçalho
    out.append(M.par(B[0], [(enderec, (M.rprs(B[0]) or [""])[0])]))
    ementa = ("EMENTA: DIREITO DO CONSUMIDOR E BANCÁRIO. AÇÃO DECLARATÓRIA DE NULIDADE DE REFINANCIAMENTO COMPULSÓRIO. "
              + ("Distinguishing: sentença anterior sobre a validade do contrato original não faz coisa julgada sobre ato "
                 "unilateral superveniente. " if anteriores else "")
              + f"Nulidade absoluta do refinanciamento de cartão {tipo} por fraude à lei imperativa (art. 166, VI, CC; "
              "art. 28, § 1º, Lei 14.690/2023). Marco extintivo de 200%: obrigação quitada antes do refinanciamento. "
              "Repetição em dobro (art. 42, parágrafo único, CDC) e danos morais.")
    out.append(M.par(B[3], [(ementa, (M.rprs(B[3]) or [""])[0])]))
    qualif = (f"{M.g(q, 'nome')}, {M.g(q, 'nacionalidade', F('brasileiro', 'brasileira'))}, {M.g(q, 'estado_civil')}, "
              f"{M.g(q, 'profissao')}, {F('inscrito', 'inscrita')} no CPF sob o nº {M.g(q, 'cpf')}, RG nº {M.g(q, 'rg')}, "
              f"{benef} do benefício nº {proc['nb']} ({especie}), residente e {F('domiciliado', 'domiciliada')} na "
              f"{M.g(q, 'endereco')}, CEP {M.g(q, 'cep')}, {M.g(q, 'cidade')}/{M.g(q, 'uf', 'BA')}, por seus advogados que "
              "ao final subscrevem, vem propor:")
    if M.CONFERIR in qualif:
        conferir.append("Qualificação com campo(s) [CONFERIR] — completar com os documentos pessoais.")
    out.append(M.par(B[6], [(qualif, (M.rprs(B[6]) or [""])[0])]))
    out.append(M.par(B[8], [("AÇÃO DECLARATÓRIA DE NULIDADE DE REFINANCIAMENTO COMPULSÓRIO C/C REPETIÇÃO DO INDÉBITO EM "
                             "DOBRO E INDENIZAÇÃO POR DANOS MORAIS"
                             + (", COM PEDIDO DE TUTELA PROVISÓRIA DE URGÊNCIA" if ativo else ""),
                             (M.rprs(B[8]) or [""])[0])]))
    out.append(M.par(B[9], [(f"em face {reu['artigo']} {reu['nome']}, {reu['descricao']}, pelos motivos que passa a "
                             "expor:", (M.rprs(B[9]) or [""])[0])]))

    # I — preliminares
    h1("DAS PRELIMINARES")
    h2("Da Gratuidade da Justiça")
    corpo(f"{A_} declara, sob as penas da lei, sua insuficiência de recursos, nos termos do art. 99, § 3º, do CPC/2015. "
          f"Seu benefício previdenciário tem base de cálculo de {M.brl(base) if base else M.CONFERIR}, valor "
          "incompatível com o custeio do processo sem prejuízo da própria subsistência, razão pela qual requer a "
          "concessão dos benefícios da gratuidade da justiça (arts. 98 e 99 do CPC).")
    if anteriores:
        h2("Da Inaplicabilidade da Coisa Julgada — Distinguishing em Seis Dimensões")
        for t in distinguishing(anteriores, incl4, R["competencia"], a_, tipo):
            corpo(t)
        alertas.append("Tópico de coisa julgada incluído (processos anteriores informados) — conferir números e o "
                       "resultado das ações anteriores (o texto pressupõe discussão da contratação original).")
    if proc.get("litispendencia"):
        def _h(_, nome):
            h2("Da Ausência de Litispendência")
        M.bloco_litispendencia(proc, ficha, _h, corpo)
    if ativo:
        h2("Da Tutela Provisória de Urgência e de Evidência")
        corpo(f"Requer-se tutela de urgência (art. 300 do CPC/2015) para suspender imediatamente os descontos do "
              f"contrato nº {numero} no benefício NB {proc['nb']}, vedando o repasse ao Banco Réu, sob pena de multa "
              f"diária de R$ 1.000,00 (mil reais). Fumus boni iuris: o próprio extrato oficial do INSS demonstra o "
              f"refinanciamento unilateral em {R['competencia']} e uma onerosidade de {pct(oneros)} sobre o capital "
              "original. Periculum in mora: os descontos mensais recaem sobre verba de natureza alimentar e de caráter "
              "previdenciário, causando dano de trato sucessivo e de difícil reparação. Alternativamente, requer-se "
              "tutela de evidência (art. 311, II e IV, do CPC), porquanto os fatos são demonstrados exclusivamente por "
              "prova documental.")

    # II — fatos
    h1("DOS FATOS")
    h2("Cronologia")
    corpo(f"{A_} é {benef} de {especie} (NB: {proc['nb']}), com base de cálculo de "
          f"{M.brl(base) if base else M.CONFERIR}. Em {incl4}, foi averbado em seu benefício contrato de {nome_cartao} "
          f"(contrato nº {numero}, {reu['nome']}), cujo limite de cartão — capital originalmente disponibilizado — era de "
          f"{M.brl(capital)}. Desde então, descontos mensais foram realizados diretamente no benefício a título de "
          f"“Desconto de cartão ({tipo})”, levando {a_} a acreditar, de boa-fé, na amortização progressiva do "
          "débito.")
    corpo(f"Conforme demonstrado pela planilha da Seção II.3, {a_} já havia pago, antes de qualquer refinanciamento, "
          f"valores muito superiores ao capital original: em {mes_ext(marco)}, o acumulado pago atingiu "
          f"{M.brl(marco_linha['acumulado'])}, equivalente a {pct(marco_linha['pct'])} do capital de {M.brl(capital)} — "
          "ultrapassando o teto legal de 200% estabelecido pelo art. 28, § 1º, da Lei 14.690/2023, "
          f"{meses_teto} {'mês' if meses_teto == 1 else 'meses'} antes de qualquer refinanciamento.")
    h2("O Refinanciamento Compulsório: A Prova Documental da Fraude")
    id_ref = f"{numero}{cart['banco_cod']}{R['competencia'].replace('/', '')}"
    corpo(f"Em {mes_ext(R['competencia'])}, o Banco Réu, sem qualquer contato, proposta, nova assinatura ou repasse de "
          f"numerário {F('ao Autor', 'à Autora')}, promoveu novo lançamento no sistema de consignações do INSS/DATAPREV "
          f"relativo ao contrato {tipo} nº {numero}. O próprio extrato oficial do INSS — Histórico de Empréstimo "
          f"Consignado, emitido em {emissao} — evidencia a fraude de forma autoexplicativa, conforme a Seção "
          f"“DESCONTOS DE CARTÃO”, contrato {id_ref}:")
    viz = [u for u in R["utilizado_vizinhos"] if u is not None]
    corpo(f"(a) Salto abrupto na coluna “UTILIZADO NO MÊS”: "
          + (f"nos meses anteriores ao refinanciamento, a coluna registra apenas {', '.join(M.brl(u) for u in viz)}; "
             if viz else "")
          + f"na competência {R['competencia']}, esse valor salta para {M.brl(R['utilizado'])} — "
          f"{'idêntico' if abs(R['utilizado'] - R['saldo']) < 0.01 else 'praticamente idêntico'} ao saldo devedor então "
          f"registrado ({M.brl(R['saldo'])}) —, demonstrando que o sistema tratou a operação como novo saque, sem que "
          f"nenhuma solicitação ou assinatura {da_} tenha ocorrido.")
    corpo(f"(b) Lançamento de IOF na mesma competência: a competência {R['competencia']} registra IOF de "
          f"{M.brl(R['iof'])} — tributo que somente incide sobre operação de crédito nova —, confirmando a existência de "
          f"nova operação de crédito não solicitada {F('pelo Autor', 'pela Autora')}.")
    if juros_cai:
        corpo(f"(c) Queda abrupta na taxa de juros do contrato: a taxa de juros mensal, que era de "
              f"{str(min(juros_tipicos)).replace('.', ',')}% ou mais nas competências próximas, cai para "
              f"{str(R['juros_m']).replace('.', ',')}% na competência do refinanciamento ({R['competencia']}) — "
              "assinatura típica da reconstituição artificial do saldo, que dilui a taxa efetiva ao recalcular o CET "
              "sobre um saldo inflado.")
    corpo(f"Esses elementos, extraídos do próprio documento oficial do INSS — cuja autenticidade pode ser conferida no "
          "código constante do rodapé do extrato —, comprovam, pela simples soma aritmética dos lançamentos, que o "
          f"Banco Réu promoveu, em {mes_ext(R['competencia'])}, um refinanciamento compulsório do saldo do cartão "
          f"{tipo}, sem qualquer manifestação de vontade {da_}.")
    h2("O Custo Real da Dívida — Planilha Completa de Pagamentos")
    aus = calc["ausentes"]
    corpo(f"A tabela abaixo demonstra todos os descontos realizados no benefício previdenciário {da_} a título do "
          f"contrato {tipo} nº {numero} ({reu['nome']}), extraídos do Histórico de Empréstimo Consignado emitido pelo "
          f"INSS em {emissao}"
          + (f" e complementados por {', '.join(sorted(fontes_extra))} anexo" if fontes_extra else "")
          + f", mês a mês, do primeiro desconto ({calc['primeira']}) ao mais recente disponível ({calc['ultima']})."
          + (f" Até a competência {cont[0]['de']}, o INSS registrou os descontos do cartão sob o código do benefício, sem "
             f"o número do contrato; a partir de {cont[0]['para']}, sob o nº {numero}. A continuidade do saldo devedor "
             f"na transição ({M.brl(cont[0]['saldo_de'])} em {cont[0]['de']} e {M.brl(cont[0]['saldo_para'])} em "
             f"{cont[0]['para']}) demonstra tratar-se da mesma conta do cartão."
             if cont and cont[0]["variacao"] <= 0.05 else "")
          + (f" {'A competência' if len(aus) == 1 else 'As competências'} {', '.join(aus)} "
             f"{'consta ausente' if len(aus) == 1 else 'constam ausentes'} e {'é registrada' if len(aus) == 1 else 'são registradas'} "
             "como ausente(s), não interpolada(s); os valores acumulados representam, portanto, o piso do efetivamente "
             f"pago {F('pelo Autor', 'pela Autora')}." if aus else ""))
    out.append(tabela(["MÊS/ANO", "DESCONTO (R$)", "ACUMULADO (R$)", "% DO CAPITAL"],
                      [[p["competencia"], num(p["desconto"] or 0), num(p["acumulado"]), pct(p["pct"])]
                       for p in calc["planilha"]], [1, 1, 1, 1]))
    corpo(f"A tabela acima revela dado irrefutável: em {mes_ext(marco)}, {a_} atingiu o marco de 200% do capital "
          "original — momento a partir do qual a Lei 14.690/2023 considera extinta a obrigação de pagar juros e encargos "
          f"adicionais. Ao promover o refinanciamento compulsório em {mes_ext(R['competencia'])}, o Banco Réu agiu sobre "
          "uma dívida juridicamente inexistente.")
    h2("Resumo Financeiro")
    ult = calc["ultima"]
    out.append(tabela(None, [
        [f"Capital originalmente emprestado (limite do cartão, {incl4})", M.brl(capital)],
        ["Teto legal de juros e encargos — 200% (Lei 14.690/2023)", M.brl(2 * capital)],
        [f"Total pago até o mês anterior ao refinanciamento ({CT.comp_s(rn - 1)})",
         f"{M.brl(calc['total_ate_refin'])} ({pct(calc['total_ate_refin'] / capital * 100)})"],
        [f"Crédito de refinanciamento registrado no INSS/DATAPREV ({R['competencia']}, já com IOF)", M.brl(saldo_ref)],
        [f"Total pago até o ajuizamento ({ult})", f"{M.brl(total_pago)} ({pct(total_pago / capital * 100)})"],
        [f"Saldo devedor atual no INSS ({ult})", M.brl(saldo_atual)],
        ["CUSTO TOTAL MÍNIMO (pago + saldo devedor)", M.brl(custo)],
        ["ONEROSIDADE SOBRE O CAPITAL ORIGINAL", pct(oneros)],
        ["Marco de 200% atingido em", marco],
        ["Meses em que o teto foi ultrapassado antes do refinanciamento", f"{meses_teto} meses"],
    ], [3, 1], destaque_ultima=False))

    # III — direito
    h1("DO DIREITO")
    h2("Da Aplicação do CDC e da Inversão do Ônus da Prova")
    corpo("A relação entre as partes é de consumo (arts. 2º e 3º, § 2º, do CDC), fato pacificado pela Súmula 297 do STJ, "
          "segundo a qual o Código de Defesa do Consumidor é aplicável às instituições financeiras. Aplica-se, portanto, a "
          "inversão do ônus da prova (art. 6º, VIII, do CDC), determinando-se ao Banco Réu a juntada do histórico "
          "integral de faturas e do desglose de cada parcela entre capital e juros — documentos em seu poder exclusivo.")
    h2("Da Nulidade Absoluta por Fraude à Lei Imperativa (Art. 166, VI, do Código Civil)")
    corpo("O negócio jurídico é absolutamente nulo quando celebrado para fraudar lei de ordem pública (art. 166, VI, do "
          "CC). A nulidade absoluta é declarável de ofício (art. 168, caput, do CC), opera retroativamente (ex tunc) e não "
          "admite convalidação (art. 169 do CC). Duas normas cogentes foram violadas:")
    corpo("(a) Art. 28, § 1º, da Lei 14.690/2023: “o total cobrado a título de juros e encargos financeiros não poderá "
          f"exceder o valor original da dívida.” O refinanciamento gerou custo total de {pct(oneros)} sobre o capital, "
          "em direta afronta ao dispositivo.")
    corpo("(b) Art. 2º-C, Resolução CMN 5.112/2023: a renegociação só é permitida se o valor cobrado de juros e encargos "
          "não exceder o valor original da dívida, “descontando-se os juros e encargos que já foram pagos”. O "
          "Banco Réu não deduziu absolutamente nada do histórico de pagamentos ao promover o refinanciamento — fato "
          "demonstrado pelo próprio extrato oficial do INSS (Seção II.2), que evidencia a simples reconstituição do saldo, "
          f"ignorando os {M.brl(calc['total_ate_refin'])} já pagos até então.")
    corpo("A fraude se consuma quando um ato aparentemente lícito — a renegociação de saldo — é usado como veículo para "
          "atingir resultado proibido: a perpetuação do endividamento além do limite legal. Reconhecida a nulidade, as "
          "partes devem ser restituídas ao status quo ante (art. 182 do CC): desconstituição do refinanciamento, liberação "
          f"da margem e devolução de todos os valores descontados a partir de {mes_ext(R['competencia'])}.")
    h2("Do Marco Extintivo de 200%: A Quitação Forçada Antes do Refinanciamento")
    corpo("Quando o total pago supera o dobro do capital originalmente concedido, a obrigação está inteiramente extinta "
          "por operação de lei. O raciocínio é encadeado:")
    for t in [
        "Passo 1: O art. 28, § 1º, da Lei 14.690/2023 impõe que os juros e encargos totais não podem exceder o valor "
        "original da dívida. Norma imperativa de ordem pública.",
        f"Passo 2: Em {mes_ext(marco)}, {a_} já havia pago {M.brl(marco_linha['acumulado'])} — representando "
        f"{pct(marco_linha['pct'])} do capital de {M.brl(capital)} —, ultrapassando o teto de 200% ({M.brl(2 * capital)}).",
        "Passo 3: Quando o total pago supera 200% do capital, já foram cobertos: (i) o capital integralmente (100%); e "
        "(ii) juros e encargos em valor igual ao capital (mais 100%) — atingindo exatamente o teto legal.",
        "Passo 4: A Resolução CMN 5.112/2023 exige que, ao renegociar, seja feito o desconto dos juros e encargos já "
        f"pagos. Com juros pagos já superiores ao teto legal desde {mes_ext(marco)}, o saldo disponível para nova "
        f"cobrança de juros era R$ 0,00 muito antes do refinanciamento de {mes_ext(R['competencia'])}.",
        f"Passo 5 — Conclusão: a obrigação já estava extinta por lei havia {meses_teto} "
        f"{'mês' if meses_teto == 1 else 'meses'} quando o Banco Réu promoveu o refinanciamento. O próprio extrato do "
        f"INSS comprova que o Banco registrou novo saldo de {M.brl(saldo_ref)} sem que nenhum valor fosse repassado "
        f"{F('ao Autor', 'à Autora')}. O Banco Réu refinanciou uma dívida juridicamente inexistente, configurando "
        "enriquecimento ilícito e nulidade absoluta.",
        "O ônus de demonstrar eventual dedução dos juros já pagos no cálculo do refinanciamento é do Banco Réu (art. 6º, "
        "VIII, do CDC) — que detém, com exclusividade, o desglose das parcelas. Na impossibilidade dessa demonstração, "
        "prevalece a interpretação mais favorável ao consumidor (art. 47 do CDC).",
    ]:
        corpo(t)
    h2("Da Violação à Boa-Fé Objetiva")
    corpo("O art. 422 do CC impõe probidade e boa-fé na execução do contrato. O refinanciamento unilateral — sigiloso, sem "
          "notificação e ignorando os pagamentos anteriores — configura venire contra factum proprium: o Banco Réu aceitou "
          "anos de pagamentos como amortização, para depois agir como se nada tivesse sido pago. Configura também prática "
          "abusiva do art. 39, V, do CDC: exigir vantagem manifestamente excessiva.")
    h2("Da Repetição do Indébito em Dobro (Art. 42, Parágrafo Único, do CDC)")
    corpo("A Corte Especial do STJ, no EAREsp nº 600.663/RS, fixou a tese, modulada a partir de 30/03/2021, de que a "
          "repetição em dobro prevista no parágrafo único do art. 42 do CDC é cabível quando a cobrança indevida "
          "consubstanciar conduta contrária à boa-fé objetiva, independentemente da natureza do elemento volitivo. Todos "
          f"os descontos a partir de {mes_ext(R['competencia'])} são indevidos, por incidirem sobre dívida já extinta "
          f"desde {mes_ext(marco)}. O valor descontado indevidamente totaliza {M.brl(pos)} em valores simples e "
          f"{M.brl(dobro)} na forma dobrada, a ser atualizado em cumprimento de sentença com: (i) juros de mora "
          "(Súmula 54/STJ); (ii) correção monetária desde cada desembolso (Súmula 43/STJ).")
    h2("Dos Danos Morais")
    corpo(f"A conduta do Banco Réu atinge a dignidade {da_} em sua manifestação mais concreta: drena mensalmente sua "
          f"verba alimentar e previdenciária sem que {F('ele', 'ela')} compreenda por que jamais consegue quitar o "
          f"contrato. {A_} arcou com {pct(total_pago / capital * 100)} do capital emprestado e ainda é "
          f"{F('cobrado', 'cobrada')} como {F('devedor', 'devedora')}, após descobrir que o banco operou um "
          "refinanciamento sigiloso sobre uma dívida já extinta por lei. Esse estado configura lesão à esfera íntima da "
          "personalidade, passível de reparação nos termos do art. 5º, V e X, da CF/88; arts. 186 e 927 do CC; e art. 6º, "
          "VI, do CDC.")
    corpo("A responsabilidade civil objetiva da instituição financeira está assentada na Súmula 479 do STJ — com mais "
          "razão quando a irregularidade é de sua própria autoria. Pugna-se pela condenação em R$ 20.000,00 (vinte mil "
          "reais), valor de função reparatória e pedagógica, suficiente para desestimular a perpetuação da prática "
          "abusiva, sem configurar enriquecimento sem causa.")

    # IV — pedidos
    h1("DOS PEDIDOS")
    corpo("Diante do exposto, requer:")
    L = iter("ABCDE")
    if ativo:
        corpo(f"{next(L)}) TUTELA PROVISÓRIA", [(f"A) TUTELA PROVISÓRIA", RBB)])
        ped("a.1", f"Tutela de urgência (art. 300 do CPC) para suspender imediatamente os descontos do contrato nº "
                   f"{numero} no benefício NB {proc['nb']}, vedando o repasse ao Banco Réu, sob pena de multa diária de "
                   "R$ 1.000,00 (mil reais); ou, alternativamente, tutela de evidência (art. 311, II e IV, do CPC);")
    lb = next(L)
    corpo("", [(f"{lb}) PRELIMINARES", RBB)])
    ped(f"{lb.lower()}.1", "A concessão dos benefícios da gratuidade da justiça (arts. 98 e 99 do CPC);")
    ped(f"{lb.lower()}.2", "A citação do Banco Réu para, querendo, apresentar contestação no prazo legal, sob pena de "
                           "revelia, manifestando a parte autora, desde já, interesse na realização de audiência de "
                           "conciliação;")
    lc = next(L)
    corpo("", [(f"{lc}) MÉRITO — PEDIDOS PRINCIPAIS", RBB)])
    c = lc.lower()
    ped(f"{c}.1", f"A declaração de nulidade absoluta do Refinanciamento Compulsório realizado em "
                  f"{mes_ext(R['competencia'])} sobre o contrato nº {numero} (crédito de refinanciamento registrado no "
                  f"INSS em {M.brl(saldo_ref)}, já com IOF de {M.brl(R['iof'])}), por fraude à lei imperativa (art. 166, "
                  "VI, do CC c/c art. 28, § 1º, da Lei 14.690/2023 e art. 2º-C, Resolução CMN 5.112/2023), com "
                  "desconstituição de todos os efeitos desde a data da prática;")
    ped(f"{c}.2", f"A declaração de quitação integral do contrato {tipo} nº {numero} já em {mes_ext(marco)}, quando os "
                  f"pagamentos acumulavam {M.brl(marco_linha['acumulado'])}, representando {pct(marco_linha['pct'])} do "
                  f"capital original ({M.brl(capital)}) — ultrapassando o teto legal de juros e encargos do art. 28, "
                  "§ 1º, da Lei 14.690/2023 (200%);")
    ped(f"{c}.3", f"A condenação do Banco Réu, em obrigação de fazer, a emitir, no prazo de 5 (cinco) dias úteis do "
                  "trânsito em julgado, as instruções para liberação integral da margem consignável bloqueada pelo "
                  f"contrato nº {numero} junto ao INSS/DATAPREV, sob pena de multa diária de R$ 2.000,00 (dois mil reais);")
    ped(f"{c}.4", f"A condenação do Banco Réu ao pagamento de repetição em dobro (art. 42, parágrafo único, do CDC; "
                  f"EAREsp 600.663/RS — Corte Especial do STJ) de todos os valores descontados a partir de "
                  f"{mes_ext(R['competencia'])}, no montante de {M.brl_ext(dobro)}, acrescido dos descontos que vierem a "
                  "ocorrer até a efetiva suspensão, com juros de mora (Súmula 54/STJ) e correção monetária de cada "
                  "desembolso (Súmula 43/STJ);")
    ped(f"{c}.5", "A condenação do Banco Réu ao pagamento de indenização por danos morais no valor de R$ 20.000,00 (vinte "
                  "mil reais) (arts. 186 e 927 do CC; art. 6º, VI, do CDC; Súmula 479/STJ), com juros e correção nos "
                  "termos das Súmulas 54 e 362 do STJ.")
    ld = next(L)
    corpo("", [(f"{ld}) PEDIDOS SUBSIDIÁRIOS", RBB)])
    ped(f"{ld.lower()}.1", f"Subsidiariamente ao pedido {c}.1, a anulação do refinanciamento por lesão (art. 157 do CC), "
                           "com recálculo do saldo devedor deduzindo todos os valores pagos e aplicando o teto da Lei "
                           "14.690/2023;")
    ped(f"{ld.lower()}.2", "Subsidiariamente, a revisão judicial do contrato com abatimento dos valores pagos, vedação de "
                           "novo refinanciamento sem anuência expressa e escrita do consumidor, e fixação de prazo "
                           "definitivo de quitação.")
    le = next(L)
    corpo("", [(f"{le}) INSTRUÇÃO PROCESSUAL", RBB)])
    ped(f"{le.lower()}.1", f"A inversão do ônus da prova (art. 6º, VIII, do CDC), determinando-se ao Banco Réu que junte, "
                           f"no prazo de 15 (quinze) dias da citação: (i) todas as faturas do contrato desde {incl4} até o "
                           "presente; (ii) desglose de capital e juros por parcela; (iii) contrato específico do "
                           f"refinanciamento de {mes_ext(R['competencia'])}; (iv) comprovantes de comunicação "
                           f"{F('ao Autor', 'à Autora')} sobre o refinanciamento; (v) histórico completo de transações no "
                           "DATAPREV — sob pena de se presumirem verdadeiros os fatos que se pretende demonstrar por meio "
                           "deles;")
    ped(f"{le.lower()}.2", f"Se necessário, a realização de perícia contábil, com os seguintes quesitos: (i) Total pago de "
                           f"{incl4} a {R['competencia']}? (ii) Saldo devedor real na data do refinanciamento, considerando "
                           "os pagamentos? (iii) Os juros e encargos pagos haviam atingido o valor original da dívida "
                           f"({M.brl(capital)}) na data do refinanciamento? (iv) O saldo refinanciado ({M.brl(saldo_ref)}) "
                           "considerou a amortização real do capital? (v) Qual seria o saldo correto aplicando a "
                           "Resolução CMN 5.112/2023?")
    ped(f"{le.lower()}.3", "A produção de todas as provas em direito admitidas.")

    corpo("", [("Da Composição do Valor da Causa", RBB)])
    out.append(tabela(None, [
        ["Nulidade do refinanciamento — saldo registrado no INSS (art. 292, II, CPC)", M.brl(saldo_ref)],
        [f"Repetição em dobro dos descontos a partir de {R['competencia']} ({M.brl(pos)} × 2)", M.brl(dobro)],
        ["Indenização por danos morais", "R$20.000,00"],
        ["VALOR TOTAL DA CAUSA (art. 292 do CPC)", M.brl(valor_causa)],
    ], [3, 1], destaque_ultima=True))
    out.append(M.par(B[117], [("Dá-se à causa o valor de ", RN), (M.brl_ext(valor_causa), RBB),
                              (", nos termos do art. 292 do CPC/2015.", RN)]))
    for i in range(118, len(B)):
        b = B[i]
        if i == 120:
            b = M.par(b, [(f"{M.g(q, 'cidade')}, {hoje.day} de {M.MESES[hoje.month - 1]} de {hoje.year}.",
                           (M.rprs(b) or [""])[0])])
        out.append(b)

    # ---- salvar e conferência
    saida = Path(a.saida)
    saida.mkdir(parents=True, exist_ok=True)
    nome_reu = re.sub(r"[^\w]+", "_", reu["nome"].split(" S.A")[0].split(" S A")[0]).strip("_")
    nome_aut = re.sub(r"[^\w]+", "_", M.g(q, "nome", "AUTOR")).strip("_")
    basen = f"Inicial_RMC_Refinanciamento_{nome_aut}_x_{nome_reu}_NB{(proc.get('nb') or '').replace('.', '').replace('-', '')}"
    destino = saida / f"{basen}.docx"
    M.salvar_docx(destino, cab, out, rod)
    Lr = [f"# Conferência — {destino.name}\n",
          f"- Processo {proc['processo']} · NB {proc['nb']} · réu {reu['nome']} · {enderec}",
          f"- Cartão {tipo} nº {numero} · incluído em {incl4} · limite (capital) {M.brl(capital)} · situação "
          f"{cart['situacao']} · tutela: {'sim' if ativo else 'não'}",
          f"- Histórico: {calc['primeira']} → {calc['ultima']} ({len(calc['planilha'])} competências)"
          + (f" · complementado por {', '.join(sorted(fontes_extra))}" if fontes_extra else ""),
          f"- Refinanciamento: {R['competencia']} · utilizado {M.brl(R['utilizado'])} · saldo {M.brl(R['saldo'])} · "
          f"IOF {M.brl(R['iof'])} · juros {R['juros_m']}% (vizinhos {juros_tipicos})",
          f"- Marco de 200%: {marco} ({M.brl(marco_linha['acumulado'])}, {pct(marco_linha['pct'])}) · "
          f"{meses_teto} meses antes do refinanciamento",
          f"- Pago até o refinanciamento: {M.brl(calc['total_ate_refin'])} · após: {M.brl(pos)} (dobro {M.brl(dobro)}) · "
          f"total pago {M.brl(total_pago)} · saldo atual {M.brl(saldo_atual)} · onerosidade {pct(oneros)}",
          f"- **Valor da causa: {M.brl_ext(valor_causa)}** (saldo refinanciado + dobro + R$ 20.000,00)"]
    if conferir:
        Lr.append("\n## ⚠️ Conferir antes de protocolar\n")
        Lr += [f"- {x}" for x in conferir]
    if alertas:
        Lr.append("\n## Alertas\n")
        Lr += [f"- {x}" for x in alertas]
    (saida / f"{basen}_conferencia.md").write_text("\n".join(Lr), encoding="utf-8")
    print(destino)
    print("\n".join(Lr))


def distinguishing(anteriores, data_contr, data_ref, a_, tipo):
    return [
        f"Existe(m) demanda(s) anterior(es) (Processo(s) nº {anteriores}) nas quais foi discutida a validade da "
        f"contratação originária do cartão {tipo}. O óbice da coisa julgada não se configura, por ausência da tríplice "
        "identidade exigida pelo art. 337, §§ 1º a 4º, do CPC/2015. São seis dimensões de distinção qualificada "
        "(distinguishing), nos termos do art. 489, § 1º, VI, do CPC:",
        f"1ª Dimensão — Fato Gerador Posterior e Autônomo: as ações anteriores discutiram se o contrato de {data_contr} "
        f"foi validamente celebrado. Esta ação discute o Refinanciamento Compulsório de {data_ref} — ato unilateral "
        f"praticado pelo banco anos após a contratação, sem qualquer manifestação de vontade d{'o' if a_.startswith('o') else 'a'} "
        f"{a_.split()[-1]}. São fatos distintos, separados no tempo, com causa de pedir autônoma. O art. 505, I, do CPC "
        "confirma que a coisa julgada não impede novo pedido fundado em fato novo e superveniente.",
        f"2ª Dimensão — Objeto Jurídico Diverso: as ações anteriores pediam a nulidade ou revisão do contrato original de "
        f"{tipo}. Esta ação pede exclusivamente a declaração de nulidade do ato jurídico de refinanciamento de {data_ref} "
        "e seus consectários. Não há identidade de pedido.",
        "3ª Dimensão — Marco Normativo Superveniente: esta ação funda-se na Lei 14.690/2023 (Lei Desenrola), promulgada "
        "em 03/10/2023, e na Resolução CMN 5.112/2023, em vigor a partir de 21/12/2023 — diplomas inexistentes quando as "
        "demandas anteriores foram ajuizadas. É impossível reconhecer coisa julgada sobre violação a norma que ainda não "
        "existia.",
        "4ª Dimensão — A Sentença Anterior Validou o Contrato Original, Não Autorizou Modificações Futuras: eventual "
        "sentença de improcedência reconheceu a higidez do contrato original — e é precisamente esse reconhecimento que "
        f"reforça esta ação: se o contrato era válido com as condições pactuadas em {data_contr}, o banco não tinha "
        "poderes para alterá-lo unilateralmente. Coisa julgada cobre o que foi decidido — não autoriza o que foi "
        "praticado depois.",
        "5ª Dimensão — O Refinanciamento Não Foi Objeto da Demanda Anterior: ainda que a sentença tenha sido prolatada "
        "após o refinanciamento, não há coisa julgada sobre ele, porque não constou da causa de pedir daquele processo. "
        "O art. 508 do CPC é claro: a coisa julgada cobre o que foi decidido, não o que poderia ter sido alegado de outra "
        "forma.",
        "6ª Dimensão — As Duas Ações São Compatíveis e Complementares: esta ação não pretende reformar a decisão anterior "
        "— aceita-a integralmente. Precisamente porque o contrato original era válido, qualquer modificação unilateral de "
        "suas condições é ilícita por duplo fundamento: viola a vontade originalmente declarada pelas partes e afronta a "
        "Lei 14.690/2023.",
    ]


if __name__ == "__main__":
    main()
