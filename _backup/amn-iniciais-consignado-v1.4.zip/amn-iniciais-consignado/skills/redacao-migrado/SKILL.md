---
name: redacao-migrado
description: Redige a petição inicial de contrato MIGRADO — "Emp. Migrados Ativos C/ Liminar" ou "Emp. Migrados Inativos S/ Liminar" (.docx timbrado do AMN) — para processos da ficha de ajuizamento da /triagem-consignado com tese MIGRADO (bloco A). Acione com "redigir migrado", "gerar as iniciais de migrado", "migrado ativo", "migrado inativo", ou depois de aprovada a ficha de um cliente. Não serve para não contratado, Tese 1000 nem RMC.
---

# Redação — Migrado (ativo e inativo)

Mesmo fluxo e mesmas entradas da `/redacao-nao-contratado`: **ficha aprovada** +
**extrato do benefício do processo** + **qualificação** (`clientes/<cliente>/qualificacao.json`
— ver o Passo 1 daquela skill). Requer as skills `triagem-consignado` e
`redacao-nao-contratado` instaladas ao lado (usa o motor de geração desta última).

## Gerar

Para cada processo da ficha com `tese = MIGRADO`:

```bash
python3 <pasta desta skill>/scripts/gerar.py \
  --ficha "<cliente>/triagem/ficha.json" --processo N \
  --extrato "<EXTRATO DO NB DO PROCESSO>.pdf" \
  --qualificacao "<cliente>/qualificacao.json" \
  --saida "<cliente>/iniciais" [--data AAAA-MM-DD]
```

`<pasta desta skill>` = o diretório base desta skill (informado ao carregá-la).

## O que muda em relação ao Não Contratado

- **Ementa**: migração unilateral; ausência de anuência; Res. CMN 4.753/2019 e IN 138/2022; cessão de posição contratual sem notificação (art. 290 do CC); nulidade da averbação.
- **Título**: "AÇÃO DECLARATÓRIA DE NULIDADE DA MIGRAÇÃO E DE INEXISTÊNCIA DE RELAÇÃO OBRIGACIONAL…".
- **Pedido 1**: nulidade da migração e da averbação, com base na Res. CMN 4.753/2019, IN 138/2022 e arts. 166, VI e VII, e 290 do CC, e, por consequência, inexistência da relação jurídica.
- **Ativo × inativo** é decidido pelo extrato, não pela ficha: havendo contrato ATIVO, a peça sai como **Migrados Ativos C/ Liminar** — título "COM PEDIDO DE TUTELA PROVISÓRIA DE URGÊNCIA", tópico de tutela e pedido de antecipação **só sobre os contratos ativos**, frase "e ainda assim vem sofrendo cobranças", e o texto do campo "Motivo da Exclusão" para contrato ainda ativo. Sem contrato ativo, sai como **Migrados Inativos S/ Liminar**.
- O número do contrato migrado aparece duas vezes no extrato (banco de origem e banco de destino): o gerador usa a ocorrência **do banco réu**. Se não houver ocorrência com o código do réu, avisa.

Todo o resto (juízo, réu, tabela, cálculo de parcelas, dobro, dano moral de R$ 20.000,00,
valor da causa, prescrição, litispendência, conferência) é idêntico ao Não Contratado.

## Conferir e entregar

Igual ao Passo 3 da `/redacao-nao-contratado`: apresentar o `_conferencia.md` de cada
processo (réu, juízo, tabela, valor da causa, liminar, tópicos condicionais, itens a
conferir e alertas) e entregar os `.docx`. Peça com `[CONFERIR]` ou
`[VERIFICAR ANTES DE PROTOCOLAR]` não está pronta para protocolo.

Atenção ao alerta de **descontos anteriores a 30/03/2021**: migrados antigos costumam
tê-los, e a repetição em dobro dessas parcelas esbarra na modulação do EAREsp 600.663/RS.
