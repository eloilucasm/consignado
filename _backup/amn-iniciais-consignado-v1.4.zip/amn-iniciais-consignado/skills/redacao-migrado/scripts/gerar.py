#!/usr/bin/env python3
"""Gera a inicial de MIGRADO (Emp. Migrados Ativos C/ Liminar ou Inativos S/ Liminar).

Usa o mesmo motor da skill redacao-nao-contratado (formatação, tabela, cálculos,
juízo, tópicos condicionais) com o texto próprio da tese da migração: ementa,
título "NULIDADE DA MIGRAÇÃO", pedido de nulidade (Res. CMN 4.753/2019, IN 138/2022,
arts. 166 e 290 do CC). Ativo ou inativo é decidido pelo extrato: havendo contrato
ativo, entra a tutela (só sobre os ativos).

Mesmos argumentos do gerador do Não Contratado.
"""
import sys
from pathlib import Path

MOTOR = Path(__file__).resolve().parent.parent.parent / "redacao-nao-contratado" / "scripts"
if not MOTOR.exists():
    MOTOR = Path.home() / ".claude/skills/redacao-nao-contratado/scripts"
sys.path.insert(0, str(MOTOR))
import gerar as motor  # noqa: E402

if __name__ == "__main__":
    motor.main(teses_aceitas=("MIGRADO",))
