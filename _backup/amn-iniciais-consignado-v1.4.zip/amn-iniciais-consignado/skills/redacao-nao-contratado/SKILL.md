---
name: redacao-nao-contratado
description: Redige a petição inicial "Emp. Não Contratado" (.docx timbrado do AMN) para processos da ficha de ajuizamento gerada pela /triagem-consignado — blocos B, C e CAIXA (tese NAO_CONTRATADO). Acione com "redigir não contratado", "gerar as iniciais de não contratado", "inicial contra a Caixa", ou depois de aprovada a ficha de um cliente. Não serve para migrado, Tese 1000 nem RMC (agentes próprios).
---

# Redação — Emp. Não Contratado

Entrada: a **ficha aprovada** (`clientes/<cliente>/triagem/ficha.json`) + o **extrato
do benefício** do processo + a **qualificação** do autor. Saída: um `.docx` por
processo, no timbre do escritório, e um `_conferencia.md` ao lado.

## Passo 1 — qualificação (uma vez por cliente)

Crie/atualize `clientes/<cliente>/qualificacao.json`:

```json
{"nome": "", "genero": "F|M", "nacionalidade": "", "estado_civil": "", "profissao": "",
 "cpf": "", "rg": "", "endereco": "", "cep": "", "cidade": "", "uf": "BA", "fonte": ""}
```

Fonte, nesta ordem: documentos pessoais / comprovante de residência enviados pelo
usuário → inicial já protocolada do mesmo cliente → termo. O termo costuma vir com
RG em branco e e-mail de terceiro: **não use o termo como fonte única do endereço**.
Campo que não tiver fonte fica vazio — o gerador escreve `[CONFERIR]` e avisa.
Não deduza gênero pelo nome: pergunte ou use o documento.

## Passo 2 — gerar

`<pasta desta skill>` = o diretório base desta skill (informado ao carregá-la). Requer a skill triagem-consignado instalada ao lado.

Para cada processo da ficha com `tese = NAO_CONTRATADO`:

```bash
python3 <pasta desta skill>/scripts/gerar.py \
  --ficha "<cliente>/triagem/ficha.json" --processo N \
  --extrato "<EXTRATO DO NB DO PROCESSO>.pdf" \
  --qualificacao "<cliente>/qualificacao.json" \
  --saida "<cliente>/iniciais" [--data AAAA-MM-DD]
```

Use o extrato **do mesmo NB** do processo (`processos[].nb`). Vários processos podem
rodar em sequência; são independentes.

O gerador:
- parte de `assets/modelo_formatado_amn.docx` (inicial formatada do escritório) e copia os parágrafos fixos como estão;
- endereça pelo `competencia` da ficha (Vara Cível da comarca TJBA / Vara Federal da subseção TRF1 para a Caixa);
- qualifica o réu pelo `dados/reus.json` da skill triagem-consignado (réu ausente → `[CONFERIR]`);
- monta a tabela pelo extrato: **Qtde = meses de Início a Fim, inclusive** (0 se o contrato foi excluído antes do 1º desconto); contrato ATIVO conta até a competência do mês anterior à data; restituição = dobro;
- dano moral fixo **R$ 20.000,00**; valor da causa = restituições + dano moral (Vara Federal: valor real, sem renúncia a teto);
- inclui, só quando cabem: **tutela** (contrato ativo — liminar só sobre os ativos), **prescrição decenal** (algum desconto com mais de 5 anos; citações marcadas `[VERIFICAR ANTES DE PROTOCOLAR]`), **ausência de litispendência** (`processos[].litispendencia` da ficha: outro benefício e/ou outra tese contra o mesmo réu);
- corrige no caminho dois defeitos do modelo: "sérvios" e a equação que substituía "R$10.000,00 (dez mil reais) e R$" na ementa do TRF-4.

## Passo 3 — conferir e entregar

Leia cada `_conferencia.md` e apresente ao usuário, por processo: réu, juízo, tabela
de contratos com qtde/valores, valor da causa, tópicos condicionais incluídos e tudo
que estiver em **Conferir antes de protocolar** e **Alertas**. Não esconda alerta.

Entregue os `.docx` (SendUserFile). Nunca diga que a peça está pronta para protocolo
se houver `[CONFERIR]` ou `[VERIFICAR ANTES DE PROTOCOLAR]` no texto.

## Regras

- Só processos da ficha aprovada; nunca acrescentar contrato que não esteja nela.
- Nunca escrever CNPJ, endereço de réu, comarca ou subseção de memória — tabelas em `triagem-consignado/dados/`.
- Réu novo: depois de conferido com o usuário, acrescentar em `dados/reus.json` (com a fonte).
- Mudança de texto-padrão pedida pelo usuário → alterar `scripts/gerar.py` (ou o modelo em `assets/`), não editar só o .docx gerado.
- O `scripts/gerar.py` desta skill é o **motor compartilhado** com a `/redacao-migrado`: qualquer mudança nele afeta as duas. Depois de mexer, gere de novo uma peça de cada tese e compare.
