#!/usr/bin/env python3
"""Gera a petição inicial "Emp. Não Contratado" (.docx timbrado) para UM processo
da ficha de ajuizamento.

Uso:
  python3 gerar.py --ficha ficha.json --processo 13 --extrato EXTRATO_DO_NB.pdf \
                   --qualificacao qualificacao.json --saida PASTA [--data 2026-10-20]

Base de formatação: assets/modelo_formatado_amn.docx (inicial formatada do
escritório). Parágrafos fixos são copiados como estão; só as partes variáveis
são reescritas. Saídas: <PASTA>/<arquivo>.docx e <PASTA>/<arquivo>_conferencia.md.
"""
import argparse
import datetime as dt
import json
import re
import shutil
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

AQUI = Path(__file__).resolve().parent
MODELO = AQUI.parent / "assets" / "modelo_formatado_amn.docx"
# a skill de triagem fica ao lado desta (mesma pasta "skills/"), seja em ~/.claude/skills ou num plugin
TRIAGEM = AQUI.parent.parent / "triagem-consignado"
if not TRIAGEM.exists():
    TRIAGEM = Path.home() / ".claude/skills/triagem-consignado"
sys.path.insert(0, str(TRIAGEM / "scripts"))
import extrato as ext  # noqa: E402

DANO_MORAL = 20000.00
MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto",
         "Setembro", "Outubro", "Novembro", "Dezembro"]
CONFERIR = "[CONFERIR]"

# ---------------------------------------------------------------- números

UN = ["", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove", "dez", "onze", "doze",
      "treze", "quatorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove"]
DZ = ["", "", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa"]
CT = ["", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos",
      "oitocentos", "novecentos"]


def _ate_mil(n):
    if n == 0:
        return ""
    if n == 100:
        return "cem"
    c, r = divmod(n, 100)
    partes = [CT[c]] if c else []
    if r:
        if r < 20:
            partes.append(UN[r])
        else:
            d, u = divmod(r, 10)
            partes.append(DZ[d] + (f" e {UN[u]}" if u else ""))
    return " e ".join(partes)


def _inteiro(n):
    if n == 0:
        return "zero"
    grupos = []
    for nome_s, nome_p, div in (("milhão", "milhões", 10 ** 6), ("mil", "mil", 1000), ("", "", 1)):
        g, n = divmod(n, div)
        if g:
            if div == 1000:
                grupos.append("mil" if g == 1 else f"{_ate_mil(g)} mil")
            elif div == 10 ** 6:
                grupos.append(f"{_ate_mil(g)} {nome_s if g == 1 else nome_p}")
            else:
                grupos.append(_ate_mil(g))
    if len(grupos) > 1:
        ultimo = grupos[-1]
        sem_e = ultimo.count(" e ") > 0 and not ultimo.startswith(("cem", "cento"))
        # "mil e cem", "mil e vinte" — mas "mil, cento e vinte"
        sep = ", " if (sem_e or ultimo.startswith("cento") or " e " in ultimo) else " e "
        return ", ".join(grupos[:-1]) + sep + ultimo
    return grupos[0]


def extenso(v):
    reais = int(round(v * 100)) // 100
    cent = int(round(v * 100)) % 100
    partes = []
    if reais:
        partes.append(f"{_inteiro(reais)} {'real' if reais == 1 else 'reais'}")
        if reais % 10 ** 6 == 0:
            partes[-1] = partes[-1].replace(" reais", " de reais")
    if cent:
        partes.append(f"{_inteiro(cent)} {'centavo' if cent == 1 else 'centavos'}")
    return " e ".join(partes) if partes else "zero reais"


def brl(v):
    s = f"{v:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
    return f"R${s}"


def brl_ext(v):
    return f"{brl(v)} ({extenso(v)})"


# ---------------------------------------------------------------- competências

def comp(s):
    m, a = s.split("/")
    return int(a) * 12 + int(m) - 1


def comp_str(n):
    return f"{n % 12 + 1:02d}/{n // 12}"


# ---------------------------------------------------------------- docx

def ler_modelo():
    with zipfile.ZipFile(MODELO) as z:
        xml = z.read("word/document.xml").decode("utf-8")
    ini = xml.index("<w:body>") + len("<w:body>")
    sect = xml.index("<w:sectPr", ini)
    corpo = xml[ini:sect]
    blocos = [m.group(0) for m in re.finditer(r"<w:p[ >].*?</w:p>|<w:tbl>.*?</w:tbl>", corpo, re.S)]
    return xml[:ini], blocos, xml[sect:]


def limpar_ids(x):
    x = re.sub(r'\s(w14:paraId|w14:textId|w:rsidR|w:rsidRDefault|w:rsidRPr|w:rsidP|w:rsidTr)="[^"]*"', "", x)
    return re.sub(r"<w:bookmark(Start|End)[^>]*/>", "", x)


def ppr(b):
    m = re.search(r"<w:pPr>.*?</w:pPr>", b, re.S)
    return m.group(0) if m else ""


def rprs(b):
    return [m.group(0) if m else "" for m in
            (re.search(r"<w:rPr>.*?</w:rPr>", r, re.S) for r in re.findall(r"<w:r[ >].*?</w:r>", b, re.S))]


def run(texto, rpr=""):
    return f'<w:r>{rpr}<w:t xml:space="preserve">{escape(texto)}</w:t></w:r>'


def par(proto, segmentos):
    """segmentos: lista de (texto, rPr). Mantém o pPr do protótipo."""
    return f"<w:p>{ppr(proto)}{''.join(run(t, r) for t, r in segmentos)}</w:p>"


def texto(b):
    return "".join(re.findall(r"<w:t[^>]*>([^<]*)", b))


def trocar_texto(b, de, para):
    """Troca dentro de um único <w:t>."""
    return b.replace(de, para, 1)


def celula_texto(tc, novo):
    p = re.search(r"<w:p[ >].*?</w:p>", tc, re.S).group(0)
    r = rprs(p)
    novo_p = f"<w:p>{ppr(p)}{run(novo, r[0] if r else '')}</w:p>"
    return re.sub(r"<w:p[ >].*?</w:p>", lambda _: novo_p, tc, count=1, flags=re.S)


def linha(tr, valores):
    tcs = re.findall(r"<w:tc>.*?</w:tc>", tr, re.S)
    novo = tr
    for tc, v in zip(tcs, valores):
        novo = novo.replace(tc, celula_texto(tc, v), 1)
    return novo


def tabela(proto, linhas_dados, total):
    rows = re.findall(r"<w:tr[ >].*?</w:tr>", proto, re.S)
    cab, dado, tot = rows[0], rows[1], rows[-1]
    corpo = "".join(linha(dado, v) for v in linhas_dados) + linha(tot, total)
    ini = proto.index(rows[0])
    fim = proto.index(rows[-1]) + len(rows[-1])
    return proto[:ini] + cab + corpo + proto[fim:]


def salvar_docx(destino, cabeca, blocos, rodape):
    xml = cabeca + "".join(blocos) + rodape
    with zipfile.ZipFile(MODELO) as zin, zipfile.ZipFile(destino, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            dados = xml.encode("utf-8") if item.filename == "word/document.xml" else zin.read(item.filename)
            zout.writestr(item, dados)


# ---------------------------------------------------------------- dados do caso

def carregar_reu(banco):
    cod = (banco or "").split(" - ")[0].strip()
    reus = json.loads((TRIAGEM / "dados/reus.json").read_text(encoding="utf-8"))["reus"]
    return reus.get(cod), cod


def g(q, campo, padrao=CONFERIR):
    v = (q or {}).get(campo)
    return v if v else padrao


def flex(genero, m, f):
    return f if (genero or "").upper().startswith("F") else m


def data_extrato(caminho):
    import pypdf
    p1 = pypdf.PdfReader(str(caminho)).pages[0].extract_text()
    m = re.search(r"(\d{2}/\d{2}/\d{4}) \d{2}:\d{2}:\d{2}", p1)
    return m.group(1) if m else None


TESE_DESC = {
    "MIGRADO": "nulidade da migração unilateral de contrato consignado",
    "NAO_CONTRATADO": "inexistência de contratação de empréstimo consignado",
    "TESE_1000": "reaverbação irregular de contrato excluído sob numeração derivada (Tese 1000 Contra)",
    "RMC_REFINANCIAMENTO": "nulidade do refinanciamento compulsório de cartão consignado (RMC/RCC)",
}


# ---------------------------------------------------------------- geração

def main(teses_aceitas=("NAO_CONTRATADO",)):
    ap = argparse.ArgumentParser()
    ap.add_argument("--ficha", required=True)
    ap.add_argument("--processo", type=int, required=True)
    ap.add_argument("--extrato", required=True)
    ap.add_argument("--qualificacao", required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--data", default=dt.date.today().isoformat())
    a = ap.parse_args()

    ficha = json.loads(Path(a.ficha).read_text(encoding="utf-8"))
    proc = next(p for p in ficha["processos"] if p["processo"] == a.processo)
    if proc["tese"] not in teses_aceitas:
        sys.exit(f"Processo {a.processo} é da tese {proc['tese']} — este gerador atende só: {', '.join(teses_aceitas)}.")
    tese = proc["tese"]
    migrado = tese == "MIGRADO"
    q = json.loads(Path(a.qualificacao).read_text(encoding="utf-8"))
    hoje = dt.date.fromisoformat(a.data)
    alertas, conferir = [], []

    # ---- réu
    reu, cod = carregar_reu(proc["reu"])
    if not reu:
        reu = {"nome": f"{CONFERIR} {proc['reu']}", "artigo": "do",
               "descricao": f"pessoa jurídica de direito privado, inscrito no CNPJ sob o n° {CONFERIR}, "
                            f"com endereço na {CONFERIR}"}
        conferir.append(f"Réu {proc['reu']} (código {cod}) não está em dados/reus.json — preencher CNPJ e endereço "
                        f"e acrescentar à tabela.")
    eh_caixa = cod == "104"

    # ---- contratos (extrato)
    lista = [r for r in ext.contratos(a.extrato) if r["inicio"]]
    mes_ref = hoje.year * 12 + hoje.month - 2  # última competência já descontada (mês anterior)
    linhas = []
    for c in proc["contratos"]:
        achados = ext.buscar(lista, c["contrato"])
        if not achados:
            conferir.append(f"Contrato {c['contrato']} não localizado no extrato — linha da tabela em branco.")
            linhas.append({"contrato": c["contrato"], "inclusao": CONFERIR, "inicio": CONFERIR, "fim": CONFERIR,
                           "parcela": 0.0, "qtde": 0, "total": 0.0, "rest": 0.0, "status": CONFERIR,
                           "ativo": False})
            continue
        # o mesmo número pode aparecer no banco de origem e no de destino (migração): usar o do banco réu
        do_reu = [x for x in achados if x["banco"].replace(" ", "").startswith(f"{cod}-")]
        if do_reu:
            achados = do_reu
        else:
            alertas.append(f"Contrato {c['contrato']}: nenhuma ocorrência no extrato com o código do réu ({cod}) — "
                           f"conferir o banco.")
        if len(achados) > 1:
            alertas.append(f"Contrato {c['contrato']} aparece {len(achados)}x no extrato para o réu — usada a "
                           f"ocorrência {'ativa' if any(x['secao'] == 'ATIVO' for x in achados) else 'mais recente'}.")
        r = next((x for x in achados if x["secao"] == "ATIVO"), achados[-1])
        ini, fim = comp(r["inicio"]), comp(r["fim"])
        ativo = r["secao"] == "ATIVO"
        ate = min(fim, mes_ref) if ativo else fim
        qtde = max(0, ate - ini + 1)
        total = round(qtde * r["parcela"], 2)
        incl = r["inclusao"]
        incl = f"{incl[:6]}20{incl[6:]}" if incl and len(incl) == 8 else incl
        status = "ATIVO" if ativo else ("ENCERRADO" if (r["situacao"] or "").startswith("Encerr") else "EXCLUÍDO")
        linhas.append({"contrato": r["contrato"], "inclusao": incl, "inicio": r["inicio"], "fim": r["fim"],
                       "parcela": r["parcela"], "qtde": qtde, "total": total, "rest": round(2 * total, 2),
                       "status": status, "ativo": ativo, "ini_n": ini, "ate_n": ate})
        if c.get("bloco") in ("B", "C") and ativo:
            alertas.append(f"ANOMALIA: contrato {r['contrato']} (bloco {c['bloco']}) está ATIVO no extrato.")
        if qtde and ini < comp("04/2021"):
            alertas.append(f"Contrato {r['contrato']}: há descontos anteriores a 30/03/2021 (modulação do EAREsp "
                           f"600.663/RS para a repetição em dobro) — conferir o pedido de dobro.")
    ativos = [l["contrato"] for l in linhas if l["ativo"]]
    liminar = bool(ativos)
    tot_desc = round(sum(l["total"] for l in linhas), 2)
    tot_rest = round(sum(l["rest"] for l in linhas), 2)
    valor_causa = round(tot_rest + DANO_MORAL, 2)
    com_desconto = [l for l in linhas if l["qtde"] > 0]

    # prescrição: algum desconto com mais de 5 anos
    inicios = [l["ini_n"] for l in com_desconto if "ini_n" in l]
    limite5 = (hoje.year - 5) * 12 + hoje.month - 1
    prescricao = bool(inicios) and min(inicios) < limite5
    if inicios and min(inicios) < (hoje.year - 10) * 12 + hoje.month - 1:
        alertas.append("Há descontos com MAIS DE 10 ANOS — o tópico de prescrição afirma que todos estão no prazo "
                       "decenal; rever o tópico e o pedido de restituição dessas parcelas.")

    # ---- textos variáveis
    gen = q.get("genero")
    cidade_autor, uf_autor = g(q, "cidade"), g(q, "uf", "BA")
    comp_txt = proc.get("competencia", "")
    if eh_caixa:
        m = re.search(r"((?:Sub)?[Ss]eção Judiciária d[aeo] .+?)(?:/[A-Z]{2})?$", comp_txt)
        secao = m.group(1).upper() if m else f"{CONFERIR} SUBSEÇÃO JUDICIÁRIA"
        enderecamento = f"AO JUÍZO FEDERAL DA ___ VARA FEDERAL CÍVEL DA {secao}, ESTADO DA BAHIA"
    else:
        m = re.search(r"Comarca de (.+?)/[A-Z]{2}", comp_txt)
        comarca = m.group(1).upper() if m else CONFERIR
        enderecamento = f"AO JUÍZO DA ___ VARA CÍVEL DA COMARCA DE {comarca}, ESTADO DA BAHIA"
    if "CONFERIR" in comp_txt or "NÃO" in comp_txt:
        conferir.append(f"Juízo: {comp_txt}")

    if migrado:
        ementa = ("EMENTA: Migração unilateral de contrato de crédito consignado. Ausência de anuência do "
                  "beneficiário. Violação da Resolução CMN nº 4.753/2019 e da Instrução Normativa INSS/PRES nº "
                  "138/2022. Cessão de posição contratual sem notificação (art. 290 do Código Civil). Nulidade da "
                  "averbação. Desconto indevido sobre verba de natureza alimentar. Responsabilidade objetiva. "
                  "Repetição do indébito. Dano extrapatrimonial.")
    else:
        ementa = (f"EMENTA: Empréstimo consignado não contratado. {flex(gen, 'Beneficiário', 'Beneficiária')} do "
                  "INSS. Ausência de manifestação volitiva. Ato juridicamente inexistente. Desconto indevido sobre "
                  "verba de natureza alimentar. Violação à IN INSS/PRES nº 138/2022. Responsabilidade objetiva da "
                  "instituição financeira. Repetição do indébito. Dano extrapatrimonial.")
    if liminar:
        ementa += " Tutela de urgência para suspensão imediata dos descontos."
    qualif = (f"{g(q, 'nome')}, {g(q, 'nacionalidade', flex(gen, 'brasileiro', 'brasileira'))}, "
              f"{g(q, 'estado_civil')}, {g(q, 'profissao')}, {flex(gen, 'inscrito', 'inscrita')} no CPF sob nº "
              f"{g(q, 'cpf')}, RG sob nº {g(q, 'rg')}, residente e {flex(gen, 'domiciliado', 'domiciliada')} na "
              f"{g(q, 'endereco')}, CEP {g(q, 'cep')}, cidade de {cidade_autor}/{uf_autor}, por seu advogado que esta "
              f"subscreve (procuração anexa), vem, respeitosamente, perante este Juízo, propor a presente")
    if CONFERIR in qualif:
        conferir.append("Qualificação com campo(s) [CONFERIR] — completar com os documentos pessoais.")
    if not gen:
        conferir.append("Gênero do(a) autor(a) não informado — flexões (brasileiro/a, inscrito/a) podem estar erradas.")
    titulo = [("AÇÃO DECLARATÓRIA DE NULIDADE DA MIGRAÇÃO E DE INEXISTÊNCIA DE RELAÇÃO OBRIGACIONAL, "
               if migrado else "AÇÃO DECLARATÓRIA DE INEXISTÊNCIA DE RELAÇÃO OBRIGACIONAL, ")
              + "CUMULADA COM REPETIÇÃO DO INDÉBITO, OBRIGAÇÃO DE FAZER E INDENIZAÇÃO POR DANOS EXTRAPATRIMONIAIS"]
    if liminar:
        titulo[0] += ","
        titulo.append("COM PEDIDO DE TUTELA PROVISÓRIA DE URGÊNCIA")
    face = (f"Em face {reu['artigo']} {reu['nome']}, {reu['descricao']}, pelos seguintes fatos, fundamentos e "
            f"razões de direito.")
    lista_ctr = ", ".join(f"nº {l['contrato']}" for l in linhas)
    lista_ativos = ", ".join(f"nº {c}" for c in ativos)

    # ---- montar documento
    cab, B, rod = ler_modelo()
    B = [limpar_ids(b) for b in B]
    RN = rprs(B[48])[0] if rprs(B[48]) else ""        # corpo normal
    RB = rprs(B[47])[0]                                # negrito (cabeçalho de contrato)
    RBB = rprs(B[105])[1]                              # negrito azul (pedidos/valores)
    P_CORPO, P_H1, P_H2 = B[13], B[12], B[28]
    out = []
    num = [0, 0, 0]
    secoes = {}

    def h(nivel, nome):
        if nivel == 1:
            num[0] += 1; num[1] = 0; num[2] = 0
            out.append(par(P_H1, [(f"{num[0]} {nome}", "")]))
        elif nivel == 2:
            num[1] += 1; num[2] = 0
            out.append(par(P_H2, [(f"            {num[0]}.{num[1]} - {nome}", "")]))
        else:
            num[2] += 1
            out.append(par(P_H2, [(f"            {num[0]}.{num[1]}.{num[2]} - {nome}", "")]))

    def corpo(t, proto=None):
        out.append(par(proto or P_CORPO, [(t, RN)]))

    def heading_do_modelo(b):
        st = re.search(r'<w:pStyle w:val="(Ttulo1|Ttulo2)"', b)
        if not st:
            return False
        t = texto(b).strip()
        m = re.match(r"^(\d+(?:\.\d+)*)\s*-?\s*(.*)$", t)
        if not m:
            return False
        nivel = m.group(1).count(".") + 1
        h(nivel, m.group(2).strip())
        if "INVERSÃO DO ÔNUS" in m.group(2):
            secoes["INVERSAO"] = num[0]
        return True

    letras = iter("abcdefghijklmnop")

    for i, b in enumerate(B):
        if i == 0:
            out.append(par(b, [(enderecamento, (rprs(b) or [""])[0])])); continue
        if i == 3:
            out.append(par(b, [(ementa, (rprs(b) or [""])[0])])); continue
        if i == 6:
            out.append(par(b, [(qualif, (rprs(b) or [""])[0])])); continue
        if i == 8:
            out.append(par(b, [(" ".join(titulo), (rprs(b) or [""])[0])])); continue
        if i == 9:
            out.append(par(b, [(face, (rprs(b) or [""])[0])])); continue
        if i == 17 and proc.get("litispendencia"):
            out.extend(bloco_litispendencia(proc, ficha, h, corpo))
        if i == 20:
            dados = [[l["contrato"], l["inclusao"], l["inicio"], l["fim"], brl(l["parcela"]), str(l["qtde"]),
                      brl(l["total"]), brl(l["rest"]), l["status"]] for l in linhas]
            out.append(tabela(b, dados, ["TOTAL", "", "", "", "", "", brl(tot_desc), brl(tot_rest), ""])); continue
        if i == 63:
            # o modelo do escritório tem "R$10.000,00 (dez mil reais) e R$" convertido em equação (bug de
            # conversão que leu os "$" como fórmula) — troca a equação por texto normal
            out.append(re.sub(r"<m:oMath>.*?</m:oMath>",
                              lambda _: run("$10.000,00 (dez mil reais) e R$", '<w:rPr><w:color w:val="3B63AF"/></w:rPr>'),
                              b, count=1, flags=re.S).replace("(vinte mil reais</w:t></w:r><w:proofErr w:type=\"gramStart\"/><w:r><w:rPr><w:color w:val=\"3B63AF\"/></w:rPr><w:t>) .", "(vinte mil reais</w:t></w:r><w:proofErr w:type=\"gramStart\"/><w:r><w:rPr><w:color w:val=\"3B63AF\"/></w:rPr><w:t>)."))
            continue
        if i == 33:
            out.append(trocar_texto(b, "sérvios", "serviços")); continue
        if i == 45:
            out.append(trocar_texto(b, "PROJUDI", "PJe")); continue
        if i in (47, 48, 49, 50):
            if i == 47:
                for l in com_desconto:
                    out.append(par(B[47], [(f"Contrato nº {l['contrato']}", RB)]))
                    out.append(par(B[48], [(
                        f"Até a presente data, a parte autora efetuou o pagamento de {l['qtde']} "
                        f"{'parcela' if l['qtde'] == 1 else 'parcelas'}, cuja soma resulta no valor de "
                        f"{brl_ext(l['total'])}. Assim, a parte ré deve restituir os valores descontados de forma "
                        f"dobrada que, atualmente, equivale ao valor de {brl_ext(l['rest'])}.", RN)]))
            continue
        if i == 51:
            if liminar:
                corpo("Por oportuno, como medida de precaução, informa a parte Autora que, da presente data até o "
                      "trânsito em julgado do processo, o banco réu poderá continuar debitando valores indevidos do "
                      "benefício da parte Requerente, caso não haja um provimento jurisdicional que a impeça. Dessa "
                      "forma, eventuais novas cobranças deverão ser incluídas no aludido pedido, com oportuna "
                      "apresentação em momento de liquidação do processo, o que se requer.")
            continue
        if i == 65 and prescricao:
            h(2, "DA PRESCRIÇÃO: INCIDÊNCIA DO PRAZO DECENAL")
            for t in texto_prescricao(linhas, a.extrato, com_desconto):
                corpo(t)
        if i == 72 and liminar:
            h(1, "DA CONCESSÃO DE TUTELA ANTECIPADA")
            for t in texto_tutela(lista_ativos):
                corpo(t)
        if i == 86:
            if ativos:
                out.append(b)
            else:
                out.append(b.replace("A ser preenchida quando da baixa", "Preenchida", 1)
                            .replace("A ser preenchida pela ré — não se pede a sua alteração",
                                     "Preenchida — não se pede a sua alteração", 1))
            continue
        if i == 108:
            out.append(trocar_texto(b, "Lei nº 14.905/2024 Requer", "Lei nº 14.905/2024. Requer")); continue
        if i == 26 and ativos:
            out.append(trocar_texto(b, "prestada pela empresa Requerida.",
                                    "prestada pela empresa Requerida e ainda assim vem sofrendo cobranças que lhe "
                                    "fazem perder todo o seu sossego com a situação em voga."))
            continue
        if i == 92 and ativos and len(ativos) == len(linhas):
            corpo("Tratando-se de contrato ainda ativo, o preenchimento do campo “Motivo da Exclusão” dar-se-á no "
                  "momento da baixa determinada por este Juízo, de modo que o registro da causa jurídica acompanhe, "
                  "desde a origem, o próprio ato de exclusão.")
            continue
        if i == 92 and ativos:
            corpo("Tratando-se de contratos já excluídos, a exclusão já ocorreu e o campo permanece vazio até hoje, "
                  "razão pela qual o provimento aqui buscado consiste na simples complementação do registro "
                  "histórico, sem qualquer alteração dos demais campos. Quanto ao(s) contrato(s) ainda ativo(s), a "
                  "providência será cumprida no momento da baixa determinada por este Juízo.")
            continue
        if i == 96:
            out.append(par(b, [(f"{next(letras)}) Concessão do benefício da justiça gratuita para as instâncias de "
                                "1° e 2° grau, requerido no instrumento procuratório; nos termos dos arts. 98 e 99, "
                                "caput e § 3°, CPC;", RN)])); continue
        if i == 97:
            out.append(par(b, [(f"{next(letras)}) Prioridade de Tramitação;", RN)])); continue
        if i == 98:
            out.append(par(b, [(f"{next(letras)}) a CITAÇÃO da requerida para que, querendo, apresente contestação "
                                "no prazo legal, sob pena de revelia, manifestando a parte autora, desde já, interesse "
                                "na realização de audiência de conciliação;", RN)])); continue
        if i == 99:
            if liminar:
                out.append(par(b, [(f"{next(letras)}) A ", RN), ("ANTECIPAÇÃO DOS EFEITOS DA TUTELA", RBB),
                                   (" para que seja a Demandada compelida a se abster de realizar novos descontos no "
                                    "benefício previdenciário da parte autora referente(s) ao(s) contrato(s) de "
                                    f"empréstimo consignado {lista_ativos}, sob pena de multa diária a ser fixada por "
                                    "este Juízo, visto que a permanência deste(s) desconto(s) compromete a verba "
                                    "alimentar da parte Autora;", RN)]))
                out.append(par(b, [(f"{next(letras)}) Sejam julgados totalmente procedentes os pedidos, confirmando "
                                    "a tutela antecipada ou a concedendo em sentença, e para que:", RN)]))
            else:
                out.append(par(b, [(f"{next(letras)}) Sejam julgados totalmente procedentes os pedidos, para que:",
                                    RN)]))
            continue
        if i == 100 and migrado:
            out.append(par(b, [("1. seja declarada a nulidade da migração e da averbação do(s) contrato(s) "
                                f"impugnado(s) {lista_ctr}, por ausência de solicitação, de autorização e de "
                                f"notificação {flex(gen, 'do devedor', 'da devedora')}, na forma da Resolução CMN nº "
                                "4.753/2019, da IN INSS/PRES nº 138/2022 e dos artigos 166, incisos VI e VII, e 290 do "
                                "Código Civil, e, por consequência, a declaração de inexistência de relação jurídica "
                                "entre as partes, com a inexigibilidade de todo e qualquer débito dela decorrente;",
                                RBB)])); continue
        if i == 100:
            out.append(par(b, [("1. seja declarada a inexistência da relação jurídica entre as partes quanto ao(s) "
                                f"contrato(s) impugnado(s) {lista_ctr} e, subsidiariamente, a declaração de sua "
                                "nulidade, com a consequente inexigibilidade de todo e qualquer débito dele(s) "
                                "decorrente;", RBB)])); continue
        if i == 103:
            t = ("4. seja a ré condenada na obrigação de fazer consistente em promover, junto ao sistema "
                 "eConsignado/DATAPREV, o preenchimento do campo Motivo da Exclusão — atualmente em branco — com a "
                 "expressão “Por força de decisão judicial”, mantido inalterado o campo Origem da Exclusão, no prazo "
                 "de 10 (dez) dias úteis, sob pena de multa diária de R$ 500,00, nos termos dos artigos 497 e 537 do "
                 "Código de Processo Civil")
            t += (", providência que, quanto a contrato ainda ativo, será cumprida no momento da baixa determinada "
                  "por este Juízo;" if ativos else ";")
            out.append(par(b, [(t, RBB)])); continue
        if i in (105, 106, 107):
            if i == 105:
                for l in com_desconto:
                    out.append(par(b, [("Contrato nº ", RN), (f"{l['contrato']} - {brl_ext(l['rest'])}.", RBB)]))
                if len(com_desconto) > 1:
                    out.append(par(B[107], [(f"Totalizando, {brl_ext(tot_rest)}.", RN)]))
                if not com_desconto:
                    conferir.append("Nenhum contrato com desconto efetivo — rever o pedido de restituição.")
            continue
        if i == 109:
            out.append(trocar_texto(b, "arbitramento juros", "arbitramento e juros")); continue
        if i in (111, 112, 113):
            if i == 111:
                out.append(par(b, [(f"{next(letras)}) A ", RN), ("INVERSÃO DO ÔNUS DA PROVA", RBB),
                                   (" em favor da Requerente, conforme autoriza Art. 6º, Inciso VIII, do Código de "
                                    "Defesa do Consumidor, e, em específico, requer seja determinado que a parte ré "
                                    f"junte aos autos os documentos relacionados no tópico {secoes.get('INVERSAO', '')} "
                                    "desta peça;", RN)]))
            elif i == 112:
                out.append(par(b, [(f"{next(letras)}) A observância dos precedentes judiciais colacionados no bojo "
                                    "da inicial e, em caso de divergência, a realização do distinguished conforme "
                                    "fundamentação supra;", RN)]))
            else:
                out.append(par(b, [(f"{next(letras)}) Condenação da requerida ao pagamento das custas processuais e "
                                    "dos honorários advocatícios de sucumbência;", RN)]))
            continue
        if i == 117:
            out.append(par(b, [("Dá-se à causa o valor de ", RN), (f"{brl_ext(valor_causa)}.", RBB)])); continue
        if i == 120:
            out.append(par(b, [(f"{cidade_autor}, {hoje.day} de {MESES[hoje.month - 1]} de {hoje.year}.",
                                (rprs(b) or [""])[0])])); continue
        if heading_do_modelo(b):
            continue
        out.append(b)

    # ---- salvar
    saida = Path(a.saida)
    saida.mkdir(parents=True, exist_ok=True)
    nome_reu = re.sub(r"[^\w]+", "_", reu["nome"].split(" S.A")[0].split(" S A")[0]).strip("_")
    nome_aut = re.sub(r"[^\w]+", "_", g(q, "nome", "AUTOR")).strip("_")
    rotulo = ("MigradoAtivo" if liminar else "MigradoInativo") if migrado else "NaoContratado"
    base = f"Inicial_{rotulo}_{nome_aut}_x_{nome_reu}_NB{(proc.get('nb') or '').replace('.', '').replace('-', '')}"
    destino = saida / f"{base}.docx"
    salvar_docx(destino, cab, out, rod)

    # ---- conferência
    L = [f"# Conferência — {destino.name}\n",
         f"- Processo {proc['processo']} da ficha · NB {proc.get('nb')} · réu {reu['nome']} · {enderecamento}",
         f"- Liminar: {'SIM, sobre ' + lista_ativos if liminar else 'não'} · Prescrição (tópico): "
         f"{'incluído' if prescricao else 'não'} · Litispendência (tópico): "
         f"{'incluído' if proc.get('litispendencia') else 'não'}",
         f"- Competência de referência para contar parcelas de contrato ativo: {comp_str(mes_ref)}\n",
         "| Contrato | Averbação | Início | Fim | Parcela | Qtde | Descontado | Restituição (dobro) | Status |",
         "|---|---|---|---|---|---|---|---|---|"]
    for l in linhas:
        L.append(f"| {l['contrato']} | {l['inclusao']} | {l['inicio']} | {l['fim']} | {brl(l['parcela'])} | "
                 f"{l['qtde']} | {brl(l['total'])} | {brl(l['rest'])} | {l['status']} |")
    L.append(f"| **TOTAL** | | | | | | **{brl(tot_desc)}** | **{brl(tot_rest)}** | |\n")
    L.append(f"- Dano moral: {brl(DANO_MORAL)} · **Valor da causa: {brl_ext(valor_causa)}**\n")
    if conferir:
        L.append("## ⚠️ Conferir antes de protocolar\n")
        L += [f"- {c}" for c in conferir]
    if alertas:
        L.append("\n## Alertas\n")
        L += [f"- {x}" for x in alertas]
    if prescricao:
        L.append("\n- O tópico de prescrição tem marcações [VERIFICAR ANTES DE PROTOCOLAR] nas citações.")
    if proc.get("litispendencia"):
        L.append("- O tópico de ausência de litispendência foi gerado — revisar a redação.")
    (saida / f"{base}_conferencia.md").write_text("\n".join(L), encoding="utf-8")
    print(destino)
    print("\n".join(L))


# ---------------------------------------------------------------- blocos condicionais

def especie_fmt(e):
    """'PENSAO POR MORTE PREVIDENCIARIA' -> 'pensão por morte previdenciária'."""
    t = (e or "").lower().strip()
    for de, para in (("pensao", "pensão"), ("previdenciaria", "previdenciária"), ("contribuicao", "contribuição"),
                     ("beneficio", "benefício"), ("assistencial", "assistencial"), ("auxilio", "auxílio"),
                     ("invalidez", "invalidez")):
        t = re.sub(rf"\b{de}\b", para, t)
    return t or None


def bloco_litispendencia(proc, ficha, h, corpo):
    lp = proc["litispendencia"]
    especies = {e.get("nb"): especie_fmt(e.get("especie")) for e in ficha.get("extratos", [])}
    for an in ficha.get("analises", []):
        especies.setdefault(an.get("nb"), especie_fmt(an.get("especie")))
    irmaos = [q for q in ficha["processos"] if q is not proc
              and (q["reu"] or "").split(" - ")[0] == (proc["reu"] or "").split(" - ")[0]]
    h(1, "DA AUSÊNCIA DE LITISPENDÊNCIA")
    esp = especies.get(proc["nb"]) or "[ESPÉCIE DO BENEFÍCIO]"
    corpo(f"Registra-se, desde logo, que a presente demanda tem por objeto exclusivamente o(s) contrato(s) "
          f"consignado(s) averbado(s) no benefício de {esp}, NB {proc['nb']}, de titularidade da parte Autora, "
          f"identificado(s) no tópico dos fatos.")
    for q in irmaos:
        ctrs = ", ".join(c["contrato"] for c in q["contratos"])
        if q["nb"] != proc["nb"]:
            esp2 = especies.get(q["nb"]) or "[ESPÉCIE DO BENEFÍCIO]"
            corpo(f"A parte Autora é também titular do benefício de {esp2}, NB {q['nb']}, sobre o qual incidem "
                  f"descontos de contrato(s) distinto(s) atribuído(s) à mesma instituição financeira (nº {ctrs}), "
                  f"objeto de ação própria. Embora as demandas sejam propostas contra a mesma Ré, referem-se a "
                  f"benefícios previdenciários distintos, cada qual com número próprio, e a contratos diferentes, "
                  f"cujos descontos recaem sobre verbas autônomas.")
        else:
            corpo(f"A parte Autora esclarece, ainda, que promove contra a mesma Ré ação própria, relativa ao(s) "
                  f"contrato(s) nº {ctrs}, averbado(s) no mesmo benefício, fundada em tese jurídica diversa — "
                  f"{TESE_DESC.get(q['tese'], q['tese'])}. Os contratos, a causa de pedir e os pedidos daquela "
                  f"demanda não se confundem com os da presente, que versa sobre "
                  f"{TESE_DESC.get(proc['tese'], proc['tese'])}.")
    corpo("Não há, portanto, litispendência, à luz do art. 337, §§ 1º a 3º, do Código de Processo Civil: embora "
          "idênticas as partes, são distintos a causa de pedir e o pedido de cada ação, o que se informa desde já em "
          "atenção ao dever de cooperação e à boa-fé processual.")
    return []


def texto_prescricao(linhas, extrato_pdf, com_desconto):
    emissao = data_extrato(extrato_pdf) or CONFERIR
    ini = min(l["ini_n"] for l in com_desconto)
    fim = max(l["ate_n"] for l in com_desconto)
    return [
        "Por cautela, cumpre afastar desde logo eventual alegação de prescrição. A pretensão aqui deduzida não "
        "decorre de defeito de um serviço contratado pelo consumidor, hipótese disciplinada pelo art. 27 do Código de "
        "Defesa do Consumidor, mas da cobrança de valores sem qualquer lastro contratual válido, por meio de "
        "averbações que a parte Autora jamais autorizou. Trata-se de pretensão de repetição de indébito fundada na "
        "cobrança indevida e na vedação ao enriquecimento sem causa, à qual se aplica o prazo geral de 10 (dez) anos "
        "previsto no art. 205 do Código Civil [VERIFICAR ANTES DE PROTOCOLAR].",
        "Nesse sentido é a orientação da Corte Especial do Superior Tribunal de Justiça no julgamento do EAREsp "
        "738.991/RS, que reconheceu que a pretensão de repetição de indébito por cobrança de serviços não contratados "
        "se submete ao prazo decenal do art. 205 do Código Civil, por não se tratar de reparação de dano decorrente de "
        "fato do serviço [VERIFICAR ANTES DE PROTOCOLAR].",
        "Ademais, a pretensão declaratória de inexistência da relação jurídica não se sujeita a prazo prescricional, "
        "uma vez que o ato juridicamente inexistente — ou nulo — não convalesce pelo decurso do tempo, a teor do art. "
        "169 do Código Civil [VERIFICAR ANTES DE PROTOCOLAR].",
        "Subsidiariamente, ainda que se cogitasse da aplicação do art. 27 do CDC, o próprio dispositivo estabelece "
        "que o prazo quinquenal somente se inicia a partir do conhecimento do dano e de sua autoria [VERIFICAR ANTES "
        "DE PROTOCOLAR]. No caso, a parte Autora apenas tomou ciência da origem e da autoria dos descontos ao obter o "
        f"Histórico de Empréstimo Consignado no portal Meu INSS, emitido em {emissao}, documento que acompanha a "
        "presente.",
        f"Considerando que os descontos impugnados ocorreram entre {comp_str(ini)} e {comp_str(fim)}, todos estão "
        "abrangidos pelo prazo decenal, impondo-se a rejeição de qualquer prejudicial de prescrição.",
    ]


def texto_tutela(lista_ativos):
    return [
        "Notória a necessidade de concessão de tutela de evidência, tendo em vista o preenchimento de todos os seus "
        "requisitos, uma vez que é demonstrada prova inequívoca, geradora de verossimilhança nas alegações, bem como o "
        "perigo de dano grave ou de difícil reparação (Art. 300 do CPC). De tão patente, a demonstração do "
        "preenchimento dos requisitos não comporta maiores esforços.",
        "O preenchimento do primeiro pressuposto prova inequívoca, já foi excessivamente demonstrado no decorrer de "
        "toda esta petição. Tal pressuposto se encontra evidenciado por toda a documentação apresentada em anexo.",
        "Observa-se ainda, no presente caso, agressão frontal a direitos e garantias fundamentais asseguradas pela "
        "Constituição Federal, o que, por si só, já justifica o reconhecimento da verossimilhança.",
        "Ressalte-se o ajuste do caso em tela aos termos dos arts. 294 e 300 do Código de Processo Civil. Fica "
        "evidente, pois, o cabimento do instituto da tutela antecipatória, vez que agride diretamente os direitos da "
        "parte Autora, que vem sofrendo descontos em seu benefício previdenciário, renda esta, utilizada como único "
        "provento de sua família, portanto de caráter substancial e alimentar, por culpa exclusiva da ineficiência da "
        "Ré.",
        "Isto posto, requer a concessão da ANTECIPAÇÃO DOS EFEITOS DA TUTELA para que seja a Demandada compelida a se "
        "abster de realizar novos descontos no benefício previdenciário da parte autora referente(s) ao(s) "
        f"contrato(s) de empréstimo consignado {lista_ativos}, sob pena de multa diária a ser fixada por este Juízo, "
        "visto que a permanência deste(s) desconto(s) compromete a verba alimentar da parte Autora.",
        "Saliente-se que não há perigo de irreversibilidade na antecipação. O único risco relevante é o da demora "
        "acrescer os prejuízos de ordem moral e fomentar o surgimento de maiores danos materiais à parte Autora.",
    ]


if __name__ == "__main__":
    main()
