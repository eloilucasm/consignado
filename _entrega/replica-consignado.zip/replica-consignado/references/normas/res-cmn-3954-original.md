---
titulo: "Resolução CMN nº 3.954, de 24 de fevereiro de 2011 — texto ORIGINAL (correspondentes no País)"
tipo: "norma"
especie: "resolução"
numero: "CMN 3.954/2011"
orgao: "Conselho Monetário Nacional"
ato_data: 2011-02-24
publicacao_dou: 2011-02-25
vigencia: "redação original; rege fatos até 2022-01-31"
situacao: "revogada: arts. 2º e 3º originais a partir de 2022-02-01 pela Res. CMN 4.935; norma revogada pela Res. BCB 277/2022 (2022-12-31)"
fonte: "https://normativos.bcb.gov.br/Lists/Normativos/Attachments/49450/Res_3954_v1_O.pdf"
consulta: 2026-10-28
nivel: "FEITO"
---

# Resolução CMN nº 3.954, de 24 de fevereiro de 2011 — texto ORIGINAL (correspondentes no País)

> Fonte: <https://normativos.bcb.gov.br/Lists/Normativos/Attachments/49450/Res_3954_v1_O.pdf> (versão original). Texto consolidado: <https://normativos.bcb.gov.br/Lists/Normativos/Attachments/49450/Res_3954_v12_P.pdf>
> Consulta: 2026-10-28 · extraído do PDF com `pdftotext` (UTF-8). Nível no painel: FEITO.
> **Vigência:** os arts. 2º e 3º originais foram revogados, a partir de 1º/2/2022, pela Res. CMN 4.935/2021, e o documento normativo consta como "revogado pela Resolução BCB nº 277, de 31/12/2022" (aviso no texto consolidado). Este arquivo guarda a redação original porque é a que rege fatos anteriores a 1º/2/2022. O **art. 2º** é a regra de responsabilidade da contratante citada nas skills ("o correspondente atua por conta e sob as diretrizes da instituição contratante, que assume inteira responsabilidade..."). **O art. 7º não trata disso** (confirmar no texto abaixo antes de citar).

RESOLUÇÃO Nº 3.954

Altera e consolida as normas que dispõem sobre a contratação de correspondentes no País.

O Banco Central do Brasil, na forma do art. 9º da Lei nº 4.595, de 31 de dezembro de 1964, torna público que o Conselho Monetário Nacional, em sessão realizada em 24 de fevereiro de 2011, com base nos arts. 3º, inciso V, 4º, incisos VI, VIII e XXXI, da referida Lei, e art. 14 da Lei nº 4.728, de 14 de julho de 1965,

RESOLVEU:

Art. 1º As instituições financeiras e demais instituições autorizadas a funcionar pelo Banco Central do Brasil devem observar as disposições desta resolução como condição para a contratação de correspondentes no País, visando à prestação de serviços, pelo contratado, de atividades de atendimento a clientes e usuários da instituição contratante.

Parágrafo único. A prestação de serviços de que trata esta resolução somente pode ser contratada com correspondente no País.

Art. 2º O correspondente atua por conta e sob as diretrizes da instituição contratante, que assume inteira responsabilidade pelo atendimento prestado aos clientes e usuários por meio do contratado, à qual cabe garantir a integridade, a confiabilidade, a segurança e o sigilo das transações realizadas por meio do contratado, bem como o cumprimento da legislação e da regulamentação relativa a essas transações.

Art. 3º Somente podem ser contratadas, na qualidade de correspondente, as sociedades empresárias e as associações, definidas na Lei nº 10.406, de 10 de janeiro de 2002 – Código Civil, e os prestadores de serviços notariais e de registro de que trata a Lei nº 8.935, de 18 de novembro de 1994.

§ 1º Exceto para as atividades definidas no art. 8º, incisos V, VII e IX, desta resolução, é vedada a contratação de entidade cujo objetivo exclusivo ou principal seja a prestação de serviços de correspondente ou cujo controle societário seja exercido pela instituição contratante ou por controlador comum.

§ 2º É vedada a contratação de entidade cujo controle societário, direta ou indiretamente, seja exercido por administrador de quaisquer instituições pertencentes ao conglomerado integrado pela instituição contratante.

§ 3º Podem ser contratadas como correspondentes as instituições financeiras e as demais instituições integrantes do Sistema Financeiro Nacional (SFN), observado o disposto no art. 18.

Art. 4º A instituição contratante, para celebração ou renovação de contrato de correspondente, deve verificar a existência de fatos que, a seu critério, desabonem a entidade contratada ou seus administradores, estabelecendo medidas de caráter preventivo e corretivo a

Resolução nº 3.954, de 24 de fevereiro de 2011.

serem adotadas na hipótese de constatação, a qualquer tempo, desses fatos, abrangendo, inclusive, a suspensão do atendimento prestado ao público e o encerramento do contrato.

Art. 5º Depende de prévia autorização do Banco Central do Brasil a celebração de contrato de correspondente com entidade não integrante do SFN cuja denominação ou nome fantasia empregue termos característicos das denominações das instituições do SFN, ou de expressões similares em vernáculo ou em idioma estrangeiro.

Art. 6º Não é admitida a celebração de contrato de correspondente que configure contrato de franquia, nos termos da Lei nº 8.955, de 15 de dezembro de 1994, ou cujos efeitos sejam semelhantes no tocante aos direitos e obrigações das partes ou às formas empregadas para o atendimento ao público.

Art. 7º Admite-se o substabelecimento do contrato de correspondente, em um único nível, desde que o contrato inicial preveja essa possibilidade e as condições para sua efetivação, entre as quais a anuência da instituição contratante.

§ 1º A instituição contratante, para anuir ao substabelecimento, deve assegurar o cumprimento das disposições desta resolução, inclusive quanto às entidades passíveis de contratação na forma do art. 3º.

§ 2º É vedado o substabelecimento do contrato no tocante às atividades de atendimento em operações de câmbio.

CAPÍTULO II

DO OBJETO DO CONTRATO DE CORRESPONDENTE

Art. 8º O contrato de correspondente pode ter por objeto as seguintes atividades de atendimento, visando ao fornecimento de produtos e serviços de responsabilidade da instituição contratante a seus clientes e usuários:

I - recepção e encaminhamento de propostas de abertura de contas de depósitos à vista, a prazo e de poupança mantidas pela instituição contratante;

II - realização de recebimentos, pagamentos e transferências eletrônicas visando à movimentação de contas de depósitos de titularidade de clientes mantidas pela instituição contratante;

III - recebimentos e pagamentos de qualquer natureza, e outras atividades decorrentes da execução de contratos e convênios de prestação de serviços mantidos pela instituição contratante com terceiros;

IV - execução ativa e passiva de ordens de pagamento cursadas por intermédio da instituição contratante por solicitação de clientes e usuários;

V - recepção e encaminhamento de propostas referentes a operações de crédito e de arrendamento mercantil de concessão da instituição contratante; Resolução nº 3.954, de 24 de fevereiro de 2011.

VI - recebimentos e pagamentos relacionados a letras de câmbio de aceite da instituição contratante;

VII - execução de serviços de cobrança extrajudicial, relativa a créditos de titularidade da instituição contratante ou de seus clientes;

VIII - recepção e encaminhamento de propostas de fornecimento de cartões de crédito de responsabilidade da instituição contratante; e

IX - realização de operações de câmbio de responsabilidade da instituição contratante, observado o disposto no art. 9º.

Parágrafo único. Pode ser incluída no contrato a prestação de serviços complementares de coleta de informações cadastrais e de documentação, bem como controle e processamento de dados.

Art. 9º O atendimento prestado pelo correspondente em operações de câmbio deve ser contratualmente restrito às seguintes operações:

I - compra e venda de moeda estrangeira em espécie, cheque ou cheque de

viagem;

II - execução ativa ou passiva de ordem de pagamento relativa a transferência unilateral do ou para o exterior; e

III - recepção e encaminhamento de propostas de operações de câmbio.

§ 1º As operações mencionadas no inciso I do caput somente podem ser realizadas pelos seguintes contratados:

I - instituição financeira ou instituição autorizada a funcionar pelo Banco Central

do Brasil;

II - pessoas jurídicas cadastradas no Ministério do Turismo como prestadores de serviços turísticos remunerados, na forma da regulamentação em vigor;

III - a Empresa Brasileira de Correios e Telégrafos (ECT); e

IV - os permissionários de serviços lotéricos.

§ 2º O contrato que inclua o atendimento nas operações de câmbio relacionadas nos incisos I e II do caput deve prever as seguintes condições:

I - limitação ao valor de US$3.000,00 (três mil dólares dos Estados Unidos), ou seu equivalente em outras moedas, por operação;

Resolução nº 3.954, de 24 de fevereiro de 2011.

II - obrigatoriedade de entrega ao cliente de comprovante para cada operação de câmbio realizada, contendo a identificação das partes, a indicação da moeda estrangeira, da taxa de câmbio e dos valores em moeda estrangeira e em moeda nacional; e

III - observância das disposições do Regulamento do Mercado de Câmbio e Capitais Estrangeiros (RMCCI).

CAPÍTULO III

DAS CONDIÇÕES GERAIS DO CONTRATO DE CORRESPONDENTE

Art. 10. O contrato de correspondente deve estabelecer:

I - exigência de que o contratado mantenha relação formalizada mediante vínculo empregatício ou vínculo contratual de outra espécie com as pessoas naturais integrantes da sua equipe, envolvidas no atendimento a clientes e usuários;

II - vedação à utilização, pelo contratado, de instalações cuja configuração arquitetônica, logomarca e placas indicativas sejam similares às adotadas pela instituição contratante em suas agências e postos de atendimento;

III - divulgação ao público, pelo contratado, de sua condição de prestador de serviços à instituição contratante, identificada pelo nome com que é conhecida no mercado, com descrição dos produtos e serviços oferecidos e telefones dos serviços de atendimento e de ouvidoria da instituição contratante, por meio de painel visível mantido nos locais onde seja prestado atendimento aos clientes e usuários, e por outras formas caso necessário para esclarecimento do público;

IV - realização de acertos financeiros entre a instituição contratante e o correspondente, no máximo, a cada dois dias úteis;

V - utilização, pelo correspondente, exclusivamente de padrões, normas operacionais e tabelas definidas pela instituição contratante, inclusive na proposição ou aplicação de tarifas, taxas de juros, taxas de câmbio, cálculo de Custo Efetivo Total (CET) e quaisquer quantias auferidas ou devidas pelo cliente, inerentes aos produtos e serviços de fornecimento da instituição contratante;

VI - vedação ao contratado de emitir, a seu favor, carnês ou títulos relativos às operações realizadas, ou cobrar por conta própria, a qualquer título, valor relacionado com os produtos e serviços de fornecimento da instituição contratante;

VII - vedação à realização de adiantamento a cliente, pelo correspondente, por conta de recursos a serem liberados pela instituição contratante;

VIII - vedação à prestação de garantia, inclusive coobrigação, pelo correspondente nas operações a que se refere o contrato;

Resolução nº 3.954, de 24 de fevereiro de 2011.

IX - realização, pelo contratado, de atendimento aos clientes e usuários relativo a demandas envolvendo esclarecimentos, obtenção de documentos, liberações, reclamações e outros referentes aos produtos e serviços fornecidos, as quais serão encaminhadas de imediato à instituição contratante, quando não forem resolvidas pelo correspondente;

X - permissão de acesso do Banco Central do Brasil aos contratos firmados ao amparo desta resolução, à documentação e informações referentes aos produtos e serviços fornecidos, bem como às dependências do contratado e respectiva documentação relativa aos atos constitutivos, registros, cadastros e licenças requeridos pela legislação;

XI - possibilidade de adoção de medidas pela instituição contratante, por sua iniciativa, nos termos do art. 4º, ou por determinação do Banco Central do Brasil;

XII - observância do plano de controle de qualidade do atendimento, estabelecido pela instituição contratante nos termos do art. 14, § 1º, e das medidas administrativas nele previstas; e

XIII - declaração de que o contratado tem pleno conhecimento de que a realização, por sua própria conta, das operações consideradas privativas das instituições financeiras ou de outras operações vedadas pela legislação vigente sujeita o infrator às penalidades previstas nas Leis nº 4.595, de 31 de dezembro de 1964, e nº 7.492, de 16 de junho de 1986.

Parágrafo único. A vedação de que trata o inciso VIII não se aplica às operações de financiamento e de arrendamento mercantil de bens e serviços fornecidos pelo próprio correspondente no exercício de atividade comercial integrante de seu objeto social.

CAPÍTULO IV

DO ENCAMINHAMENTO DE PROPOSTAS DE OPERAÇÕES DE CRÉDITO E DE ARRENDAMENTO MERCANTIL

Art. 11. O contrato de correspondente que incluir as atividades relativas a operações de crédito e de arrendamento mercantil, referidas no art. 8º, inciso V, deve prever, com relação a essas atividades:

I - obrigatoriedade de, no atendimento prestado em operações de financiamento e de arrendamento mercantil referentes a bens e serviços fornecidos pelo próprio correspondente, apresentação aos clientes, durante o atendimento, dos planos oferecidos pela instituição contratante e pelas demais instituições financeiras para as quais preste serviços de correspondente;

II - uso de crachá pelos integrantes da respectiva equipe que prestem atendimento nas operações de que trata o caput, expondo ao cliente ou usuário, de forma visível, a denominação do contratado, o nome da pessoa e seu número de registro no Cadastro de Pessoas Físicas (CPF);

Resolução nº 3.954, de 24 de fevereiro de 2011.

III - envio, em anexo à documentação encaminhada à instituição contratante para decisão sobre aprovação da operação pleiteada, da identificação do integrante da equipe do correspondente, contendo o nome e o número do CPF, especificando:

a) no caso de operações relativas a bens e serviços fornecidos pelo próprio correspondente, a identificação da pessoa certificada de acordo com as disposições do art. 12, § 1º, responsável pelo atendimento prestado; e

b) nas demais operações, a identificação da pessoa certificada que procedeu ao atendimento do cliente; e

IV - liberação de recursos pela instituição contratante a favor do beneficiário, no caso de crédito pessoal, ou da empresa fornecedora, nos casos de financiamento ou arrendamento mercantil, podendo ser realizada pelo correspondente por conta e ordem da instituição contratante, desde que, diariamente, o valor total dos pagamentos realizados seja idêntico ao dos recursos recebidos da instituição contratante para tal fim.

Art. 12. O contrato deve prever, também, que os integrantes da equipe do correspondente, que prestem atendimento em operações de crédito e arrendamento mercantil, sejam considerados aptos em exame de certificação organizado por entidade de reconhecida capacidade técnica.

§ 1º No caso de correspondentes ao mesmo tempo fornecedores de bens e serviços financiados ou arrendados, admite-se a certificação de uma pessoa por ponto de atendimento, que se responsabilizará, perante a instituição contratante, pelo atendimento ali prestado aos clientes.

§ 2º A certificação de que trata este artigo deve ter por base processo de capacitação que aborde, no mínimo, os aspectos técnicos das operações, a regulamentação aplicável, o Código de Defesa do Consumidor (CDC), ética e ouvidoria.

§ 3º O correspondente deve manter cadastro dos integrantes da equipe referidos no caput permanentemente atualizado, contendo os dados sobre o respectivo processo de certificação, com acesso a consulta pela instituição contratante a qualquer tempo.

CAPÍTULO V

DO CONTROLE DAS ATIVIDADES DO CORRESPONDENTE

Art. 13. A instituição contratante deve colocar à disposição do correspondente e de sua equipe de atendimento documentação técnica adequada, bem como manter canal de comunicação permanente com objetivo de prestar esclarecimentos tempestivos à referida equipe sobre seus produtos e serviços e deve atender, conforme o art. 10, inciso IX, às demandas apresentadas pelos clientes e usuários ao contratado.

Art. 14. A instituição contratante deve adequar o sistema de controles internos e a auditoria interna, com o objetivo de monitorar as atividades de atendimento ao público realizadas

Resolução nº 3.954, de 24 de fevereiro de 2011.

por intermédio de correspondentes, compatibilizando-os com o número de pontos de atendimento e com o volume e complexidade das operações realizadas.

§ 1º A instituição contratante deve estabelecer, com relação à atuação do correspondente, plano de controle de qualidade, levando em conta, entre outros fatores, as demandas e reclamações de clientes e usuários.

§ 2º O plano a que se refere o § 1º deve conter medidas administrativas a serem adotadas pela instituição contratante se verificadas irregularidades ou inobservância dos padrões estabelecidos, incluindo a possibilidade de suspensão do atendimento prestado ao público e o encerramento antecipado do contrato nos casos considerados graves pela instituição contratante.

§ 3º Fica o Banco Central do Brasil autorizado a estabelecer procedimentos a serem integrados aos controles de que trata este artigo, bem como, alternativa ou cumulativamente:

I - determinar a adoção de controles e procedimentos adicionais, estabelecendo prazo para sua implementação, caso verifique a inadequação do controle que a contratante exerce sobre as atividades do correspondente;

II - recomendar a suspensão do atendimento prestado ao público ou o encerramento do contrato, na forma do § 2º deste artigo; e/ou

III - condicionar a contratação de novos correspondentes à prévia autorização do Banco Central do Brasil, que verificará o atendimento das medidas de que tratam os incisos I e II.

CAPÍTULO VI

DA DIVULGAÇÃO DE INFORMAÇÕES

Art. 15. A instituição contratante deve manter, em página da internet acessível a todos os interessados, a relação atualizada de seus contratados, contendo as seguintes informações:

I - razão social, nome fantasia, endereço da sede e o número de inscrição no Cadastro Nacional da Pessoa Jurídica (CNPJ) de cada contratado;

II - endereços dos pontos de atendimento ao público e respectivos nomes e números de inscrição no CNPJ; e

III - atividades de atendimento, referidas no art. 8º, incluídas no contrato, especificadas por ponto de atendimento.

Parágrafo único. A instituição contratante deve disponibilizar, inclusive por meio de telefone, informação sobre determinada entidade ser, ou não, correspondente e sobre os produtos e serviços para os quais está habilitada a prestar atendimento.

Resolução nº 3.954, de 24 de fevereiro de 2011.

Art. 16. A instituição contratante deve segregar as informações sobre demandas e reclamações recebidas pela instituição, nos respectivos serviços de atendimento e de ouvidoria, apresentadas por clientes e usuários atendidos por correspondentes.

CAPÍTULO VII

DISPOSIÇÕES GERAIS

Art. 17. É vedada a cobrança, pela instituição contratante, de clientes atendidos pelo correspondente, de tarifa, comissão, valores referentes a ressarcimento de serviços prestados por terceiros ou qualquer outra forma de remuneração, pelo fornecimento de produtos ou serviços de responsabilidade da referida instituição, ressalvadas as tarifas constantes da tabela adotada pela instituição contratante, de acordo com a Resolução nº 3.518, de 6 de dezembro de 2007, e com a Resolução nº 3.919, de 25 de novembro de 2010.

Art. 18. Aplicam-se aos contratos de correspondente em que as partes sejam instituições financeiras ou instituições autorizadas a funcionar pelo Banco Central do Brasil as seguintes condições:

I - são dispensadas as exigências estabelecidas nos arts. 11 e 12, na hipótese de a instituição contratada oferecer a seus próprios clientes operações da mesma natureza;

II - não incide a vedação estabelecida no art. 10, inciso VIII; e

III - na relação de correspondentes a ser mantida em página da internet, referida no art. 15, devem constar, no mínimo, os seguintes dados:

a) razão social, nome fantasia, endereço da sede e o número de inscrição no CNPJ da instituição contratada; e

b) atividades de atendimento, referidas no art. 8º, incluídas no contrato.

Parágrafo único. Admite-se a contratação de instituição cujo controle societário seja exercido pela instituição contratante ou por controlador comum.

Art. 19. A instituição contratante deve realizar os seguintes procedimentos de informação ao Banco Central do Brasil, na forma definida pela referida autarquia:

I - designar diretor responsável pela contratação de correspondentes no País e pelo atendimento prestado por eles;

II - informar a celebração de contrato de correspondente, bem como posteriores atualizações e encerramento, discriminando os serviços contratados;

III - proceder à atualização das informações sobre os contratos de correspondente enviadas até a data de entrada em vigor desta resolução; e

Resolução nº 3.954, de 24 de fevereiro de 2011.

IV - elaborar relatórios sobre o atendimento prestado por meio de correspondentes.

Art. 20. O art. 38 da Resolução nº 3.568, de 29 de maio de 2008, passa a vigorar com a seguinte redação:

"Art. 38. ..........................................................................................................

..........................................................................................................................

II - limites operacionais das agências de turismo, bem como das empresas contratadas na forma prevista em regulamentação específica, incluídos os critérios para o seu cumprimento." (NR)

Art. 21. Fica o Banco Central do Brasil autorizado a baixar as normas e a adotar as medidas necessárias à execução do disposto nesta resolução.

Art. 22. Esta resolução entra em vigor na data de sua publicação, produzindo

efeitos:

I - três anos após a sua publicação, com relação aos arts. 11, inciso III, e 12;

II - um ano após a sua publicação:

a) com relação ao art. 3º, caput e § 1º, e aos arts. 7º e 8º, para o ajuste de contratos firmados até a data de publicação desta resolução; e

b) com relação aos arts. 10, incisos I, IX e XII, 11, inciso II, 13, 14, 15 e 16; e

III - na data de sua publicação, com relação aos demais dispositivos.

Art. 23. Ficam revogados:

I - as Resoluções ns. 3.110, de 31 de julho de 2003, 3.156, de 17 de dezembro de 2003, e 3.654, de 17 de dezembro de 2008;

II - os incisos I, II e III e os §§ 2º, 3º e 4º do art. 4º da Resolução nº 3.568, de 29 de maio de 2008;

III - o inciso III do § 1º e o § 2º do art. 1º da Resolução nº 3.518, de 6 de dezembro de 2007, com redação dada pela Resolução nº 3.693, de 26 de março de 2009; e

Resolução nº 3.954, de 24 de fevereiro de 2011.

IV - o inciso III do § 1º do art. 1º da Resolução nº 3.919, de 25 de novembro de 2010, a partir de 1º de março de 2011.

Brasília, 24 de fevereiro de 2011. Alexandre Antonio Tombini

Presidente Este texto não substitui o publicado no DOU de 25/2/2011, Seção 1, p. 44/45, e no Sisbacen.

Resolução nº 3.954, de 24 de fevereiro de 2011.
