# Padrão das peças do escritório — consignado

Vale para toda peça redigida por qualquer skill do pacote. Os modelos de cada skill trazem o conteúdo da tese; este arquivo fixa a forma e as regras de rotina. Em conflito, prevalece este padrão. Cite só dispositivos e precedentes que estejam no acervo; o que não estiver fica `[CONFERIR]`. A aparência (fonte, cores, numeração, notas) é da skill `tipografia-azul`.

## 0. Antes de redigir: rito e competência

O rito vem da triagem e do quadro de fatos: **Juizado Especial Cível (JEC)** ou **Justiça Comum**. Pelo art. 3º, I, da Lei 9.099/95, o JEC tem competência para causas de menor complexidade de valor até quarenta vezes o salário mínimo. **Antes de gerar, a skill pergunta ao advogado qual rito usar.** Pode sugerir pelo valor da causa e pela necessidade de prova, mas não escolhe sozinha. O rito muda: pedidos de prova (seção 4), honorários (seção 4), nome e destino do recurso.

Juízo, sempre pelas tabelas oficiais da triagem, nunca de memória:
- réu **Caixa Econômica Federal**: Vara Federal da (sub)seção judiciária do TRF1 que abrange o município do autor;
- demais réus: unidade da **comarca do TJBA** a que o município do autor pertence, que nem sempre é o próprio município. A comarca vem de `references/dados/tjba_comarcas.json`; a unidade e o endereçamento prontos, para o JEC e para a Justiça Comum, vêm de `references/dados/tjba_unidades.json` (explicação e fontes em `references/dados/territorial-tjba.md`). Só 40 comarcas têm Vara do Sistema dos Juizados Especiais. Nas demais, a causa do Juizado vai à unidade cível da comarca (Vara de Jurisdição Plena ou Vara dos Feitos Relativos às Relações de Consumo, Cíveis e Comerciais), pelo procedimento da Lei 9.099/95 (Lei 10.845/2007, arts. 107 e 156), e a petição diz isso no corpo (decisão do escritório de 03/11/2026);
- autor fora da Bahia: não há tabela no pacote; `[CONFERIR]`.

## 1. Endereçamento e tratamento

Fórmula impessoal dirigida ao órgão (CPC, art. 319, I). **Na inicial, o número da vara fica em branco** ("AO JUÍZO DA __ª VARA…"): quem define a vara é o distribuidor do tribunal, não o advogado; não é pendência nem se pergunta. Onde a tabela traz `[N]ª`, a inicial usa `__ª`. Nas peças intermediárias e recursais, a unidade é a da capa dos autos (decisão do escritório, 05/11/2026). Evite "Excelentíssimo", "Exmo.", "Meritíssimo" e "V. Exa." (tratamento impessoal; o modelo anterior usava "Excelência" no corpo).

| Destino | Endereçamento | No corpo |
|---|---|---|
| Justiça Comum (TJBA) | o `comum.enderecamento` da comarca em `tjba_unidades.json`; por exemplo, AO JUÍZO DA __ª VARA DOS FEITOS RELATIVOS ÀS RELAÇÕES DE CONSUMO, CÍVEIS E COMERCIAIS DA COMARCA DE [CIDADE] - BA; em Salvador, AO JUÍZO DA __ª VARA DE RELAÇÕES DE CONSUMO DA COMARCA DE SALVADOR - BA | "este Juízo" |
| Juizado Especial Cível, comarca com Vara do Sistema (40) | o `jec.enderecamento`; por exemplo, AO JUÍZO DA __ª VARA DO SISTEMA DOS JUIZADOS ESPECIAIS DA COMARCA DE [CIDADE] - BA; em Salvador, AO JUÍZO DA __ª VARA DO SISTEMA DOS JUIZADOS ESPECIAIS DO CONSUMIDOR DA COMARCA DE SALVADOR - BA | "este Juízo" |
| Juizado Especial Cível, comarca sem Vara do Sistema | o `jec.enderecamento`; por exemplo, AO JUÍZO DA VARA DE JURISDIÇÃO PLENA DA COMARCA DE [CIDADE] - BA. No preâmbulo, depois do nome da ação: "pelo procedimento da Lei nº 9.099/95" | "este Juízo" |
| Vara Federal (Caixa) | AO JUÍZO DA __ª VARA FEDERAL DA SUBSEÇÃO JUDICIÁRIA DE [CIDADE] - [UF] | "este Juízo" |
| Recurso (inominado ou apelação) | petição de interposição ao juízo de origem e razões à Turma Recursal ou ao Tribunal | vocativo "Colenda Turma," / "Egrégio Tribunal," |

## 2. Qualificação

Petição inicial: qualificação completa (CPC, art. 319, II): nome, nacionalidade, estado civil, profissão, CPF, RG, endereço com CEP. Nunca "já qualificado" na inicial. Fonte, nesta ordem: documentos pessoais e comprovante de residência; inicial já protocolada do mesmo cliente; o termo. Campo sem fonte vira `[CONFERIR]`. Não deduza gênero pelo nome. Peça intermediária ou recursal: "[NOME], já qualificado nos autos do processo em epígrafe".

## 3. Estrutura da petição inicial

**Nome da ação:** em maiúsculas só na primeira letra de cada palavra principal ("Ação Declaratória de Inexistência de Relação Jurídica e Nulidade de Migração de Contrato, Cumulada com Repetição do Indébito em Dobro…"), com preposições, artigos e conjunções em minúscula; nunca em caixa alta (por causa do tamanho da fonte do título). A formatação (`tipografia-azul`) não deve converter o título para caixa alta.

Ordem do modelo do escritório, com os tópicos condicionais incluídos só quando cabem:

1. Da gratuidade da justiça.
2. Da tramitação prioritária (quando 60 anos ou mais).
3. Dos fatos.
4. Do direito (relação de consumo; responsabilidade; a tese específica; repetição do indébito; dano moral).
5. Da inversão do ônus da prova.
6. Dos precedentes judiciais evocados ao caso concreto (seção 8).
7. Do campo "Motivo da Exclusão" no eConsignado/DATAPREV (quando há contrato ativo ou excluído com campo em branco).
8. Da tutela provisória de urgência (**só quando há contrato ativo**, e só sobre os ativos).
9. Da prescrição (quando há desconto com mais de 5 anos).
10. Da ausência de litispendência (quando o quadro de fatos indica outro processo contra o mesmo banco).
11. Das provas, dos pedidos, do valor da causa e fecho.

Cada tópico condicional tem gatilho: sem gatilho, não entra. Nada sobre quantas ações o autor ou o escritório têm.

## 4. Pedidos de rotina

Incluir sempre que cabíveis:

- **Gratuidade**: CPC, arts. 98 e 99, com a presunção do § 3º do art. 99 para pessoa natural; a assistência por advogado particular não impede (art. 99, § 4º). No JEC, acrescente o art. 54 da Lei 9.099/95.
- **Prioridade de tramitação**, se 60 anos ou mais (CPC, art. 1.048, I; Lei 10.741/2003, art. 71), com prova da idade.
- **Citação** para contestação e intimações em nome do advogado subscritor. **Audiência de conciliação**: na Justiça Comum, desinteresse em tópico próprio (CPC, arts. 319, VII, e 334, § 5º), com convite à composição extrajudicial pelos e-mails michaelneves.adv@gmail.com e diegoarleo@gmail.com e pelo telefone +55 73 9104-5925; no JEC, nada se declara (a sessão de conciliação é parte do procedimento, Lei 9.099/95, art. 16).
- **Declaração de inexistência/nulidade** da relação, conforme a tese (migrado: nulidade da migração e da averbação).
- **Obrigação de fazer**: cessação dos descontos, baixa da averbação no INSS e liberação da margem. Se o extrato mostra o campo "Motivo da Exclusão" em branco, pedir seu preenchimento com "Por força de decisão judicial", mantida a origem da exclusão, em 10 dias úteis, com multa diária de R$ 500,00 (CPC, arts. 497 e 537).
- **Obrigação de não fazer**: não averbar de novo, não descontar, não cobrar, não negativar e não ceder o crédito impugnado, sob pena de multa de R$ 1.000,00 por evento de descumprimento (CPC, art. 537). Decisão do escritório de 08/11/2026.
- **Repetição em dobro** de **todos** os descontos, fundada no texto do art. 42, parágrafo único, do CDC e na primeira tese do EAREsp 676.608/RS (Corte Especial, DJe 30/03/2021); para descontos anteriores a 30/03/2021, a dobra se apoia só no art. 42 (o acórdão modulou a tese). **Não cite o Tema 929/STJ** (acórdão não publicado, cabem embargos); o escritório atualizará quando sair. Corrigir a quantia com a Súmula 43/STJ (desde cada desconto), juros pela Súmula 54/STJ (desde o evento danoso); no RMC, juros desde a citação (Súmula 33 da Turma de Uniformização do TJBA), porque o cartão é contrato. Nos pedidos de correção e juros (restituição e dano moral), só a ressalva "observada a Lei 14.905/2024 a partir de 30/08/2024". Pedir que descontos posteriores à inicial, até o trânsito em julgado, entrem na liquidação.
- **Dano moral de R$ 20.000,00**, sempre. Fundamento: natureza alimentar do benefício; particularidades do caso (valor e tempo dos descontos), como a Súmula 40 do TJBA exige; tentativa administrativa só entra se os autos trouxerem uma (protocolo, "Presunções do escritório"). O caráter punitivo-pedagógico é mantido sem marca, mas não use a Súmula 326/STJ para sustentá-lo: ela trata de sucumbência.
- **Inversão do ônus da prova** (ver abaixo, por rito).
- **Honorários**: no primeiro grau do JEC, **não** pedir condenação em custas e honorários (Lei 9.099/95, art. 55); só em recurso, contra o recorrente vencido. Na Justiça Comum, pedir os honorários de sucumbência **sempre em 20%** (CPC, art. 85, § 2º), sem perguntar ao advogado (padrão do escritório, 05/11/2026); havendo contrato ativo, sobre a soma da condenação e do proveito econômico.

**Prova por rito:**
- **JEC:** formule a juntada de documentos **somente como encargo decorrente da inversão do ônus** (CDC, art. 14, § 3º; CPC, art. 429, II; Tema 1061/STJ), para a contestação. Não peça exibição autônoma, perícia nem ofício.
- **Justiça Comum:** acrescente o pedido expresso de **exibição** (CPC, arts. 396 a 404). **Perícia e quesitos não entram na inicial:** a decisão é da réplica, depois de ver os documentos que o banco juntar. Se o banco não juntar o instrumento ou a trilha, ou se o que juntar não provar a contratação, não se pede perícia: o ônus é dele (CPC, art. 429, II). O efeito da não exibição é o do art. 400 do CPC, e não uma "inexistência confirmada" (ponto D6).

## 5. Valor da causa

Restituição em dobro de todos os descontos, mais R$ 20.000,00 de dano moral, mais o proveito econômico declaratório: as parcelas vincendas dos contratos ativos (no RMC, o saldo refinanciado). A soma vale sempre, em qualquer rito (CPC, art. 292, II e VI; decisão do escritório de 03/11/2026); sem contrato ativo, o proveito é zero. **Exceção, migrado:** valor da causa = restituição em dobro + dano moral, sem o proveito, que depende de fatos posteriores à inicial e vai à liquidação (decisão de 12/11/2026). No JEC, se a soma passar de 40 salários mínimos, o script alerta: rever o rito. Em Vara Federal, valor real, sem renúncia a teto. Mostre a memória do cálculo por contrato (premissas, quantidade de descontos, parcela, total, dobro) e marque `[CÁLCULO A CONFERIR]`.

## 6. Documentos

A peça **não leva** o tópico "Dos documentos": cada documento é identificado no ponto do corpo em que é citado: **na inicial, pelo nome, como anexo** ("extrato do INSS anexo"), porque o processo ainda não existe e não há ID; em réplica, recurso e demais peças de processo em curso, por ID e página.

A lista dos anexos fica **fora da peça**, na nota de entrega ao advogado, como conferência para o protocolo: numerada na ordem em que os documentos são citados, com o que cada um comprova. Base: procuração, declaração de hipossuficiência, documento de identidade, comprovante de residência atual e legível, extrato do INSS (Histórico de Empréstimo Consignado) do NB do processo, e os demais conforme a tese.

## 7. Fecho

```
Termos em que, pede deferimento.

[Cidade] - [UF], [dd] de [mês] de [aaaa].


[NOME DO ADVOGADO]
OAB/[UF] nº [00.000]
```

A data é a do dia da produção da peça. Nunca deixe "[dd]" nem data de exemplo. A cidade e a UF do fecho **não se perguntam**: são a cidade-sede do juízo competente, tirada do endereço do autor (`foro.fecho` do `calculo.json`; na réplica e no recurso, a comarca do processo).

Assinam as peças do escritório (a skill não pergunta quem assina):

| Advogado | OAB |
|---|---|
| Diego Ramos Arléo Barbosa | OAB-BA nº 38.179 |
| Thadeu Gomes Muniz | OAB-BA nº 44.113 |
| Michael Santos Neves | OAB-BA nº 50.954 |
| Nádia Lívia Oliveira Macedo | OAB-BA nº 82.380 |

Subscritores padrão: **Diego Ramos Arléo Barbosa (OAB-BA nº 38.179) e Michael Santos Neves (OAB-BA nº 50.954)**, e as intimações saem em nome dos dois. Michael Santos Neves é acrescentado porque o escritório protocola nos estados em que ele tem inscrição; em peça para outro estado, use a inscrição dele naquele estado se constar do quadro de fatos, e só então pergunte.

## 8. Dos Precedentes Judiciais Evocados ao Caso Concreto

**Obrigatório** em toda petição judicial (inicial, intermediária como réplica, memoriais e contrarrazões, ou recursal) que citar súmula, jurisprudência ou precedente. Não se aplica a petição simples de juntada, a manifestação sem precedente nem a requerimento ou recurso administrativo (o art. 489 do CPC trata de decisão judicial). Posição: depois de "Do direito" e antes dos pedidos, com título numerado conforme a peça. O texto abaixo é fixo: reproduza-o sem alterar, exceto a lista e a numeração.

---

> **[N]. Dos Precedentes Judiciais Evocados ao Caso Concreto**
>
> Precedentes evocados nesta peça: [lista, com o tópico de cada um, por exemplo: Súmula 479/STJ (tópico 4); Tema 1061/STJ (tópico 5)].

O Código de Processo Civil estabelece sistema de precedentes destinado a assegurar coerência e integridade aos julgamentos, de modo que decisões sobre o mesmo tema e as mesmas circunstâncias não destoem entre si.

Nesse sentido, dispõe o art. 489, § 1º, VI:

> Art. 489. (...).
>
> § 1º Não se considera fundamentada qualquer decisão judicial, seja ela interlocutória, sentença ou acórdão, que:
>
> (...)
>
> VI - deixar de seguir enunciado de súmula, jurisprudência ou precedente invocado pela parte, sem demonstrar a existência de distinção no caso em julgamento ou a superação do entendimento.

A norma impõe que, uma vez invocado precedente pela parte, o julgador que pretenda decidir em sentido diverso deve, de forma expressa e fundamentada, distingui-lo do caso concreto (*distinguishing*) ou justificar sua superação (*overruling*), sob pena de a decisão ser tida por não fundamentada.

O *distinguishing* pressupõe ausência de coincidência entre os fatos da demanda e a tese jurídica que sustentou o precedente, ou peculiaridade do caso concreto que afaste a aplicação de sua *ratio decidendi*. Mesmo diante de precedente vinculante, essa distinção deve ser feita de forma expressa e fundamentada, e não presumida.[^1]

O *overruling*, por sua vez, pressupõe que o precedente já não se sustenta, apurando-se sua consistência sistêmica e congruência social por meio do denominado *basic overruling principle*. Falhando em qualquer desses aspectos, a superação também deve ser expressamente justificada.[^2]

Requer-se a apreciação de cada um dos precedentes evocados de forma expressa, promovendo a distinção ou a superação que entender cabível, mas sempre de modo fundamentado, nos termos do art. 489, § 1º, VI, do CPC, sob pena de a decisão incorrer em vício apto a ensejar embargos de declaração.

[^1]: DONIZETTI, Elpídio. **A Força dos Precedentes do Novo Código de Processo Civil**. 2018. Disponível em: https://elpidiodonizetti.jusbrasil.com.br/artigos/155178268/a-forca-dos-precedentes-do-novo-codigo-de-processo-civil.

[^2]: FENSTERSEIFER, Wagner Arnold. Distinguishing e overruling na aplicação do art. 489, § 1.º, VI, do CPC/2015. **Revista de Processo**, São Paulo, v. 252. Editora Revista dos Tribunais, 2017.

---

**Ponte para o JEC.** O Enunciado 162 do FONAJE afasta o art. 489 do CPC dos Juizados, diante do art. 38 da Lei 9.099/95, e o Enunciado 161 só admite o CPC quando houver remissão expressa ou compatibilidade com os critérios do art. 2º da Lei 9.099/95. Decisão do escritório (28/10/2026): o texto acima vale também no JEC, com este parágrafo inserido logo depois do primeiro:

> Nos Juizados Especiais, a sentença segue o art. 38 da Lei 9.099/95, que dispensa o relatório, mas exige que mencione os elementos de convicção do Juiz. O art. 489, § 1º, VI, do CPC é compatível com os critérios do art. 2º da mesma lei e é invocado aqui como parâmetro para o enfrentamento dos precedentes.

Não cite os Enunciados 161 e 162 na peça: servem à redação, não à tese.

Nos pedidos: "apreciação expressa de cada precedente evocado, nos termos do art. 489, § 1º, VI, do CPC".

*(O texto, com as notas de rodapé de doutrina, vem da seção 8 do `padrao-pecas.md` da skill de benefícios por incapacidade do kit Cortex. As duas obras citadas (Donizetti; Fensterseifer) foram conferidas manualmente pelo escritório em 30/10/2026. O art. 489, § 1º, VI, está literalmente em `normas/cpc.md`.)*

**Notas de precedente:** padrão ABNT da `tipografia-azul`, com dados só do acervo (`jurisprudencia/`). Dado que falte fica como campo evidente na nota.

## 9. Revisão antes da entrega

Toda peça passa por esta revisão antes de ser entregue ou formatada. Marque cada item como OK, FALHA ou ATENÇÃO. Revise substância, completude e correção jurídica, não estilo.

**Completude**
- [ ] Endereçamento correto para o rito e para o réu (seção 1)
- [ ] Qualificação completa; sem "já qualificado" na inicial
- [ ] Só contratos que estão **na análise e no termo**
- [ ] Gratuidade, prioridade de tramitação (se 60 anos ou mais) e pedidos de rotina (seção 4)
- [ ] Valor da causa com memória por contrato (seção 5)
- [ ] Todo documento citado identificado (inicial: pelo nome, como anexo, sem ID; demais peças: ID e página); sem tópico "Dos documentos"; lista dos anexos na nota de entrega
- [ ] Figuras (se houver) no padrão de `assets/padrao-figuras.md`: 17 cm a 300 dpi, nada abaixo de 9 pt, nada sobreposto, rodapé sem ID na inicial

**Fundamentação**
- [ ] Cada artigo, súmula e tema citado existe no acervo; o resto ficou `[CONFERIR]`
- [ ] Tema 929/STJ **não** citado
- [ ] Norma aplicada é a da data do fato (IN 28 até 12/12/2022, IN 138 depois; 3.954 até 31/1/2022, 4.935 depois)
- [ ] Nada sobre biometria sem examinar o prazo prorrogado pela IN 143 e o acesso autenticado (art. 5º, § 11)
- [ ] Nenhuma citação de Súmula 326 para caráter punitivo; nenhuma "inexistência confirmada" como efeito automático da não exibição
- [ ] Res. CMN 4.753/2019 e Res. BCB 96/2021 não usadas como base de nulidade ou de guarda de trilha, salvo decisão do escritório (pontos D2 e D5 do painel)
- [ ] Todo pedido tem fundamento e todo fundamento leva a um pedido

**Checagem pré-recurso (FSC1 a FSC12)** — cada item responde "a sentença que perderíamos tinha este fundamento?" Rode o script de cálculo e confira `checagem-fsc-vf.md` (`assets/escrutinio-fsc-vf.md`): nenhum FSC ATIVADO sem tratamento na peça.
- [ ] A peça não nega, em nome do cliente, o recebimento do valor: afirma que o banco não comprovou o crédito (art. 373, II, do CPC; Súmula 42/TJBA) (FSC4, FSC12)
- [ ] Ônus: art. 14, § 3º, CDC + art. 429, II, CPC + Tema 1061 antes do art. 6º, VIII (FSC3)
- [ ] Autoria negada de forma específica por contrato, sem fato novo que só o banco prova (FSC7, FSC1, FSC2)
- [ ] Valor liberado do extrato tratado; portabilidade pura e mesmo dia identificados (FSC4, FSC11); cadeia de cessão questionada nos eixos existência e eficácia, quando migrado (FSC5)
- [ ] Data de ciência no quadro; declaração de inexistência separada de repetição e dano (FSC6)
- [ ] Dano moral com natureza alimentar e particularidades do caso (FSC8)
- [ ] Rito e prova: JEC sem exibição, perícia ou ofício; Justiça Comum com exibição, sem perícia nem quesitos na inicial (perícia: decisão da réplica) (FSC9, FSC10)
- [ ] Documentos de identidade e residência atuais e legíveis; um processo por benefício + banco + tese; nada sobre outras ações (FSC12)

**Precedentes**
- [ ] Tópico da seção 8 presente, com lista que bate com as citações e o pedido de apreciação expressa

**Rito**
- [ ] Rito confirmado pelo advogado; competência correta; sem pedido de custas e honorários no 1º grau do JEC
- [ ] Prazo, quando for recurso: JEC 10 dias úteis (Lei 9.099/95, arts. 42 e 12-A); apelação 15 dias (CPC, art. 1.003, § 5º), contados em dias úteis (art. 219 do CPC, conferido no acervo)

**Coerência**
- [ ] Fatos iguais aos do quadro de fatos; relato do cliente não apresentado como prova
- [ ] Datas coerentes; sem contradição interna; fecho com data real e com a cidade-sede do juízo (`foro.fecho`)
- [ ] Dano moral em R$ 20.000,00

**Pendências**
- [ ] Todas as marcas `[PREENCHER]`, `[CONFERIR]`, `[VERIFICAR ANTES DE PROTOCOLAR]` e `[CÁLCULO A CONFERIR]` listadas ao final da entrega

**Resultado**
- **Aprovado:** nenhuma FALHA. Sai como documento final, com as pendências listadas.
- **Reprovado:** corrija cada FALHA e revise de novo. No máximo dois ciclos.
- **Bloqueado:** se o segundo ciclo ainda tiver FALHA, ou faltar dado essencial, entregue como minuta `BLOQUEADO PARA USO FINAL`, com a lista do que impede o uso.

Informe o resultado em uma linha (aprovado, reprovado e corrigido, ou bloqueado) e a lista de pendências.
